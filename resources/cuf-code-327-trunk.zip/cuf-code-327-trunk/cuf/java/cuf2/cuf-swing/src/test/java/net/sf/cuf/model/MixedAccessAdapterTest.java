package net.sf.cuf.model;

import junit.framework.TestCase;

/**
 * various tests concerning the {@link MixedAccessAdapter}.
 */
public class MixedAccessAdapterTest extends TestCase
{

    /**
     * tests if the adapter works if there is no setter available
     */
    public void testGetterWithoutSetter()
    {
        TestDataObject tdo = new TestDataObject();
        tdo.setString( "Test");
        assertEquals( "direct access must return test value", "Test", tdo.getROString());
        MixedAccessAdapter adapter = new MixedAccessAdapter( "rOString");
        assertEquals( "value must be Test", "Test", adapter.getValue( tdo));
    }
    
    /**
     * tests if the adapter works if there is no getter available
     * <P>
     * It does not (yet?) - so this test would fail if we didn't catch the exception.
     */
    public void testSetterWithoutGetter()
    {
        try 
        {
            TestDataObject tdo = new TestDataObject();
            MixedAccessAdapter adapter = new MixedAccessAdapter( "wOString");
            adapter.setValue( tdo, "Test");
            assertEquals( "value must be Test", "Test", tdo.getString());
            fail( "Surprise: apparently the MixedAccessAdapter works now with write only setters");
        }
        catch (Throwable ex)
        {
            // it is unfortunate, but we expected it since the feature does not exist yet
        }
    }
    
    /**
     * tests if the adapter works when there is a null value when
     * applying a getter chain.
     */
    public void testNullValueInChain()
    {
        TestDataObject tdo = new TestDataObject();
        tdo.setString( "Test");
        MixedAccessAdapter adapter = new MixedAccessAdapter( "string.bytes");
        assertEquals( "value must be correct", new String("Test".getBytes()), new String((byte[])adapter.getValue(tdo)));
        tdo.setString( null);
        assertNull( "value must be null", adapter.getValue(tdo));
    }
    
}
