package net.sf.cuf.model.converter;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import net.sf.cuf.model.ValueModel;

/**
 * Takes a {@link List} and filters the entries so that only those
 * which are accepted by the filter are returned in our own value {@link List}.
 * The order of the entries is unchanged.
 * The converter is read only.
 * The implementation is not optimized for settings where {@link #getValue()}
 * is called often.
 * @param <T> the type inside the list
 */
public class ListFilterConverter<T> extends AbstractTypeConverter<List<T>, List<T>>
{
    /** the filter we are using, may be null (which means all entries allowed) */
    private Filter<T> mFilter;

    /**
     * Constructor that initializes with no filter
     * @param pSubject the value model providing the {@link Collection}, must not be null
     */
    public ListFilterConverter(final ValueModel<List<T>> pSubject)
    {
        this(pSubject,null);
    }

    /**
     * Constructor that initializes with the given filter
     * @param pSubject the value model providing the {@link Collection}, must not be null
     * @param pFilter the filter to apply, may be null
     */
    public ListFilterConverter(final ValueModel<List<T>> pSubject, final Filter<T> pFilter)
    {
        super(pSubject);
        mFilter = pFilter;
    }

    /**
     * Return the current filter.
     * @return null or the current filter
     */
    public Filter<T> getFilter()
    {
        return mFilter;
    }
    
    /**
     * updates the filter we should use and notifies listeners
     * @param pFilter the filter to apply, may be null
     */
    public void setFilter(final Filter<T> pFilter)
    {
        mFilter = pFilter;
        fireStateChanged();
    }

    /**
     * throws an exception, since this converter is read only
     * @param pOwnValue not used
     * @return never an object
     * @throws ConversionException always
     */
    @SuppressWarnings({"UnusedDeclaration"})
    public List<T> convertOwnToSubjectValue(final List<T> pOwnValue) throws ConversionException
    {
        throw new ConversionException( "ListFilterConverter is read only", null);
    }

    /**
     * creates the list which contains only the elements that are accepted by the filter
     * {@inheritDoc}
     */
    public List<T> convertSubjectToOwnValue(final List<T> pSubjectValue) throws ConversionException
    {
        if (pSubjectValue==null)
        {
            return null;
        }
        if (mFilter==null)
        {
            return new ArrayList(pSubjectValue);
        }
        List<T> result = new ArrayList(pSubjectValue.size());
        for (final T entry : pSubjectValue)
        {
            if (mFilter.accept(entry))
            {
                result.add(entry);
            }
        }
        return result;
    }
    
    /**
     * filter interface for the {@link ListFilterConverter}
     */
    public interface Filter<T>
    {
        /**
         * determines if the given entry should be included in the resulting list
         * @param pEntry the entry in the original list
         * @return true if the entry should be included in the filtered list
         */
        public boolean accept(T pEntry);
    }

}
