package net.sf.cuf.model;

/**
 * A ValueHolder object holds a value (any Object) determined
 * by the constructor. The value can
 * be accessed via getValue() but not be changed via setValue().
 * However, if the value is an object with attributes, the object's
 * value may be changed.
 * If that happens, you should call {@link #signalExternalUpdate()}
 * afterwards so the listeners can be notified.
 * @param <T> the type we hold
 */
public class UnmodifiableValueHolder<T> extends AbstractValueModel<T> implements DelegateAccess
{
    /** our value, may be null */
    private T  mValue;

    /**
     * Create a new holder with NULL as its value.
     */
    public UnmodifiableValueHolder()
    {
        this(null);
    }

    /**
     * Create a new holder with the handed object as its value.
     * @param pValue the value we hold, may be null
     */
    public UnmodifiableValueHolder(final T pValue)
    {
        super();
        mValue= pValue;
    }

    /**
     * Returns always false
     * @return false
     */
    public boolean isEditable()
    {
        return false;
    }

    /**
     * Throws an exception.
     * @param pValue ignored
     * @param pIsSetForced ignored
     * @throws UnsupportedOperationException always
     */
    public void setValue(final T pValue, final boolean pIsSetForced)
    {
        throw new UnsupportedOperationException( "UnmodifiableValueHolder does not support setValue");
    }

    /**
     * Get the current value, during a callback this is the new value.
     * @return null or the value object
     */
    public T getValue()
    {
        checkDisposed();
        return mValue;
    }

    /**
     * Transform the handed value to a new value.
     * This should not change the current value or trigger any updates.
     * @param pValue the value we should assume as our value
     * @return pValue
     */
    public Object getValue(final Object pValue)
    {
        checkDisposed();
        return pValue;
    }
}
