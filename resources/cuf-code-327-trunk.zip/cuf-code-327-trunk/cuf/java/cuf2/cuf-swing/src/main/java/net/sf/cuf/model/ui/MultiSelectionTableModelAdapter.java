package net.sf.cuf.model.ui;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.EventListenerList;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.TableModel;

import net.sf.cuf.model.DelegateAccess;
import net.sf.cuf.model.MultiSelectionInList;
import net.sf.cuf.model.ui.ListTableMapper.Mapping;
import net.sf.cuf.model.ui.ListTableMapperBase.IdentityIndexConverter;
import net.sf.cuf.ui.builder.SwingXMLBuilder;

/**
 * This class maps the content of List of a {@link MultiSelectionInList} ValueModel to a
 * JTable TableModel and ListSelectionModel.<br/>
 * This is the multi selection version of the {@link ListTableMapper}.
 * <P>
 * Each entry in the list of the {@link MultiSelectionInList} ValueModel describes a
 * row, all entries are assumed to be objects from the same class/interface.
 * Whenever the either the list or the selection changes, the table is
 * adjusted accordingly.
 * The table data is read-only, when the user changes the selection in the
 * table, the selection of the {@link MultiSelectionInList} is changed accordingly.
 * <P>
 * The initial selection is taken from the {@link MultiSelectionInList} value model.
 * 
 * FIXME: currently we never unregister from the MultiSelectionInList value model,
 * this might lead to memory leaks.
 */
public class MultiSelectionTableModelAdapter implements TableModel, ListSelectionListener
{
    // NOTE:
    // Most of the code is copied from ListTableMapper and ListTableMapperBase.
    // Everything around the Adapters between combos, lists, tables and value models 
    // feels like it needs a major overhaul or at least some face lifting.
    // Comments in the other classes are not accurate and code is very 'grown'.
    
    /** our JTable, never null */
    private   JTable               mTable;
    /** value model holding the list, never null */
    protected MultiSelectionInList mMultiSelectionInList;
    /** helper for the TableModel callback handling */
    private   EventListenerList    mListenerList;
    /** marker if we are inside a selection change, we then ignore selection
      * changes from the "other" model */
    private   boolean              mInSelectionChange;
    /** a IndexConverter maps the view index to the model index and vice versa, never null */
    private   IndexConverter       mIndexConverter;
    /** List of Mapping objects, contains a DelegateAccess object
      * or each column, never null */
    private List<Mapping>          mColumnMapping;

    /** the shared identity converter */
    private static final IndexConverter IDENTITY_CONVERTER= new IdentityIndexConverter();
    /** shared no params array */
    private static final Class<?>[]     NO_PARAMS = {};
    /** shared no args array */
    private static final Object[]       NO_ARGS = {};

    /**
     * Create a new adaption object between a JTable and a {@link MultiSelectionInList} value model.
     * This object is also set as the JTable's TableModel.
     * @param pTable the table for which we provide TableModel behaviour and connect to the {@link ListSelectionModel} 
     * @param pValueModel the value model that drives the table (data, selection)
     *                    and gets updated by the table (selection only)
     * @param pMapping non-null List containing {@link Mapping} objects
     * @param pSortable true if table is sortable
     * @throws IllegalArgumentException if a parameter is bogus
     */
    public MultiSelectionTableModelAdapter(final JTable pTable, final MultiSelectionInList pValueModel, final List<Mapping> pMapping, final boolean pSortable)
    {
       this(pTable, pValueModel, pMapping, pSortable, -1);
    }

    /**
     * Create a new adaption object between a JTable and a {@link MultiSelectionInList} value model.
     * This object is also set as the JTable's TableModel.
     * @param pTable the table for which we provide TableModel behaviour and connect to the {@link ListSelectionModel} 
     * @param pValueModel the value model that drives the table (data, selection)
     *                    and gets updated by the table (selection only)
     * @param pMapping non-null List containing {@link Mapping} objects
     * @param pSortable true if table is sortable
     * @param pColumnForInitialSorting -1 or the column index for initial sorting
     * @throws IllegalArgumentException if a parameter is bogus
     */
    public MultiSelectionTableModelAdapter(final JTable pTable, final MultiSelectionInList pValueModel, final List<Mapping> pMapping,
                           final boolean pSortable, final int pColumnForInitialSorting)
    {
        mColumnMapping= Collections.emptyList();
        init(pTable, pValueModel);
        setColumnMapping(pTable, pMapping, pSortable, pColumnForInitialSorting);
    }

    /*
     * "our" handling code (=no Swing or ValueModel callback/handling stuff)
     */

    /**
     * Common construction stuff, it creates a new adaption between
     * a JTable and a {@link MultiSelectionInList} value model.
     * This object is also set as the JTable's TableModel.
     * @param pTable the table for which we provide TableModel behaviour and connect to the {@link ListSelectionModel} 
     * @param pValueModel the value model that drives the table (data, selection)
     *                    and gets updated by the table (selection only)
     * @throws IllegalArgumentException if a parameter is bogus
     */
    protected void init(final JTable pTable, final MultiSelectionInList pValueModel)
    {
        if (pTable==null)
        {
            throw new IllegalArgumentException("the table must not be null");
        }
        if (pValueModel==null)
        {
            throw new IllegalArgumentException("the value model must not be null");
        }

        mTable                 = pTable;
        mMultiSelectionInList       = pValueModel;
        mListenerList          = new EventListenerList();
        mInSelectionChange     = false;
        mIndexConverter        = IDENTITY_CONVERTER;

        // this must stay at the end so that everything is setup first
        mMultiSelectionInList.onChangeSend                  (this, "vmDataChanged");
        mMultiSelectionInList.getSelectedIndexSetValueModel().onChangeSend(this, "vmSelectionChanged");
        pTable.setModel         (this);
        pTable.getSelectionModel().addListSelectionListener(this);
    }

    /**
     * The method maps the attributes of our List entry class to column names
     * in the table and the alignments of the columns.
     * @param pTable the table for which we set the column alignments
     * @param pMapping non-null List containing {@link Mapping} objects
     * @param pSortable true if table is sortable
     * @param pColumnForInitialSorting -1 or the column index for initial sorting
     * @throws IllegalArgumentException if pMapping is null or contains invalid mappings
     */
    private void setColumnMapping(final JTable pTable, final List<Mapping> pMapping, final boolean pSortable, final int pColumnForInitialSorting)
    {
        if (pMapping==null)
        {
            throw new IllegalArgumentException("mapping must not be null");
        }

        List<Mapping> columnMapping= new ArrayList<Mapping>(pMapping.size());
        for (int i = 0, n = pMapping.size(); i < n; i++)
        {
            Mapping mapping  = pMapping.get(i);
            Mapping myMapping= new Mapping(mapping);
            columnMapping.add(myMapping);
        }
        mColumnMapping= columnMapping;

        // notify the table to re-create the columns
        TableModelEvent e= new TableModelEvent(this, TableModelEvent.HEADER_ROW);
        fireTableChanged(e);

        // make table sortable with a NewTabelSorter-TableModel
        if (pSortable)
        {
            NewTableSorter sorter = new NewTableSorter(pTable.getModel());
            sorter.setTableHeader(pTable.getTableHeader());
            pTable.setModel(sorter);

            setIndexConverter(sorter);

            // add Comparator for sorting, if necessary
            for (int i = 0, n = pMapping.size(); i < n; i++)
            {
                Mapping mapping= pMapping.get(i);

                if(mapping.getComparatorClass() != null)
                {
                    try
                    {
                        Comparator<?> myComparator =
                            (Comparator<?>) mapping
                                .getComparatorClass()
                                .getConstructor(NO_PARAMS)
                                .newInstance(NO_ARGS);

                        sorter.setColumnComparator(mapping.getColumnClass(), myComparator);
                    }
                    catch (Exception e1)
                    {
                        throw SwingXMLBuilder.createException("could not instantiate ComparatorClass "
                                + mapping.getComparatorClass() + " for "
                                + mapping.getColumnClass(), e1);
                    }
                }
            }

            // force initial sorting
            if(pColumnForInitialSorting >= 0 && pColumnForInitialSorting < sorter.getColumnCount())
            {
                sorter.forceInitialSorting(pColumnForInitialSorting);
            }
        }

        for (int i = 0, n = pMapping.size(); i < n; i++)
        {
            Mapping mapping  = pMapping.get(i);

            // set defined column alignment
            if(mapping.getColumnAlignment() != null)
            {
                pTable.getColumnModel().getColumn(i).setCellRenderer(
                    new ColumnAlignmentRenderer(mapping.getColumnAlignment()));
            }
            else
            {
                // if no alignment defined: set default-alignment per column-class
                if(mapping.getColumnClass() != null
                   && Boolean.class.isAssignableFrom(mapping.getColumnClass()))
                {
                    pTable.getColumnModel().getColumn(i).setCellRenderer(
                        new ColumnAlignmentRenderer(ColumnAlignmentRenderer.ALIGN_CENTER));
                }
                else if(mapping.getColumnClass() != null
                        && (Number.class.isAssignableFrom(mapping.getColumnClass())
                            || Date.class.isAssignableFrom(mapping.getColumnClass())))
                {
                    pTable.getColumnModel().getColumn(i).setCellRenderer(
                        new ColumnAlignmentRenderer(ColumnAlignmentRenderer.ALIGN_RIGHT));
                }
                else
                {
                    pTable.getColumnModel().getColumn(i).setCellRenderer(
                        new ColumnAlignmentRenderer(ColumnAlignmentRenderer.ALIGN_LEFT));
                }
            }

            // set prefered width for table columns
            if(mapping.getColumnPrefWidthIntValue() > 0)
            {
                // if we don't disable the auto resize, preferred with has no consequences
                pTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
                JTextField dummyTextField = new JTextField(mapping.getColumnPrefWidthIntValue());
                pTable.getColumnModel().getColumn(i).setPreferredWidth(dummyTextField.getPreferredSize().width);

            }
        }
    }

    /******************************************************************/

    /*
     * TableModel callbacks
     */

    public int getColumnCount()
    {
        return mColumnMapping.size();
    }

    public String getColumnName(final int pColumnIndex)
    {
        return mColumnMapping.get(pColumnIndex).getColumnTitle();
    }

    public Class<?> getColumnClass(final int pColumnIndex)
    {
        Class<?> clazz= mColumnMapping.get(pColumnIndex).getColumnClass();
        if (clazz==null)
            clazz= Object.class;
        return clazz;
    }

    public Object getValueAt(final int pRowIndex, final int pColumnIndex)
    {
        Mapping        mapping   = mColumnMapping.get(pColumnIndex);
        DelegateAccess valueModel= mapping.getValueModel();
        List           list      = (List)mMultiSelectionInList.getValue();
        Object         value     = list.get(pRowIndex);
        Object         back      = valueModel.getValue(value);
        return back;
    }

    public Object getRawValueAt(final int pRowIndex, final int pColumnIndex)
    {
        List   list = (List)mMultiSelectionInList.getValue();
        Object value= list.get(pRowIndex);
        return value;
    }

    public Object getValueForSortingAt(final int pRowIndex, final int pColumnIndex)
    {
        Mapping        mapping             = mColumnMapping.get(pColumnIndex);
        DelegateAccess valueModelForSorting= mapping.getValueModelForSorting();
        List           list                = (List)mMultiSelectionInList.getValue();
        Object         value               = list.get(pRowIndex);
        Object         back                = valueModelForSorting.getValue(value);
        return back;
    }

    public boolean isColumnSortable(final int pColumnIndex)
    {
        Mapping mapping= mColumnMapping.get(pColumnIndex);
        return mapping.isSortable();
    }

    /**
     * Setter for IndexConverter.
     * @param pIndexConverter the new IndexConverter, must not be null
     */
    protected void setIndexConverter(final IndexConverter pIndexConverter)
    {
        if (pIndexConverter==null)
        {
            throw new IllegalArgumentException("IndexConverter must not be null");
        }
        mIndexConverter = pIndexConverter;
        vmSelectionChanged(new ChangeEvent(this));
    }
    
    /******************************************************************/
    /* Event handling code from the model                             */
    /******************************************************************/

    /**
     * Called whenever the data of the {@link MultiSelectionInList} changes.
     * @param pEvent not used
     */
    public void vmDataChanged(final ChangeEvent pEvent)
    {
        // ignore the changes we triggered
        if (mInSelectionChange)
        {
            return;
        }

        // notify the table to re-read the data, this will clear the selection,
        // so we re-set the selection afterwards
        
        mInSelectionChange= true;
        try
        {
            TableModelEvent e= new TableModelEvent(this);
            fireTableChanged(e);
            updateSelectionFromModel();
        }
        finally
        {
            mInSelectionChange= false;
        }
    }

    /**
     * Called whenever the selection of the SelectionInList changes.
     * @param pEvent not used
     */
    public void vmSelectionChanged(final ChangeEvent pEvent)
    {
        // ignore the changes we triggered
        if (mInSelectionChange)
        {
            return;
        }

        mInSelectionChange= true;
        try
        {
            updateSelectionFromModel();
        }
        finally
        {
            mInSelectionChange= false;
        }
    }

    /**
     * Helper method to update the selection in the table
     * based on the current selection in the model.
     * The call to this method should be wrapped in
     * checking {@link #mInSelectionChange}.
     */
    private void updateSelectionFromModel()
    {
        // Note: the code here is helpless when the model selection
        // is incompatible with the selection mode of the table.
        // (Since it can't correct the selection of the model.)
        // Note: because of the internal behaviour of the
        // DefaultListSelectionModel it is nearly impossible
        // to keep anchor and lead index the same. 
        // Right now we don't even try.
        Set selectedIndexes = (Set) mMultiSelectionInList.getSelectedIndexSetValueModel().getValue();
        ListSelectionModel selectionModel = mTable.getSelectionModel();
        selectionModel.clearSelection();
        for (final Object selectedIndexe : selectedIndexes)
        {
            Integer selectedIndex = (Integer) selectedIndexe;
            int viewIndex = mIndexConverter.convert2ViewIndex(selectedIndex);
            if (0 <= viewIndex && viewIndex < mTable.getRowCount())
            {
                selectionModel.addSelectionInterval(viewIndex, viewIndex);
            }
        }
    }

    /******************************************************************/
    /* Event handling code from the table                             */
    /******************************************************************/

    /**
     * Called whenever the selection of the JTable changes, we update
     * our SelectionInList index.
     * @param pEvent event describing the new selection
     */
    public void valueChanged(final ListSelectionEvent pEvent)
    {
        // ignore the changes we triggered
        if (mInSelectionChange)
        {
            return;
        }
        // ignore intermediate changes
        if (pEvent.getValueIsAdjusting())
        {
            return;
        }

        mInSelectionChange= true;
        try
        {
            // copy the current selection
            Set<Integer> selectionIndexSet = new HashSet<>((Set<Integer>) mMultiSelectionInList.getSelectedIndexSetValueModel().getValue());

            // try to determine the range to check
            int fromViewIndex = Math.max( 0, pEvent.getFirstIndex());
            int toViewIndex = Math.min( mTable.getRowCount()-1, pEvent.getLastIndex());
            if (fromViewIndex>toViewIndex)
            {
                // we can't use the range (inconsistent information)
                fromViewIndex = 0;
                toViewIndex = mTable.getRowCount()-1;
            }
            // I am fairly sure that we don't have to consider clearing
            // selected indexes outside of that range since we never get here
            // if the model changes and that makes sure the selection is consistent
            // with the data.
            for (int checkIndex = fromViewIndex; checkIndex <= toViewIndex; checkIndex++)
            {
                boolean selected = mTable.isRowSelected( checkIndex);
                int modelIndex = mIndexConverter.convert2ModelIndex( checkIndex);
                if (selected)
                {
                    selectionIndexSet.add( modelIndex);
                }
                else
                {
                    selectionIndexSet.remove( modelIndex);
                }
            }

            // now update in one call
            mMultiSelectionInList.setSelectedIndexes(selectionIndexSet);
        }
        finally
        {
            mInSelectionChange= false;
        }
    }

    /*
     * Swing TableModel methods
     */

    public int getRowCount()
    {
        List list= (List) mMultiSelectionInList.getValue();
        return list==null ? 0 : list.size();
    }

    public boolean isCellEditable(final int pRowIndex, final int pColumnIndex)
    {
        return false;
    }

    public void setValueAt(final Object pValue, final int pRowIndex, final int pColumnIndex)
    {
        throw new UnsupportedOperationException("this is a read-only table model");
    }

    public void addTableModelListener(final TableModelListener pTableModelListener)
    {
        mListenerList.add(TableModelListener.class, pTableModelListener);
    }

    public void removeTableModelListener(final TableModelListener pTableModelListener)
    {
        mListenerList.remove(TableModelListener.class, pTableModelListener);
    }

    protected void fireTableChanged(final TableModelEvent peEvent)
    {
        Object[] listeners = mListenerList.getListenerList();
        for (int i= listeners.length-2; i>=0; i-=2)
        {
            if (listeners[i]==TableModelListener.class)
            {
                ((TableModelListener)listeners[i+1]).tableChanged(peEvent);
            }
        }
    }

}
