package net.sf.cuf.model.ui;

import net.sf.cuf.model.ValueModel;

import javax.swing.JLabel;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;

/**
 * A LabelAdapter connects the value of a ValueModel to the
 * text a JLabel. This is a one way adapter, changes
 * of the text of the JLabel are not propagated to the
 * ValueModel.
 * The label text is initially set from the value model.
 */
public class LabelAdapter implements ChangeListener
{
    /** the value model we adapt to, never null */
    private ValueModel<?> mValueModel;
    /** the label we set the text, never null */
    private JLabel        mLabel;

    /**
     * Creates a new adapter between a ValueModel and a JLabel.
     * Whenever the ValueModel changes, the label text is adjusted accordingly.
     * @param pValueModel the value model, must not be null
     * @param pLabel the label, must not be null
     */
    public LabelAdapter(final ValueModel<?> pValueModel, final JLabel pLabel)
    {
        if (pValueModel==null)
            throw new IllegalArgumentException("value model must not be null");
        if (pLabel==null)
            throw new IllegalArgumentException("label must not be null");

        mValueModel= pValueModel;
        mLabel     = pLabel;
        stateChanged(null);
        mValueModel.addChangeListener(this);
    }

    /**
     * Invoked during construction or when the value model changed its state.
     * @param pEvent not used
     */
    public void stateChanged(final ChangeEvent pEvent)
    {
        Object value= mValueModel.getValue();
        String text= (value==null) ?  null : value.toString();
        mLabel.setText(text);
    }
}
