package net.sf.cuf.debug;

import net.sf.cuf.model.DelegateAccess;


public class ClassNameAdapter implements DelegateAccess
{

    public Object getValue(final Object pValue)
    {
        if (pValue==null)
        {
            return "";
        }
        String name = pValue.getClass().getName();
        String packageName = pValue.getClass().getPackage().getName();
        if (packageName.length()==0)
        {
            return name;
        }
        else
        {
            return name.substring( packageName.length()+1);
        }
    }

}
