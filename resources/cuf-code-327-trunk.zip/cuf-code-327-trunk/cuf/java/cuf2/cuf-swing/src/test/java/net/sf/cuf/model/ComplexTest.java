package net.sf.cuf.model;

import net.sf.cuf.model.converter.IntegerStringConverter;
import net.sf.cuf.model.converter.RegExpConverter;

import junit.framework.TestCase;

/**
 * some complex tests concerning the combination of various elements
 */
public class ComplexTest extends TestCase
{

    /**
     * tests the combination of the behaviour of an
     * {@link RegExpConverter} based on a {@link IntegerStringConverter} based on an {@link AspectAdapter}
     * for an int attribute.
     */
    public void testIntegerAndRegExp()
    {
        ValueHolder valueHolder = new ValueHolder();
        AspectAdapter intAspect = new AspectAdapter( valueHolder, TestDataObject.class, "int");
        IntegerStringConverter integerStringConverter = new IntegerStringConverter( intAspect, true);
        integerStringConverter.setNullSubstitute(0);
        RegExpConverter regExpConverter = new RegExpConverter( integerStringConverter, "[0-9]{1,2}", false);
        TestDataObject data = new TestDataObject();
        data.setInt( 17);
        valueHolder.setValue( data);
        assertEquals( "value must be correct", "17", regExpConverter.getValue());
        assertTrue( "integer must be in sync", integerStringConverter.getSyncState().booleanValue());
        assertTrue( "regExp must be in sync", regExpConverter.getSyncState().booleanValue());
        data = new TestDataObject();
        data.setInt( 100);
        valueHolder.setValue( data);
        assertEquals( "value must be correct", "100", regExpConverter.getValue());
        assertTrue( "integer must be in sync", integerStringConverter.getSyncState().booleanValue());
        assertFalse( "regExp must be out of sync", regExpConverter.getSyncState().booleanValue());
        regExpConverter.setValue( "25");
        assertEquals( "value must be correct", 25, data.getInt());
        assertTrue( "integer must be in sync", integerStringConverter.getSyncState().booleanValue());
        assertTrue( "regExp must be in sync", regExpConverter.getSyncState().booleanValue());
        regExpConverter.setValue( "101");
        assertEquals( "value must be correct", 101, data.getInt());
        assertTrue( "integer must be in sync", integerStringConverter.getSyncState().booleanValue());
        assertFalse( "regExp must be out of sync", regExpConverter.getSyncState().booleanValue());
        regExpConverter.setValue( "Murks");
        assertEquals( "value must be reset to 0", 0, data.getInt());
        assertFalse( "integer must be out of sync", integerStringConverter.getSyncState().booleanValue());
        assertFalse( "regExp must be out of sync", regExpConverter.getSyncState().booleanValue());
    }
    
}
