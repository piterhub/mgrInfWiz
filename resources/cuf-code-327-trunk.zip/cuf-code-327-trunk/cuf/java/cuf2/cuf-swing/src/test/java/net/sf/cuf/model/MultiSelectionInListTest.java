package net.sf.cuf.model;

import junit.framework.TestCase;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.SortedSet;
import java.util.TreeSet;

/**
 * tests {@link MultiSelectionInList}
 */
public class MultiSelectionInListTest extends TestCase
{

    public void testCreation()
    {
        {
            ValueModel<List<?>> baseListVM = new ValueHolder<>();
            MultiSelectionInList<?> multiSIL = new MultiSelectionInList<>(baseListVM);
            checkNoSelection(multiSIL);
        }

        {
            List<String> baseList = Arrays.asList("Some", "Values");
            ValueHolder<List<? extends String>> baseListVM = new ValueHolder<List<? extends String>>(baseList);
            MultiSelectionInList<String> multiSIL = new MultiSelectionInList<>(baseListVM);
            checkNoSelection(multiSIL);
            multiSIL = new MultiSelectionInList<>(baseList);
            checkNoSelection(multiSIL);
        }
    }
    
    public void testSelectionByIndex()
    {
        ValueHolder<List<? extends NamedObject>> baseListVM = new ValueHolder<>();
        NamedObject obj0 = new NamedObject( "obj0");
        NamedObject obj1 = new NamedObject( "obj1");
        NamedObject obj2 = new NamedObject( "obj2");
        List<NamedObject> baseList = Arrays.asList(obj0, obj1, obj2);
        baseListVM.setValue( baseList);
        
        MultiSelectionInList<NamedObject> multiSIL = new MultiSelectionInList<>( baseListVM);
        checkNoSelection(multiSIL);
        multiSIL.getSelectedIndexSetValueModel().getValue().add(0);
        checkSingleSelection( multiSIL, 0, obj0);
        
        multiSIL = new MultiSelectionInList<>( baseListVM);
        checkNoSelection(multiSIL);
        multiSIL.getSelectedIndexSetValueModel().getValue().add(1);
        checkSingleSelection( multiSIL, 1, obj1);
        
        multiSIL = new MultiSelectionInList<>( baseListVM);
        checkNoSelection(multiSIL);
        multiSIL.getSelectedIndexSetValueModel().getValue().add(2);
        checkSingleSelection( multiSIL, 2, obj2);
        
        multiSIL = new MultiSelectionInList<>( baseListVM);
        checkNoSelection(multiSIL);
        multiSIL.getSelectedIndexSetValueModel().getValue().add(1);
        checkSingleSelection( multiSIL, 1, obj1);
        multiSIL.getSelectedIndexSetValueModel().getValue().add(0);
        checkDoubleSelection( multiSIL, 0, obj0, 1, obj1);
        multiSIL.getSelectedIndexSetValueModel().getValue().add(2);
        checkTripleSelection( multiSIL, 0, obj0, 1, obj1, 2, obj2);
        multiSIL.getSelectedIndexSetValueModel().getValue().remove(new Integer(1));
        checkDoubleSelection( multiSIL, 0, obj0, 2, obj2);
        multiSIL.getSelectedIndexSetValueModel().getValue().remove(new Integer(0));
        checkSingleSelection( multiSIL, 2, obj2);
        multiSIL.getSelectedIndexSetValueModel().getValue().remove(new Integer(2));
        checkNoSelection(multiSIL);
        
        multiSIL = new MultiSelectionInList<>( baseListVM);
        checkNoSelection(multiSIL);
        multiSIL.setSelectedIndexes( Arrays.asList(1));
        checkSingleSelection( multiSIL, 1, obj1);
        multiSIL.setSelectedIndexes( Arrays.asList(2));
        checkSingleSelection( multiSIL, 2, obj2);
        multiSIL.setSelectedIndexes( Arrays.asList(0, 1));
        checkDoubleSelection( multiSIL, 0, obj0, 1, obj1);
        multiSIL.setSelectedIndexes( Arrays.<Integer>asList());
        checkNoSelection( multiSIL);
        
    }
    
    public void testSelectionByValue()
    {
        ValueModel<List<? extends NamedObject>> baseListVM = new ValueHolder<>();
        NamedObject obj0 = new NamedObject( "obj0");
        NamedObject obj1 = new NamedObject( "obj1");
        NamedObject obj2 = new NamedObject( "obj2");
        List<NamedObject> baseList = Arrays.asList(obj0, obj1, obj2);
        baseListVM.setValue( baseList);
        
        MultiSelectionInList<NamedObject> multiSIL = new MultiSelectionInList<>( baseListVM);
        checkNoSelection(multiSIL);
        multiSIL.getSelectedValuesHolder().getValue().add(obj0);
        checkSingleSelection( multiSIL, 0, obj0);
        
        multiSIL = new MultiSelectionInList<>( baseListVM);
        checkNoSelection(multiSIL);
        multiSIL.getSelectedValuesHolder().getValue().add(obj1);
        checkSingleSelection( multiSIL, 1, obj1);
        
        multiSIL = new MultiSelectionInList<>( baseListVM);
        checkNoSelection(multiSIL);
        multiSIL.getSelectedValuesHolder().getValue().add(obj2);
        checkSingleSelection( multiSIL, 2, obj2);
        
        multiSIL = new MultiSelectionInList<>( baseListVM);
        checkNoSelection(multiSIL);
        try
        {
            multiSIL.getSelectedValuesHolder().getValue().add(new NamedObject("obj2"));
            fail( "exception expected for unkown object");
        } 
        catch (RuntimeException expected)
        {
            // this is ok
        }
        checkNoSelection(multiSIL);
        
        multiSIL = new MultiSelectionInList<>( baseListVM);
        checkNoSelection(multiSIL);
        multiSIL.getSelectedValuesHolder().getValue().add(obj1);
        checkSingleSelection( multiSIL, 1, obj1);
        multiSIL.getSelectedValuesHolder().getValue().add(obj0);
        checkDoubleSelection( multiSIL, 0, obj0, 1, obj1);
        multiSIL.getSelectedValuesHolder().getValue().add(obj2);
        checkTripleSelection( multiSIL, 0, obj0, 1, obj1, 2, obj2);
        multiSIL.getSelectedValuesHolder().getValue().remove( obj1);
        checkDoubleSelection( multiSIL, 0, obj0, 2, obj2);
        multiSIL.getSelectedValuesHolder().getValue().remove(obj0);
        checkSingleSelection( multiSIL, 2, obj2);
        multiSIL.getSelectedValuesHolder().getValue().remove( obj2);
        checkNoSelection(multiSIL);
        
        multiSIL = new MultiSelectionInList<>( baseListVM);
        CallbackTarget selIndexCallbackTarget = new CallbackTarget();
        multiSIL.getSelectedIndexSetValueModel().addChangeListener( selIndexCallbackTarget);
        CallbackTarget selValueCallbackTarget = new CallbackTarget();
        multiSIL.getSelectedValuesHolder().addChangeListener( selValueCallbackTarget);
        checkNoSelection(multiSIL);
        assertFalse( "no change notified", selIndexCallbackTarget.isStateChangedCalled());
        assertFalse( "no change notified", selValueCallbackTarget.isStateChangedCalled());
        
        multiSIL.setSelectedElements( Arrays.asList(obj1));
        checkSingleSelection( multiSIL, 1, obj1);
        assertTrue( "change notified", selIndexCallbackTarget.isStateChangedCalled());
        assertTrue( "change notified", selValueCallbackTarget.isStateChangedCalled());
        selIndexCallbackTarget.reset();
        selValueCallbackTarget.reset();
        
        multiSIL.setSelectedElements( Arrays.asList(obj2));
        checkSingleSelection( multiSIL, 2, obj2);
        assertTrue( "change notified", selIndexCallbackTarget.isStateChangedCalled());
        assertTrue( "change notified", selValueCallbackTarget.isStateChangedCalled());
        selIndexCallbackTarget.reset();
        selValueCallbackTarget.reset();
        
        multiSIL.setSelectedElements( Arrays.asList(obj0, obj1));
        checkDoubleSelection( multiSIL, 0, obj0, 1, obj1);
        assertTrue( "change notified", selIndexCallbackTarget.isStateChangedCalled());
        assertTrue( "change notified", selValueCallbackTarget.isStateChangedCalled());
        selIndexCallbackTarget.reset();
        selValueCallbackTarget.reset();
        
        multiSIL.setSelectedElements( Arrays.<NamedObject>asList());
        checkNoSelection( multiSIL);
        assertTrue( "change notified", selIndexCallbackTarget.isStateChangedCalled());
        assertTrue( "change notified", selValueCallbackTarget.isStateChangedCalled());
        selIndexCallbackTarget.reset();
        selValueCallbackTarget.reset();
    }
    
    public void testSelectionByValueWithEquals()
    {
        ValueHolder<List<? extends NamedObject>> baseListVM = new ValueHolder<>();
        NamedObject obj0 = new NamedObject( "obj0");
        NamedObject obj1 = new NamedObject( "obj1");
        NamedObject obj2 = new NamedObject( "obj2");
        List<NamedObject> baseList = Arrays.asList(obj0, obj1, obj2);
        baseListVM.setValue( baseList);
        
        MultiSelectionInList<NamedObject> multiSIL = new MultiSelectionInList<>( baseListVM);
        multiSIL.setSelectionComparator( MultiSelectionInList.EQUALS_COMPARATOR);
        checkNoSelection(multiSIL);
        multiSIL.getSelectedValuesHolder().getValue().add( new NamedObject( "obj0"));
        checkSingleSelection( multiSIL, 0, obj0);
        
        multiSIL = new MultiSelectionInList<>( baseListVM);
        multiSIL.setSelectionComparator( MultiSelectionInList.EQUALS_COMPARATOR);
        checkNoSelection(multiSIL);
        multiSIL.getSelectedValuesHolder().getValue().add( new NamedObject( "obj1"));
        checkSingleSelection( multiSIL, 1, obj1);
        
        multiSIL = new MultiSelectionInList<>( baseListVM);
        multiSIL.setSelectionComparator( MultiSelectionInList.EQUALS_COMPARATOR);
        checkNoSelection(multiSIL);
        multiSIL.getSelectedValuesHolder().getValue().add( new NamedObject( "obj2"));
        checkSingleSelection( multiSIL, 2, obj2);
        
        multiSIL = new MultiSelectionInList<>( baseListVM);
        multiSIL.setSelectionComparator( MultiSelectionInList.EQUALS_COMPARATOR);
        checkNoSelection(multiSIL);
        try
        {
            multiSIL.getSelectedValuesHolder().getValue().add( new NamedObject( "hugo"));
            fail( "exception expected for unkown object");
        } 
        catch (RuntimeException expected)
        {
            // this is ok
        }
        checkNoSelection(multiSIL);
        
        multiSIL = new MultiSelectionInList<>( baseListVM);
        multiSIL.setSelectionComparator( MultiSelectionInList.EQUALS_COMPARATOR);
        checkNoSelection(multiSIL);
        multiSIL.getSelectedValuesHolder().getValue().add(new NamedObject("obj1"));
        checkSingleSelection( multiSIL, 1, obj1);
        multiSIL.getSelectedValuesHolder().getValue().add(new NamedObject("obj0"));
        checkDoubleSelection( multiSIL, 0, obj0, 1, obj1);
        multiSIL.getSelectedValuesHolder().getValue().add(new NamedObject("obj2"));
        checkTripleSelection( multiSIL, 0, obj0, 1, obj1, 2, obj2);
        ((List)multiSIL.getSelectedValuesHolder().getValue()).remove( new NamedObject( "obj1"));
        checkDoubleSelection( multiSIL, 0, obj0, 2, obj2);
        ((List)multiSIL.getSelectedValuesHolder().getValue()).remove( new NamedObject( "obj0"));
        checkSingleSelection( multiSIL, 2, obj2);
        ((List)multiSIL.getSelectedValuesHolder().getValue()).remove( new NamedObject( "obj2"));
        checkNoSelection(multiSIL);
        
        multiSIL = new MultiSelectionInList<>( baseListVM);
        multiSIL.setSelectionComparator( MultiSelectionInList.EQUALS_COMPARATOR);
        CallbackTarget selIndexCallbackTarget = new CallbackTarget();
        multiSIL.getSelectedIndexSetValueModel().addChangeListener( selIndexCallbackTarget);
        CallbackTarget selValueCallbackTarget = new CallbackTarget();
        multiSIL.getSelectedValuesHolder().addChangeListener( selValueCallbackTarget);
        checkNoSelection(multiSIL);
        assertFalse( "no change notified", selIndexCallbackTarget.isStateChangedCalled());
        assertFalse( "no change notified", selValueCallbackTarget.isStateChangedCalled());
        
        multiSIL.setSelectedElements( Arrays.asList(new NamedObject( "obj1")));
        checkSingleSelection( multiSIL, 1, obj1);
        assertTrue( "change notified", selIndexCallbackTarget.isStateChangedCalled());
        assertTrue( "change notified", selValueCallbackTarget.isStateChangedCalled());
        selIndexCallbackTarget.reset();
        selValueCallbackTarget.reset();
        
        multiSIL.setSelectedElements( Arrays.asList(new NamedObject( "obj2")));
        checkSingleSelection( multiSIL, 2, obj2);
        assertTrue( "change notified", selIndexCallbackTarget.isStateChangedCalled());
        assertTrue( "change notified", selValueCallbackTarget.isStateChangedCalled());
        selIndexCallbackTarget.reset();
        selValueCallbackTarget.reset();
        
        multiSIL.setSelectedElements( Arrays.asList(new NamedObject( "obj0"), new NamedObject( "obj1")));
        checkDoubleSelection( multiSIL, 0, obj0, 1, obj1);
        assertTrue( "change notified", selIndexCallbackTarget.isStateChangedCalled());
        assertTrue( "change notified", selValueCallbackTarget.isStateChangedCalled());
        selIndexCallbackTarget.reset();
        selValueCallbackTarget.reset();
        
        multiSIL.setSelectedElements(Arrays.<NamedObject>asList());
        checkNoSelection( multiSIL);
        assertTrue( "change notified", selIndexCallbackTarget.isStateChangedCalled());
        assertTrue( "change notified", selValueCallbackTarget.isStateChangedCalled());
        selIndexCallbackTarget.reset();
        selValueCallbackTarget.reset();
    }
    
    public void testBaseListChange()
    {
        ValueHolder<List<? extends NamedObject>> baseListVM = new ValueHolder<>();
        NamedObject obj0 = new NamedObject( "obj0");
        NamedObject obj1 = new NamedObject( "obj1");
        NamedObject obj2 = new NamedObject( "obj2");
        List<NamedObject> baseList = new ArrayList<>( Arrays.asList(obj0, obj1, obj2));
        baseListVM.setValue( baseList);
        
        MultiSelectionInList<NamedObject> multiSIL = new MultiSelectionInList<>( baseListVM);
        checkNoSelection(multiSIL);
        multiSIL.getSelectedValuesHolder().getValue().add(obj0);
        checkSingleSelection(multiSIL, 0, obj0);
        baseListVM.setValue(null);
        checkNoSelection(multiSIL);
        
        baseListVM.setValue( baseList);
        multiSIL = new MultiSelectionInList<>( baseListVM);
        checkNoSelection(multiSIL);
        multiSIL.getSelectedValuesHolder().getValue().add(obj2);
        multiSIL.getSelectedValuesHolder().getValue().add(obj1);
        multiSIL.getSelectedValuesHolder().getValue().add(obj0);
        checkTripleSelection( multiSIL, 0, obj0, 1, obj1, 2, obj2);
        baseList.remove( obj1);
        baseListVM.signalExternalUpdate();
        checkDoubleSelection( multiSIL, 0, obj0, 1, obj2);
        Collections.reverse( baseList);
        baseListVM.signalExternalUpdate();
        checkDoubleSelection( multiSIL, 0, obj2, 1, obj0);
        baseList = Arrays.asList(obj1, obj0);
        baseListVM.setValue( baseList);
        checkSingleSelection( multiSIL, 1, obj0);
    }
    
    public void testBaseListChangeWithEquals()
    {
        ValueHolder<List<? extends NamedObject>> baseListVM = new ValueHolder<>();
        NamedObject obj0 = new NamedObject( "obj0");
        NamedObject obj1 = new NamedObject( "obj1");
        NamedObject obj2 = new NamedObject( "obj2");
        List<NamedObject> baseList = new ArrayList<>( Arrays.asList(obj0, obj1, obj2));
        baseListVM.setValue( baseList);

        MultiSelectionInList<NamedObject> multiSIL = new MultiSelectionInList<>( baseListVM);
        multiSIL.setSelectionComparator( MultiSelectionInList.EQUALS_COMPARATOR);
        checkNoSelection(multiSIL);
        multiSIL.getSelectedValuesHolder().getValue().add(obj0);
        checkSingleSelection(multiSIL, 0, obj0);
        baseListVM.setValue(null);
        checkNoSelection(multiSIL);
        
        baseListVM.setValue( baseList);
        multiSIL = new MultiSelectionInList<>( baseListVM);
        multiSIL.setSelectionComparator(MultiSelectionInList.EQUALS_COMPARATOR);
        checkNoSelection(multiSIL);
        multiSIL.getSelectedValuesHolder().getValue().add(obj2);
        multiSIL.getSelectedValuesHolder().getValue().add(obj1);
        multiSIL.getSelectedValuesHolder().getValue().add(obj0);
        checkTripleSelection( multiSIL, 0, obj0, 1, obj1, 2, obj2);
        baseList.remove( obj1);
        baseListVM.signalExternalUpdate();
        checkDoubleSelection( multiSIL, 0, obj0, 1, obj2);
        Collections.reverse( baseList);
        baseListVM.signalExternalUpdate();
        checkDoubleSelection( multiSIL, 0, obj2, 1, obj0);
        NamedObject newObj0 = new NamedObject( "obj0");
        NamedObject newObj1 = new NamedObject( "obj1");
        baseList = Arrays.asList(newObj1, newObj0);
        baseListVM.setValue( baseList);
        checkSingleSelection( multiSIL, 1, newObj0);
    }
    
    public void testSelectAll()
    {
        ValueHolder<List<? extends NamedObject>> baseListVM = new ValueHolder<>();
        NamedObject obj0 = new NamedObject( "obj0");
        NamedObject obj1 = new NamedObject( "obj1");
        NamedObject obj2 = new NamedObject( "obj2");
        List<NamedObject> baseList = new ArrayList<>( Arrays.asList(obj0, obj1, obj2));
        baseListVM.setValue( baseList);

        MultiSelectionInList<NamedObject> multiSIL = new MultiSelectionInList<>( baseListVM);
        checkNoSelection(multiSIL);
        multiSIL.selectAll();
        checkTripleSelection( multiSIL, 0, obj0, 1, obj1, 2, obj2);
    }
    
    public void testClearSelection()
    {
        ValueHolder<List<? extends NamedObject>> baseListVM = new ValueHolder<>();
        NamedObject obj0 = new NamedObject( "obj0");
        NamedObject obj1 = new NamedObject( "obj1");
        NamedObject obj2 = new NamedObject( "obj2");
        List<NamedObject> baseList = new ArrayList<>( Arrays.asList(obj0, obj1, obj2));
        baseListVM.setValue( baseList);

        MultiSelectionInList<NamedObject> multiSIL = new MultiSelectionInList<>( baseListVM);
        multiSIL.getSelectedValuesHolder().getValue().add( obj1);
        checkSingleSelection( multiSIL, 1, obj1);
        multiSIL.clearSelection();
        checkNoSelection(multiSIL);
    }
    
    public void testMultipleIdenticalValuesInSelectedList()
    {
        // TODO
    }
    
    public void testNullInList()
    {
        // TODO
    }
    
	/**
     * checks if the given selection is empty
     * @param pMultiSIL the selection VM
     */
    private void checkNoSelection( final MultiSelectionInList pMultiSIL)
    {
        SortedSet indexSet = (SortedSet) pMultiSIL.getSelectedIndexSetValueModel().getValue();
        List valueList = (List) pMultiSIL.getSelectedValuesHolder().getValue();
        assertTrue( "index set must be empty", indexSet.isEmpty());
        assertTrue( "list must be empty", valueList.isEmpty());
    }
    
    /**
     * checks if the selection contains correctly one element with
     * the given index and the given value
     * @param pMultiSIL the selection VM
     * @param pIndex the correct index
     * @param pObj the correct object
     */
    private void checkSingleSelection(final MultiSelectionInList pMultiSIL, final int pIndex, final Object pObj)
    {
        SortedSet indexSet = (SortedSet) pMultiSIL.getSelectedIndexSetValueModel().getValue();
        List valueList = (List) pMultiSIL.getSelectedValuesHolder().getValue();
        assertEquals( "index set must be correct size", 1, indexSet.size());
        assertEquals( "list must be correct size", 1, valueList.size());
        assertEquals( "index must be correct", pIndex, ((Integer) indexSet.first()).intValue());
        assertSame( "list must have correct entry", pObj, valueList.get(0));
    }

    /**
     * checks if the selection contains correctly two element with
     * the given index and the given values
     * @param pMultiSIL the selection VM
     * @param pIndex0 the correct index for the first element
     * @param pObj0 the correct object for the first element
     * @param pIndex1 the correct index for the second element
     * @param pObj1 the correct object for the second element
     */
    private void checkDoubleSelection(final MultiSelectionInList<?> pMultiSIL, final int pIndex0, final Object pObj0, final int pIndex1, final Object pObj1)
    {
        SortedSet<Integer> indexSet = pMultiSIL.getSelectedIndexSetValueModel().getValue();
        List<Integer> indexAsList = new ArrayList<>( indexSet);
        List<?> valueList = pMultiSIL.getSelectedValuesHolder().getValue();
        assertEquals( "index set must be correct size", 2, indexSet.size());
        assertEquals( "list must be correct size", 2, valueList.size());
        assertEquals( "index 0 must be correct", pIndex0, indexAsList.get(0).intValue());
        assertSame( "list value 0 must be correct", pObj0, valueList.get(0));
        assertEquals( "index 1 must be correct", pIndex1, indexAsList.get(1).intValue());
        assertSame( "list value 1 must be correct", pObj1, valueList.get(1));
    }

    /**
     * checks if the selection contains correctly two element with
     * the given index and the given values
     * @param pMultiSIL the selection VM
     * @param pIndex0 the correct index for the first element
     * @param pObj0 the correct object for the first element
     * @param pIndex1 the correct index for the second element
     * @param pObj1 the correct object for the second element
     * @param pIndex2 the correct index for the third element
     * @param pObj2 the correct object for the third element
     */
    private void checkTripleSelection(final MultiSelectionInList<?> pMultiSIL, final int pIndex0, final Object pObj0, final int pIndex1, final Object pObj1, final int pIndex2, final Object pObj2)
    {
        SortedSet<Integer> indexSet = pMultiSIL.getSelectedIndexSetValueModel().getValue();
        List<Integer> indexAsList = new ArrayList<>( indexSet);
        List<?> valueList = pMultiSIL.getSelectedValuesHolder().getValue();
        assertEquals( "index set must be correct size", 3, indexSet.size());
        assertEquals( "list must be correct size", 3, valueList.size());
        assertEquals( "index 0 must be correct", pIndex0, indexAsList.get(0).intValue());
        assertSame( "list value 0 must be correct", pObj0, valueList.get(0));
        assertEquals( "index 1 must be correct", pIndex1, indexAsList.get(1).intValue());
        assertSame( "list value 1 must be correct", pObj1, valueList.get(1));
        assertEquals( "index 2 must be correct", pIndex2, indexAsList.get(2).intValue());
        assertSame( "list value 2 must be correct", pObj2, valueList.get(2));
    }

    /**
     * tests if the selected values and indexes can be serialized
     */
    public void testSerializationOfSelection()
    {
        ValueHolder<List<? extends NamedObject>> baseListVM = new ValueHolder<>();
        NamedObject obj0 = new NamedObject("obj0");
        NamedObject obj1 = new NamedObject("obj1");
        NamedObject obj2 = new NamedObject("obj2");
        List<NamedObject> baseList = new ArrayList<>(Arrays.asList(obj0, obj1, obj2));
        baseListVM.setValue(baseList);

        MultiSelectionInList<NamedObject> multiSIL = new MultiSelectionInList<>(baseListVM);
        multiSIL.getSelectedValuesHolder().getValue().add(obj0);
        multiSIL.getSelectedValuesHolder().getValue().add(obj1);
        multiSIL.getSelectedValuesHolder().getValue().add(obj2);

        List serializedValues = (List) attemptSerializationAndCheck(multiSIL
                .getSelectedValuesHolder().getValue());
        assertEquals(Arrays.asList(obj0, obj1, obj2), serializedValues);
        SortedSet serializedIndexes = (SortedSet) attemptSerializationAndCheck(multiSIL
                .getSelectedIndexSetValueModel().getValue());
        assertEquals(new TreeSet<>(Arrays.asList(0, 1, 2)), serializedIndexes);
    }

    /**
     * serializes and deserializes the given object
     * 
     * @param pValue the object to test 
     * @return the object after serialization and deserialization
     */
    private Object attemptSerializationAndCheck(Object pValue)
    {
        Object result;
        try
        {
            ByteArrayOutputStream bOut = new ByteArrayOutputStream();
            ObjectOutputStream oOut = new ObjectOutputStream(bOut);
            oOut.writeObject(pValue);
            oOut.close();
            ByteArrayInputStream bIn = new ByteArrayInputStream(bOut.toByteArray());
            ObjectInputStream oIn = new ObjectInputStream(bIn);
            result = oIn.readObject();
            oIn.close();
        }
        catch (ClassNotFoundException | IOException e)
        {
            throw new RuntimeException("Error in serialization: "+e,e);
        }
        return result;
    }

    private static class NamedObject implements Serializable 
    {
        private String mName;
        public NamedObject( final String pName)
        {
            mName = pName;
        }
        public String toString()
        {
            return mName;
        }
        public int hashCode()
        {
            return mName.hashCode();
        }
        public boolean equals(final Object pObj)
        {
            return mName.equals( ((NamedObject)pObj).mName);
        }
    }
}
