package net.sf.cuf.model.state;

import net.sf.cuf.model.AbstractValueModel;
import net.sf.cuf.model.ValueModel;
import net.sf.cuf.state.State;
import net.sf.cuf.state.MutableState;

import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;

/**
 * A StateValue object wraps a State object as a ValueModel.
 * Whenever the State object changes, we fire a ChangeEvent, too.
 */
public class StateValue extends AbstractValueModel<Boolean> implements ValueModel<Boolean>, ChangeListener
{
    /** the State we wrap */
    private State        mState;
    /** null or mState, if mState is mutable */
    private MutableState mMutableState;

    /**
     * We wrap a State object as a ValueModel.
     * @param pState  state we wrap, must not be null
     * @throws IllegalArgumentException if pState is null
     */
    public StateValue(final State pState)
    {
        if (pState==null)
            throw new IllegalStateException("state must not be null");

        mState= pState;
        if (mState instanceof MutableState)
        {
            mMutableState= (MutableState) mState;
        }
        setInSetValue(false, false);

        mState.addChangeListener(this);
    }

    /**
     * Returns true if our backing state is mutable.
     * @return true if setValue() can be called
     */
    public boolean isEditable()
    {
        return (mMutableState!=null);
    }

    /**
     * Cleanup all resources: disconnect from any input sources (like
     * other ValueModel's ...), and remove all listeners.
     */
    public void dispose()
    {
        super.dispose();
        if (!mState.isDisposed())
        {
            mState.removeChangeListener(this);
        }
    }

    /**
     * Invoked when the target of the listener has changed its state.
     *
     * @param pEvent  a ChangeEvent object
     */
    public void stateChanged(final ChangeEvent pEvent)
    {
        checkDisposed();
        if (isInSetValue())
        {
            return;
        }
        fireStateChanged();
    }

    /**
     * Return the state we wrap.
     * @return the state we wrap, never null
     */
    public State getState()
    {
        checkDisposed();
        return mState;
    }

    /**
     * Set a new value, this will fire a ChangeEvent if the new value
     * is different from the old value.
     * @param pValue the new Boolean value (null is o.k. and interpreted as false)
     * @param pIsSetForced true if a forced setValue should be done
     * @throws UnsupportedOperationException if the State we wrap is not not mutable
     */
    public void setValue(Boolean pValue, final boolean pIsSetForced)
    {
        checkDisposed();
        if (mMutableState==null)
            throw new UnsupportedOperationException("our state is not mutable");

        if (pValue==null)
            pValue= Boolean.FALSE;

        try
        {
            boolean enabled= pValue;
            setInSetValue(true, pIsSetForced);
            mMutableState.setEnabled(enabled, this);
            fireStateChanged();
        }
        finally
        {
            setInSetValue(false, false);
        }
    }

    /**
     * Get the current value, during a callback this is the new value.
     * @return Boolean.TRUE or Boolean.FALSE, never null
     */
    public Boolean getValue()
    {
        checkDisposed();
        return mState.isEnabled();
    }
}
