package net.sf.cuf.ui.table;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Toolkit;
import javax.swing.JPopupMenu;
import javax.swing.SwingUtilities;


/**
 * Utility functions for better UI programming.
 * Currently this class offers the following features:
 * <ul>
 *   <li>adjusting the position of popup menus</li>
 * </ul>
 * <p>
 * Multiple instances of this class may exist. One of these instances is the
 * default instance managed by this class.
 *
 * @author  Hendrik W&ouml;rdehoff, sd&amp;m AG
 */
public class GuiUtilities
{
    /** Move the popup menu a little bit to keep it on the screen. */
    public static final int POPUP_ADJUSTMENT_STRATEGY_MOVE = 1;
    /** Flip the popup menu to the other side of the mouse coursor. */
    public static final int POPUP_ADJUSTMENT_STRATEGY_FLIP = 2;

    /**
     * The default instance of this class.
     */
    private static GuiUtilities sInstance = null;

    /**
     * Current adjustment strategy for popup menus.
     * Valid values are {@link #POPUP_ADJUSTMENT_STRATEGY_MOVE} (default) and
     * {@link #POPUP_ADJUSTMENT_STRATEGY_FLIP}.
     */
    protected int mPopupAdjustmentStrategy = POPUP_ADJUSTMENT_STRATEGY_MOVE;


    /**
     * Get the default instance.
     * @return  current default instance
     */
    public static GuiUtilities getDefault()
    {
        if ( sInstance == null )
        {
            sInstance = new GuiUtilities();
        }
        return sInstance;
    }

    /**
     * Install a new default instance.
     * Derived classes may use this hook to install themselves as the default instance.
     * @param  pInstance  new default instance, may be null
     */
    protected static void setDefault(final GuiUtilities pInstance)
    {
        sInstance = pInstance;
    }


    /**
     * Get the popup adjustment strategy.
     * @return  {@link #POPUP_ADJUSTMENT_STRATEGY_MOVE} or {@link #POPUP_ADJUSTMENT_STRATEGY_FLIP}
     */
    public int getPopupAdjustmentStrategy()
    {
        return mPopupAdjustmentStrategy;
    }

    /**
     * Set the popup adjustment strategy.
     * @param  pStrategy  {@link #POPUP_ADJUSTMENT_STRATEGY_MOVE} or {@link #POPUP_ADJUSTMENT_STRATEGY_FLIP}
     * @throws  IllegalArgumentException  if the value <code>strategy</code> is not supported
     */
    public void setPopupAdjustmentStrategy(final int pStrategy)
    {
        if ( pStrategy != POPUP_ADJUSTMENT_STRATEGY_MOVE &&
             pStrategy != POPUP_ADJUSTMENT_STRATEGY_FLIP )
            throw new IllegalArgumentException("strategy must be a valid value");
        mPopupAdjustmentStrategy = pStrategy;
    }

    /**
     * Adjust the position of a popup so that it will be displayed in the visible screen area.
     * @param  popup      popup whose position has to be adjusted
     * @param  pInvoker  "invoker" of popup
     * @param  pPosition   proposed position for popup relative to <code>invoker</code> (should be the mouse cursor position)
     * @return            adjusted position relative to <code>invoker</code>
     */
    public Point adjustPopupPosition(final JPopupMenu popup, final Component pInvoker, final Point pPosition)
    {
        Point p = (Point) pPosition.clone();
        // convert to screen coordinate system
        SwingUtilities.convertPointToScreen(p, pInvoker);
        // get screen size
        Rectangle screen =  determineVisibleScreenArea();
        // get popup size
        Dimension popupsize = popup.getLayout().preferredLayoutSize(popup);
        // adjust popup position
        if ( mPopupAdjustmentStrategy == POPUP_ADJUSTMENT_STRATEGY_MOVE )
        {
            // move the popup menu just inside the visible area
            if ( p.x+popupsize.width  > screen.x+screen.width  )  p.x = screen.x+screen.width-popupsize.width;
            if ( p.x                  < screen.x               )  p.x = screen.x;
            if ( p.y+popupsize.height > screen.y+screen.height )  p.y = screen.y+screen.height-popupsize.height;
            if ( p.y                  < screen.y               )  p.y = screen.y;
        }
        else
        {
            // flip popup menu to the other side of the mouse cursor
            if ( p.x < screen.x )  p.x = screen.x;
            if ( p.y < screen.y )  p.y = screen.y;
            if ( p.x+popupsize.width  > screen.x+screen.width  )  p.x -= popupsize.width;
            if ( p.y+popupsize.height > screen.y+screen.height )  p.y -= popupsize.height;
        }
        // convert to component coordinate system
        SwingUtilities.convertPointFromScreen(p, pInvoker);
        return p;
    }

    /**
     * Adjust the position of a popup and show it.
     * @param  popup      popup whose position has to be adjusted
     * @param  pInvoker    "invoker" of popup
     * @param  pPosition   proposed position for popup relative to <code>invoker</code> (should be the mouse cursor position)
     */
    public void showPopupAdjusted(final JPopupMenu popup, final Component pInvoker, final Point pPosition)
    {
        Point pos = adjustPopupPosition(popup,  pInvoker, pPosition);
        popup.show(pInvoker, pos.x, pos.y);
    }

    /**
     * Determine the visible screen area.
     * With this hook taksbars and other things obscuring the screen can be taken in account.
     * @return  rectangle of visible screen area
     */
    protected Rectangle determineVisibleScreenArea()
    {
        return new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());
    }
}