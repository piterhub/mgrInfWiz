package net.sf.cuf.ui.table;

import java.util.EventListener;


/**
 * Listener interface for showing/hiding of table columns.
 *
 * @author  Hendrik W&ouml;rdehoff, sd&amp;m AG
 */
public interface ColumnVisibilityChangeListener
extends EventListener
{
    /**
     * Table column was shown.
     *
     * @param  pEvent  information about the shown column
     */
    public void columnShown(ColumnVisibilityChangeEvent pEvent);

    /**
     * Table column was hidden.
     *
     * @param  pEvent  information about the hidden column
     */
    public void columnHidden(ColumnVisibilityChangeEvent pEvent);
}
