package net.sf.cuf.fw;

import java.util.Properties;
import java.util.Map;
import java.util.HashMap;

/**
 * This class can be taken as a starting point for your a new Swing application.
 */
public abstract class AbstractSwingApplication implements Application
{
    /** Our properties. */
    protected Properties          mAppProperties;
    /** Our map for the models. */
    protected Map<String, Object> mAppModels;

    /**
     * The constructor creates the properties and the models hashmap.
     */
    public AbstractSwingApplication()
    {
        mAppProperties= new Properties();
        mAppModels    = new HashMap<String, Object>();
    }

    public String getProperty(final String pKey, final String pDefault)
    {
        return mAppProperties.getProperty(pKey, pDefault);
    }

    public void setProperty(final String pKey, final String pValue)
    {
        mAppProperties.setProperty(pKey, pValue);
    }

    public Properties getProperties()
    {
        return mAppProperties;
    }

    public Map<String, ? super Object> getAppModel()
    {
        return mAppModels;
    }

    public void doStart(final String[] pArgs)
    {
        // install our helper as a catcher of all EDT exceptions
        EDTExceptionUtil.setApp(this);
        EDTExceptionUtil.install();
    }
}
