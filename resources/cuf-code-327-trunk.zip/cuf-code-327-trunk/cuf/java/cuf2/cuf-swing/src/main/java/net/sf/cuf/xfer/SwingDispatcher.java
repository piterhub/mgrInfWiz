package net.sf.cuf.xfer;

import javax.swing.*;

/**
 * Java Swing implementation for the Dispatch interface.
 */
public class SwingDispatcher extends AbstractDispatcher implements Dispatch
{
    @Override
    protected void doDispatch(Runnable pRunnable)
    {
        SwingUtilities.invokeLater(pRunnable);
    }
}
