package net.sf.cuf.model;

import junit.framework.TestCase;

/**
 * Tests {@link ValueHolder} and includes various tests of the converter methods of {@link AbstractValueModel}.
 */
public class ValueHolderTest extends TestCase
{

    /**
     * Tests the creation of a value holder.
     */
    public void testCreateValueHolder()
    {
        ValueHolder valueHolder = new ValueHolder();
        assertSame("Initial value must be null", valueHolder.getValue(), null);
    }

    /**
     * Tests the storage of Object.
     */
    public void testHolderFunctionObject()
    {
        ValueHolder valueHolder = new ValueHolder();
        Object obj = new Object();
        valueHolder.setValue(obj);
        assertSame("getValue() after setValue(obj) must return obj", obj, valueHolder.getValue());
        valueHolder.setValue(null);
        assertSame("getValue() after setValue(null) must return null", null, valueHolder.getValue());
    }

    /**
     * Tests the notification of listeners.
     */
    public void testNotification()
    {
        ValueHolder valueHolder = new ValueHolder();
        CallbackTarget callbackTarget = new CallbackTarget();
        valueHolder.addChangeListener(callbackTarget);
        Object obj = new Object();
        assertFalse("Initially, callbackTarget must not have been notified", callbackTarget.isStateChangedCalled());
        valueHolder.setValue(obj);
        assertTrue("callbackTarget must have been notified for setValue(obj)", callbackTarget.isStateChangedCalled());
        callbackTarget.reset();
        valueHolder.setValue(obj);
        assertFalse("callbackTarget must not have been notified for second call to setValue(obj)", callbackTarget.isStateChangedCalled());
        callbackTarget.reset();
        valueHolder.setValueForced(obj);
        assertTrue("callbackTarget must have been notified for call to setValueForced(obj)", callbackTarget.isStateChangedCalled());
        callbackTarget.reset();
        valueHolder.setValue(null);
        assertTrue("callbackTarget must habe been notified for call to setValue(null)", callbackTarget.isStateChangedCalled());
        callbackTarget.reset();
        valueHolder.setValue(null);
        assertFalse("callbackTarget must not have been notified for second call to setValue(null)", callbackTarget.isStateChangedCalled());
        callbackTarget.reset();
        valueHolder.setValueForced(null);
        assertTrue("callbackTarget must have been notified for call to setValueForced(null)", callbackTarget.isStateChangedCalled());
    }

}
