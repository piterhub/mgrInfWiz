package net.sf.cuf.model.state;

import junit.framework.TestCase;
import net.sf.cuf.model.ValueHolder;
import net.sf.cuf.state.State;

/**
 * tests {@link MinMaxState}
 */
public class MinMaxStateTest extends TestCase
{
    public void testCreation()
    {
        ValueHolder vh = new ValueHolder();
        State state= new MinMaxState( vh, null, 5, false);
        assertTrue( "state must be initialized", state.isInitialized());
        assertTrue("state must be enabled for null value", state.isEnabled());
    }

    public void testInvert()
    {
        ValueHolder vh = new ValueHolder();
        State state= new MinMaxState( vh, 7, 10, false);
        State invertedState= new MinMaxState( vh, 7, 10, true);
        assertTrue( "state must be initialized", state.isInitialized());
        assertTrue( "invertedState must be initialized", invertedState.isInitialized());
        assertFalse("state must be disabled for null value", state.isEnabled());
        assertTrue("invertedState must be enabled for null value", invertedState.isEnabled());

        vh.setValue(6);
        assertFalse("state must be disabled for wrong value", state.isEnabled());
        assertTrue("invertedState must be enabled for right value", invertedState.isEnabled());
        vh.setValue(8);
        assertTrue("state must be enabled for right value", state.isEnabled());
        assertFalse("invertedState must be disabled for wrong value", invertedState.isEnabled());
        vh.setValue(11);
        assertFalse("state must be disabled for wrong value", state.isEnabled());
        assertTrue("invertedState must be enabled for right value", invertedState.isEnabled());
    }

    public void testMaxStringValues()
    {
        ValueHolder vh = new ValueHolder();
        MinMaxState minMaxState = new MinMaxState( vh, null, 10, false);
        assertTrue("state must be enabled for null value", minMaxState.isEnabled());

        vh.setValue("a");
        assertTrue("state must be enabled for matching value", minMaxState.isEnabled());

        vh.setValue("01234567891");
        assertFalse("state must be disabled for out of range value", minMaxState.isEnabled());

        vh.setValue(null);
        assertTrue("state must be enabled for null value", minMaxState.isEnabled());

        vh.setValue("in range");
        assertTrue("state must be enabled for matching value", minMaxState.isEnabled());
    }

    public void testMinMaxStringValues()
    {
        ValueHolder vh = new ValueHolder();
        MinMaxState minMaxState = new MinMaxState( vh, 1, 10, false);
        assertFalse("state must be disabled for null value", minMaxState.isEnabled());

        vh.setValue("a");
        assertTrue("state must be enabled for matching value", minMaxState.isEnabled());

        vh.setValue("01234567891");
        assertFalse("state must be disabled for out of range value", minMaxState.isEnabled());

        vh.setValue(null);
        assertFalse("state must be disabled for null value", minMaxState.isEnabled());

        vh.setValue("in range");
        assertTrue("state must be enabled for matching value", minMaxState.isEnabled());
    }

    public void testMaxIntValues()
    {
        ValueHolder vh = new ValueHolder();
        MinMaxState minMaxState = new MinMaxState( vh, null, 10, false);
        assertTrue("state must be enabled for null value", minMaxState.isEnabled());

        vh.setValue(1);
        assertTrue("state must be enabled for matching value", minMaxState.isEnabled());

        vh.setValue(11);
        assertFalse("state must be disabled for out of range value", minMaxState.isEnabled());

        vh.setValue(null);
        assertTrue("state must be enabled for null value", minMaxState.isEnabled());

        vh.setValue(7);
        assertTrue("state must be enabled for matching value", minMaxState.isEnabled());
    }
}
