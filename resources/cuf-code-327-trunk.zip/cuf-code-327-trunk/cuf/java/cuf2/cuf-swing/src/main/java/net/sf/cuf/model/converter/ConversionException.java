package net.sf.cuf.model.converter;

/**
 * A ConversionException is used by a TypeConverter to signal problems during
 * a conversion. It allows that an alternative conversion type is provided,
 * so that even the conversion state is out of sync, something "useful"
 * (like null) is propagated through the ValueModel hierarchy.
 */
public class ConversionException extends Exception
{
    /** true if we have a value, even if the conversion failed */
    private boolean mHasConversionValue;

    /** null or the conversion value */
    private Object mConversionValue;

    /**
     * Constructs a new exception without detailed message and
     * cause and without a conversion value.
     */
    public ConversionException()
    {
        super();
        mHasConversionValue= false;
        mConversionValue   = null;
    }

    /**
     * Constructs a new exception with the specified detail message and
     * cause and without a conversion value.
     * @param pMessage a text describing the problem
     * @param pCause the real cause
     */
    public ConversionException(final String pMessage, final Throwable pCause)
    {
        super(pMessage, pCause);
        mHasConversionValue= false;
        mConversionValue   = null;
    }

    /**
     * Constructs a new exception with the specified detail message and
     * cause and a (possible null) conversion value.
     * @param pMessage a text describing the problem
     * @param pCause the real cause
     * @param pConversionValue the conversion value that should be used
     */
    public ConversionException(final String pMessage, final Throwable pCause, final Object pConversionValue)
    {
        super(pMessage, pCause);
        mHasConversionValue= true;
        mConversionValue   = pConversionValue;
    }

    /**
     * Return if a alternative conversion value is available, even
     * though the conversion failed
     * @return true if we have an alternative
     */
    public boolean hasConversionValue()
    {
        return mHasConversionValue;
    }

    /**
     * Return the conversion value that should be used even if the conversion failed.
     * @return null or the conversion value
     */
    public Object getConversionValue()
    {
        return mConversionValue;
    }
}
