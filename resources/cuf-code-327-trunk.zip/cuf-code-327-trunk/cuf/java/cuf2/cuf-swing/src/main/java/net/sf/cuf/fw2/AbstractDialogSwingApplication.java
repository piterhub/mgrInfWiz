package net.sf.cuf.fw2;

import net.sf.cuf.fw.AbstractSwingApplication;
import net.sf.cuf.appevent.AppEvent;
import net.sf.cuf.appevent.AppEventManager;

/**
 * AbstractDialogSwingApplication adds app-event support to AbstractSwingApplication.
 */
public abstract class AbstractDialogSwingApplication
        extends AbstractSwingApplication
        implements DialogApplication
{
    /** Our app event manager. */
    protected AppEventManager   mAppEventManger;

    /** The manager object that opens/closes dialogs. */
    protected DialogManager     mDialogManager;

    /**
     * The constructor creates the AppEventManager and DialogManager for this application.
     */
    public AbstractDialogSwingApplication()
    {
        mAppEventManger= new AppEventManager();
        mDialogManager = new DialogManager(this);
    }

    /**
     * Process/Dispatch an AppEvent.
     * Each processing step should call forward() on the event
     * beforing doing any further dispatching/processing and
     * check after the forward() call if the event is not
     * allready consumed.
     *
     * @param pAppEvent event that should be routed/processes
     * @throws IllegalArgumentException if pAppEvent is null
     */
    public void postAppEvent(final AppEvent pAppEvent)
    {
        mDialogManager.postAppEvent(null, mAppEventManger, pAppEvent);
    }
}
