package net.sf.cuf.model.converter;

import net.sf.cuf.model.ValueModel;


/**
 * A IntegerStringConverter is taking an Long as it's subject value and converting
 * it to an String as its own value.
 */
public class IntegerStringConverter extends AbstractNumberStringConverter<Integer>
{
    
    /**
     * Create a new Integer-to-String converter where null is a valid value.
     * @param pSubject the ValueModel holding the original value
     */
    public IntegerStringConverter(final ValueModel<Integer> pSubject)
    {
        super(pSubject);
    }

    /**
     * Create a new Integer-to-String converter.
     * @param pSubject the ValueModel holding the original value
     * @param pNullIsValid true if we should use null as an
     *        alternative value if the conversion fails
     */
    public IntegerStringConverter(final ValueModel<Integer> pSubject, final boolean pNullIsValid)
    {
        super(pSubject, pNullIsValid);
    }

    /**
     * {@inheritDoc}
     */
    protected Integer convertToNumber(final String pOwnValue) throws NumberFormatException
    {
        return new Integer(pOwnValue);
    }
}
