package net.sf.cuf.ui.builder;

import org.jdom2.Element;
import org.jdom2.Attribute;

import javax.swing.AbstractButton;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JMenuItem;
import javax.swing.JComponent;
import javax.swing.JSlider;
import javax.swing.JTabbedPane;
import javax.swing.JSpinner;
import javax.swing.JList;
import javax.swing.JTable;
import javax.swing.JTree;
import javax.swing.text.JTextComponent;
import java.util.List;

import net.sf.cuf.ui.SwingConnectionManager;
import net.sf.cuf.ui.DispatcherAction;

/**
 * The ConnectionBuilderDelegate class handles the "connect" entry of
 * a xml2swing XML description.
 */
class ConnectionBuilderDelegate implements SwingXMLBuilder.BuilderDelegate
{
    /**
     * Create the connection between the visual and non visual objects.
     * @param pBuilder the builder that controls the creation process
     * @param pConnectElement the JDOM element the delegate should handle ("connect" in our case)
     * @throws IllegalArgumentException if a syntax error is detected
     */
    @SuppressWarnings({"ConstantConditions"})
    public void build(final SwingXMLBuilder pBuilder, final Element pConnectElement) throws IllegalArgumentException
    {
        List<Element> connections= pConnectElement.getChildren();
        for (final Element connection : connections)
        {
            try
            {
                String connectionType = connection.getName();
                Attribute sourceAttribute = connection.getAttribute(SwingXMLBuilder.SOURCE_ATTRIBUTE);
                Attribute targetAttribute = connection.getAttribute(SwingXMLBuilder.TARGET_ATTRIBUTE);
                Attribute methodAttribute = connection.getAttribute(SwingXMLBuilder.METHOD_ATTRIBUTE);
                if (sourceAttribute == null)
                    throw SwingXMLBuilder.createException("a connection element needs a " +
                                                          SwingXMLBuilder.SOURCE_ATTRIBUTE + " attribute", connection);
                if (targetAttribute == null)
                    throw SwingXMLBuilder.createException("a connection element needs a " +
                                                          SwingXMLBuilder.TARGET_ATTRIBUTE + " attribute", connection);
                if (methodAttribute == null)
                    throw SwingXMLBuilder.createException("a connection element needs a " +
                                                          SwingXMLBuilder.METHOD_ATTRIBUTE + " attribute", connection);

                String targetName = targetAttribute.getValue();
                Object target = pBuilder.getNonVisualObject(targetName);
                String method = methodAttribute.getValue();

                if (target == null)
                    throw SwingXMLBuilder.createException("no target found for target name " + targetAttribute.getValue(),
                                                          connection);
                if (method == null || "".equals(method))
                    throw SwingXMLBuilder.createException("no valid method for target name " + targetAttribute.getValue(),
                                                          connection);

                if (connectionType.equals(SwingXMLBuilder.BUTTONACTION_ELEMENT) || // deprecated
                    connectionType.equals(SwingXMLBuilder.COMBOBOXACTION_ELEMENT) || // deprecated
                    connectionType.equals(SwingXMLBuilder.TEXTFIELDACTION_ELEMENT) || // deprecated
                    connectionType.equals(SwingXMLBuilder.MENUACTION_ELEMENT) || // deprecated
                    connectionType.equals(SwingXMLBuilder.ACTIONACTION_ELEMENT))
                {
                    // first try a action, then a component
                    String sourceId = sourceAttribute.getValue();
                    Object actionObject = pBuilder.getNonVisualObject(sourceId);
                    if (actionObject instanceof DispatcherAction)
                    {
                        DispatcherAction source = (DispatcherAction) actionObject;
                        SwingConnectionManager.createActionConnection(source, target, method);
                    }
                    else if (actionObject == null)
                    {
                        JComponent component = pBuilder.getComponentByAnyName(sourceId);
                        if (component instanceof AbstractButton)
                        {
                            AbstractButton source = (AbstractButton) component;
                            SwingConnectionManager.createActionConnection(source, target, method);
                        }
                        else if (component instanceof JComboBox)
                        {
                            JComboBox source = (JComboBox) component;
                            SwingConnectionManager.createActionConnection(source, target, method);
                        }
                        else if (component instanceof JTextField)
                        {
                            JTextField source = (JTextField) component;
                            SwingConnectionManager.createActionConnection(source, target, method);
                        }
                        else if (component instanceof JMenuItem)
                        {
                            JMenuItem source = (JMenuItem) component;
                            SwingConnectionManager.createActionConnection(source, target, method);
                        }
                        else
                        {
                            throw new IllegalArgumentException("component (id= " + sourceId + "), object= "
                                                               + component + " can't be used to create an actionAction");
                        }
                    }
                    else
                    {
                        throw new IllegalArgumentException("action (id= " + sourceId + "), object= " + actionObject +
                                                           " can't be used to create an actionAction " +
                                                           "(no DispatcherAction)");
                    }
                }
                else if (connectionType.equals(SwingXMLBuilder.CARETACTION_ELEMENT))
                {
                    JTextComponent source = (JTextComponent) pBuilder.getComponentByAnyName(sourceAttribute.getValue());
                    SwingConnectionManager.createCaretConnection(source, target, method);
                }
                else if (connectionType.equals(SwingXMLBuilder.CHANGEACTION_ELEMENT))
                {
                    JComponent component = pBuilder.getComponentByAnyName(sourceAttribute.getValue());
                    if (component instanceof AbstractButton)
                    {
                        AbstractButton source = (AbstractButton) component;
                        SwingConnectionManager.createChangeConnection(source, target, method);
                    }
                    else if (component instanceof JSlider)
                    {
                        JSlider source = (JSlider) component;
                        SwingConnectionManager.createChangeConnection(source, target, method);
                    }
                    else if (component instanceof JTabbedPane)
                    {
                        JTabbedPane source = (JTabbedPane) component;
                        SwingConnectionManager.createChangeConnection(source, target, method);
                    }
                    else if (component instanceof JSpinner)
                    {
                        JSpinner source = (JSpinner) component;
                        SwingConnectionManager.createChangeConnection(source, target, method);
                    }
                    else
                    {
                        throw new IllegalArgumentException("component " + component +
                                                           " can't be used to create an changeAction");
                    }
                }
                else if (connectionType.equals(SwingXMLBuilder.FOCUSACTION_ELEMENT))
                {
                    JComponent source = pBuilder.getComponentByAnyName(sourceAttribute.getValue());
                    SwingConnectionManager.createFocusConnection(source, target, method);
                }
                else if (connectionType.equals(SwingXMLBuilder.LISTSELECTIONACTION_ELEMENT))
                {
                    JComponent component = pBuilder.getComponentByAnyName(sourceAttribute.getValue());
                    if (component instanceof JList)
                    {
                        JList source = (JList) component;
                        SwingConnectionManager.createListSelectionConnection(source, target, method);
                    }
                    else if (component instanceof JTable)
                    {
                        JTable source = (JTable) component;
                        SwingConnectionManager.createListSelectionConnection(source, target, method);
                    }
                    else
                    {
                        throw new IllegalArgumentException("component " + component +
                                                           " can't be used to create an listSelectionAction");
                    }
                }
                else if (connectionType.equals(SwingXMLBuilder.PROPERTYCHANGEACTION_ELEMENT))
                {
                    JComponent source = pBuilder.getComponentByAnyName(sourceAttribute.getValue());
                    SwingConnectionManager.createPropertyChangeConnection(source, target, method);
                }
                else if (connectionType.equals(SwingXMLBuilder.TREESELECTIONACTION_ELEMENT))
                {
                    JTree source = (JTree) pBuilder.getComponentByAnyName(sourceAttribute.getValue());
                    SwingConnectionManager.createTreeSelectionConnection(source, target, method);
                }
                else if (connectionType.equals(SwingXMLBuilder.DOCUMENTACTION_ELEMENT))
                {
                    JTextComponent source = (JTextComponent) pBuilder.getNonVisualObject(sourceAttribute.getValue());
                    SwingConnectionManager.createDocumentConnection(source, target, method);
                }
                else
                {
                    throw new IllegalArgumentException("unknown connection type " + connectionType);
                }
            }
            catch (Exception e)
            {
                throw SwingXMLBuilder.createException("could not create connection", e, connection);
            }
        }
    }
}
