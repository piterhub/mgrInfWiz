package net.sf.cuf.model;

/**
 * This interface allows to control in detail how an
 *  AspectAdapter gets or sets the values.
 */
public interface AspectAccessAdapter
{
    /**
     * Tests if a call to setValue() makes sense.
     * @return false if setValue will always throw an exception
     */
    public boolean isEditable();

    /**
     * Extract the value from the source.
     * @param pSource the source, may be null
     * @return null or the value
     */
    public Object getValue(Object pSource);

    /**
     * Sets a value to the source.
     * @param pSource the source, never null
     * @param pValue the new value, may be null
     */
    public void setValue(Object pSource, Object pValue);
}
