package net.sf.cuf.fw;

import junit.framework.TestCase;

import javax.swing.JButton;
import javax.swing.SwingUtilities;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.reflect.InvocationTargetException;

/**
 * Test to check if our exception handling works.
 */
public class EDTExceptionUtilTest extends TestCase
{
    /** null or the captured EDT exception */
    private Throwable mThrowable;

    /** message for our NPE */
    private static final String MESSAGE= "EDTExceptionUtilTest";

    /**
     * Test if a NPE in the EDT is reported correctly.
     * @throws InterruptedException should not be thrown
     */
    public void testEDTException() throws InvocationTargetException, InterruptedException
    {
        Thread.UncaughtExceptionHandler oldHandler= Thread.getDefaultUncaughtExceptionHandler();


        // given
        EDTExceptionUtil.install();
        EDTExceptionUtil.setFatalErrorReporter(new EDTExceptionUtil.FatalErrorReporter()
        {
            @Override
            public void reportFatalError(Throwable pThrowable)
            {
                captureFatalError(pThrowable);
            }
        });
        final JButton button= new JButton();
        button.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(final ActionEvent pActionEvent)
            {
                throw new NullPointerException(MESSAGE);
            }
        });

        // when
        SwingUtilities.invokeLater( new Runnable()
        {
            @Override
            public void run()
            {
                button.doClick();
            }
        });
        // ugly, but o.k.
        Thread.sleep(500);

        // then
        assertNotNull("no exception was captured", mThrowable);
        assertEquals("wrong exception type", NullPointerException.class, mThrowable.getClass());
        assertEquals("wrong exception message", MESSAGE, mThrowable.getMessage());

        Thread.setDefaultUncaughtExceptionHandler(oldHandler);
    }

    private void captureFatalError(final Throwable pThrowable)
    {
        mThrowable= pThrowable;
    }
}
