package net.sf.cuf.ui.table;

import javax.swing.table.TableModel;


/**
 * Context menu action to perform a {@link SortDialog} and apply the results on the {@link SortingTable}.
 *
 * @author  Hendrik W&ouml;rdehoff, sd&amp;m AG
 */
public class ContextMenuActionSortDialog
extends ContextMenuAction
{
    /**
     * Sorting dialog for the table.
     * Will be instantiated when needed.
     */
    private SortDialog mSortDialog = null;

    public String getKennung()
    {
        return mAdapter.getContextMenuKennung()+"_SORT";
    }

    /**
     * @return  always <code>true</code>
     */
    public boolean isEnabled()
    {
        return true;
    }

    /**
     * The sorting dialog is opened initialized with the current model and sorting of the table.
     * Afterwards the changes of the customer are applied to the table.
     * It is not possible to hide all columns of the table this way.
     * @throws  IllegalStateException  if the table does not (yet) reside in a {@link java.awt.Frame}
     */
    public void performAction()
    throws IllegalStateException
    {
        TableModel tableModel = mAdapter.getTable().getModel();

        if (!(tableModel instanceof TableSorter)) return;

        TableSorter tableSorter = (TableSorter)tableModel;

        TableSortInfo currentSort = tableSorter.getSortInfo();
        TableSortInfo newSort     = getSortDialog().show(mAdapter.getTable(), currentSort);

        if (newSort != null)
        {
            tableSorter.resetColumns();

            for (int i = 0; i < newSort.size(); i++)
            {
                tableSorter.sortByColumn(newSort.getColumn(i), newSort.isAscending(i));
            }
        }
    }

    /**
     * Instantiate the sorting dialog lazily.
     * This call only succeeds after the table has been embedded into a window.
     * @return  the sort dialog for this context menu
     * @throws  IllegalStateException  if the table does not (yet) reside in a {@link java.awt.Frame}
     */
    private SortDialog getSortDialog()
    throws IllegalStateException
    {
        if ( mSortDialog == null )
        {
            mSortDialog = new SortDialog(mAdapter.getFrameForTable());
        }
        return mSortDialog;
    }
}