package net.sf.cuf.state.ui;

import net.sf.cuf.state.AbstractStateAdapter;
import net.sf.cuf.state.State;

import javax.swing.JComponent;

/**
 * A SwingVisibleAdapter maps the enabeling/disabeling of the monitored state
 * to the showing/hiding of a JComponent.
 */
public class SwingVisibleAdapter extends AbstractStateAdapter
{
    /**
     * Create a new adapter with no state associated.
     */
    public SwingVisibleAdapter()
    {
        super();
    }

    /**
     * Create a new adapter.
     * @param pState the state we adapt
     */
    public SwingVisibleAdapter(final State pState)
    {
        super(pState);
    }

    /**
     * We don't need special treatment for the inital step, and
     * just call processStateChange().
     * @param pTarget the target we should adjust
     * @param pEnabled the state for the target
     */
    protected void adjustInitialState(final Object pTarget, final boolean pEnabled)
    {
        processStateChange(pTarget, pEnabled);
    }

    /**
     * We map the pEnabled boolean to the visible/not visible behaviour of a
     * JComponent.
     * @param pTarget  target object, must be a JComponent
     * @param pEnabled true if the target object should get "enabled"
     * @throws IllegalStateException if pTarget is not a JComponent
     */
    protected void processStateChange(final Object pTarget, final boolean pEnabled)
    {
        if (pTarget instanceof JComponent)
        {
            JComponent component = (JComponent) pTarget;
            component.setVisible(pEnabled);
        }
        else
        {
            // you can add any objects but we won't handle them ;-)
            throw new IllegalStateException("we cant handle that object:"+pTarget);
        }
    }
}
