package net.sf.cuf.state.ui;

import net.sf.cuf.state.AbstractStateAdapter;
import net.sf.cuf.state.State;

import javax.swing.Action;
import java.awt.Component;
import java.awt.Container;

/**
 * A SwingEnabledAdapter maps the enabeling/disabeling of the monitored state
 * to the enabeling/disabeling of a JComponent or Action.
 */
public class SwingEnabledAdapter extends AbstractStateAdapter
{
    // marker if we should enable/disable recursivly
    private boolean mDeepEnable;

    /**
     * Create a new adapter with no state associated.
     */
    public SwingEnabledAdapter()
    {
        this(null, false);
    }

    /**
     * Create a new adapter.
     * @param pState the state we adapt
     */
    public SwingEnabledAdapter(final State pState)
    {
        this(pState, false);
    }

    /**
     * Create a new adapter.
     * @param pState the state we adapt
     * @param pDeepEnable true if we should enable/disable recursivly
     */
    public SwingEnabledAdapter(final State pState, final boolean pDeepEnable)
    {
        super(pState);
        mDeepEnable= pDeepEnable;
    }

    /**
     * Sets if we should enable/disable recursivly.
     * @param pDeepEnable true if we shuld enable/disable recursivly
     */
    public void setDeepEnable(final boolean pDeepEnable)
    {
        boolean changed= (mDeepEnable!=pDeepEnable);
        mDeepEnable = pDeepEnable;
        if (changed)
        {
            stateChanged(null);
        }
    }

    /**
     * Returns if we enable/disable recursivly.
     * @return true if we enable/disable recursivly
     */
    public boolean isDeepEnable()
    {
        return mDeepEnable;
    }

    /**
     * We don't need special treatment for the inital step, and
     * just call processStateChange().
     * @param pTarget the target we should adjust
     * @param pEnabled the state for the target
     */
    protected void adjustInitialState(final Object pTarget, final boolean pEnabled)
    {
        processStateChange(pTarget, pEnabled);
    }

    /**
     * We map the pEnabled boolean to the enabled/not enabled behaviour of a
     * AbstractButton or a Action.
     * @param pTarget  target object, either a JComponent or a Action
     * @param pEnabled true if the target object should get "enabled"
     * @throws IllegalStateException if pTarget is not a JComponent or Action
     */
    protected void processStateChange(final Object pTarget, final boolean pEnabled)
    {
        if (pTarget instanceof Component)
        {
            Component component = (Component) pTarget;
            setEnabled(component, pEnabled);
        }
        else if (pTarget instanceof Action)
        {
            Action action= (Action) pTarget;
            action.setEnabled(pEnabled);
        }
        else
        {
            // you can add any objects but we won't handle them ;-)
            throw new IllegalStateException("we cant handle that object:"+pTarget);
        }
    }

    /**
     * Small helper to (recursivly) enable/disable a component.
     * @param pComponent the component
     * @param pEnabled true if we should enable the component
     */
    private void setEnabled(final Component pComponent, final boolean pEnabled)
    {
        if (mDeepEnable && (pComponent instanceof Container))
        {
            Component[] children= ((Container)pComponent).getComponents();
            for (final Component child : children)
            {
                setEnabled(child, pEnabled);
            }
        }
        pComponent.setEnabled(pEnabled);
    }
}
