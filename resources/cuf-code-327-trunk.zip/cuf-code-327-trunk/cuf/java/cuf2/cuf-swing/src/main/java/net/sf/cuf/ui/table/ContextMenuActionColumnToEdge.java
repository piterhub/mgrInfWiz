package net.sf.cuf.ui.table;


/**
 * Context menu action to move a column to the first or last column position in the table.
 *
 * @author  Hendrik W&ouml;rdehoff, sd&amp;m AG
 */
public class ContextMenuActionColumnToEdge
extends ContextMenuAction
{
    /** Move the column to the first position. */
    public static final int EDGE_LEFT = 1;
    /** Move the column to the last position. */
    public static final int EDGE_RIGHT = 2;

    /** Mode of this instance. Must be {@link #EDGE_LEFT} or {@link #EDGE_RIGHT}. */
    private int mode;

    /**
     * Constructor.
     * @param  pMode  {@link #EDGE_LEFT} or {@link #EDGE_RIGHT}
     */
    public ContextMenuActionColumnToEdge(final int pMode)
    {
        if ( pMode != EDGE_LEFT && pMode != EDGE_RIGHT )
            throw new IllegalArgumentException("mode must have a valid value");
        this.mode = pMode;
    }

    public String getKennung()
    {
        return mAdapter.getContextMenuKennung()+(mode == EDGE_LEFT ? "_COLLEFT" : "_COLRIGHT");
    }

    /**
     * @return  <code>true</code> unless the popup menu is not on a colum or the column already is at the desired position
     */
    public boolean isEnabled()
    {
        // first check if reordering is allowed in JTable...
        if (!mAdapter.getTable().getTableHeader().getReorderingAllowed())
        {
            return false;
        }
        // ...then check if view column index is in allowed range 
        int viewIndex = mAdapter.getViewColumnIndex();
        return viewIndex != -1 && viewIndex != getEdgeColumnIndex();
    }

    public void performAction()
    {
        mAdapter.getTable().moveColumn(mAdapter.getViewColumnIndex(), getEdgeColumnIndex());
    }

    /**
     * Calculate the index of the target column for this instances mode.
     * @return  view column index
     */
    private int getEdgeColumnIndex()
    {
        return (mode == EDGE_LEFT ? 0 : mAdapter.getTable().getColumnCount()-1);
    }
}