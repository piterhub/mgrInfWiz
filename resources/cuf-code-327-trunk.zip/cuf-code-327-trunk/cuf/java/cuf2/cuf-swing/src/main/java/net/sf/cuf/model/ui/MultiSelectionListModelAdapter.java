package net.sf.cuf.model.ui;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.swing.JList;
import javax.swing.ListModel;
import javax.swing.ListSelectionModel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.EventListenerList;
import javax.swing.event.ListDataEvent;
import javax.swing.event.ListDataListener;
import javax.swing.event.ListSelectionListener;

import net.sf.cuf.model.DelegateAccess;
import net.sf.cuf.model.MultiSelectionInList;

/**
 * A MultiSelectionListModelAdapter connects a model of a JList to a MultiSelectionInList
 * ValueModel. The selection is synchronized between the JList and the MultiSelectionInList.
 * The data in the list is taken from the MultiSelectionInList, too, and a
 * DelegateAccess object may be used to convert from the "raw" object to a display object.
 * Whenever either the selection of the list or in the 
 * ValueModel changes, the other model is adjusted accordingly.
 * A ListModelAdapter is not a ValueModel itself, but connects a
 * MultiSelectionInList ValueModel to a ListSelectionModel and a ListModel.
 */
public class MultiSelectionListModelAdapter implements ListModel, ListSelectionModel
{
    // list of listeners for our Swing ListModel, never null
    private   EventListenerList    mListenerList;
    // our delegate handling the Swing ListSelectionModel, never null
    private   ListSelectionModel   mListSelectionModel;
    // marker if we are inside a selection change, we then ignore selection
    // changes from the "other" model
    private   boolean              mInSelectionChange; 
    // value model holding the list, never null
    protected MultiSelectionInList mMultiSelectionInList;
    // ValueModel to get the attribute, may be null
    private DelegateAccess         mAccessValueModel;

    /**
     * Creates a new adapter between a MultiSelectionInList ValueModel
     * and a JList.
     * The selection mode of the list is not modified.
     * 
     * @param pList the list for which we adapt to
     * @param pListValueModel the value model (MultiSelectionInList) that drives the list
     *        (data, selection) and gets updated by the list (selection only)
     * @param pAccessValueModel null or the converter we use to map between the
     *                          SelectionInList list objects and the display objects
     * @throws IllegalArgumentException if pList or pValueModel is null
     */
    public MultiSelectionListModelAdapter(final JList pList, final MultiSelectionInList pListValueModel,
                            final DelegateAccess pAccessValueModel)
    {
        if (pList==null)
            throw new IllegalArgumentException("list must not be null");
        if (pListValueModel==null)
            throw new IllegalArgumentException("list value model must not be null");

        mListSelectionModel    = pList.getSelectionModel();
        mMultiSelectionInList  = pListValueModel;
        mAccessValueModel      = pAccessValueModel;
        mListenerList          = new EventListenerList();
        mInSelectionChange     = false;

        mMultiSelectionInList.onChangeSend(this, "vmDataChanged");
        mMultiSelectionInList.getSelectedIndexSetValueModel().onChangeSend(this, "vmSelectionChanged");
        // connect the list to the models
        pList.setModel         (this);
        pList.setSelectionModel(this);
        // update the selection model to the initial state
        // (this must happen after the list is assigned, otherwise the initial selection 
        // is not displayed - bug in ListUI?)
        vmSelectionChanged(null);
    }

    /**
     * Notifies all listeners that something changed in our list model.
     * @param pEvent the ListDataEvent to fire
     */
    protected void fireListChanged(final ListDataEvent pEvent)
    {
        Object[] listeners = mListenerList.getListenerList();
        for (int i= listeners.length-2; i>=0; i-=2)
        {
            if (listeners[i]==ListDataListener.class)
            {
                ((ListDataListener)listeners[i+1]).contentsChanged(pEvent);
            }
        }
    }

    /**
     * callback from our MultiSelectionInList that the base list has changed
     * @param pEvent the change event
     */
    public void vmDataChanged(final ChangeEvent pEvent)
    {
        // notify the list to re-read the data, this will clear the selection,
        // so we re-set the selection afterwards

        mInSelectionChange = true;
        try
        {
            List baseList = (List) mMultiSelectionInList.getValue();
            int maxIndex = -1;
            if (baseList!=null)
            {
                maxIndex = baseList.size()-1;
            }
            ListDataEvent e = new ListDataEvent(this, ListDataEvent.CONTENTS_CHANGED, 0, maxIndex);
            fireListChanged(e);
            mListSelectionModel.setValueIsAdjusting( true);
            mListSelectionModel.clearSelection();
            for (final Object o : ((Set) mMultiSelectionInList.getSelectedIndexSetValueModel().getValue()))
            {
                Integer selectedIndex = (Integer) o;
                mListSelectionModel.addSelectionInterval(selectedIndex, selectedIndex);
            }
            mListSelectionModel.setValueIsAdjusting( false);
        }
        finally
        {
            mInSelectionChange= false;
        }
    }

    public void vmSelectionChanged(final ChangeEvent pEvent)
    {
        // ignore the changes we triggered
        if (mInSelectionChange)
        {
            return;
        }

        mInSelectionChange= true;
        try
        {
            // re-adjust the selection in our JList
            mListSelectionModel.setValueIsAdjusting( true);
            mListSelectionModel.clearSelection();
            for (final Object o : ((Set) mMultiSelectionInList.getSelectedIndexSetValueModel().getValue()))
            {
                Integer selectedIndex = (Integer) o;
                mListSelectionModel.addSelectionInterval(selectedIndex, selectedIndex);
            }
            mListSelectionModel.setValueIsAdjusting( false);
        }
        finally
        {
            mInSelectionChange= false;
        }
    }
    
    /*
     * Swing ListSelectionModel callbacks
     */
    private void handleListSelection()
    {
        // ignore the changes we triggered
        if (mInSelectionChange)
        {
            return;
        }
        // ignore changes when the ListSelectionModel is adjusting
        if (mListSelectionModel.getValueIsAdjusting())
        {
            return;
        }

        mInSelectionChange= true;
        try
        {
            Set selectedIndexes = new HashSet();
            for (int i = mListSelectionModel.getMinSelectionIndex(); i <= mListSelectionModel.getMaxSelectionIndex(); i++)
            {
                if (mListSelectionModel.isSelectedIndex( i))
                {
                    selectedIndexes.add(i);
                }
            }
            mMultiSelectionInList.setSelectedIndexes( selectedIndexes);
        }
        finally
        {
            mInSelectionChange= false;
        }
    }

    public void setSelectionInterval(final int pIndex0, final int pIndex1)
    {
        mListSelectionModel.setSelectionInterval(pIndex0, pIndex1);
        handleListSelection();
    }

    public void addSelectionInterval(final int pIndex0, final int pIndex1)
    {
        mListSelectionModel.addSelectionInterval(pIndex0, pIndex1);
        handleListSelection();
    }

    public void removeSelectionInterval(final int pIndex0, final int pIndex1)
    {
        mListSelectionModel.removeSelectionInterval(pIndex0, pIndex1);
        handleListSelection();
    }

    public void insertIndexInterval(final int pIndex, final int pLength, final boolean pBefore)
    {
        mListSelectionModel.insertIndexInterval(pIndex, pLength, pBefore);
        handleListSelection();
    }

    public void removeIndexInterval(final int pIndex0, final int pIndex1)
    {
        mListSelectionModel.removeIndexInterval(pIndex0, pIndex1);
        handleListSelection();
    }

    public void clearSelection()
    {
        mListSelectionModel.clearSelection();
        handleListSelection();
    }

    public int getMinSelectionIndex()
    {
        return mListSelectionModel.getMinSelectionIndex();
    }

    public int getMaxSelectionIndex()
    {
        return mListSelectionModel.getMaxSelectionIndex();
    }

    public boolean isSelectedIndex(final int pIndex)
    {
        if (pIndex == -1)
        {
            return false;
        }

        return mListSelectionModel.isSelectedIndex(pIndex);
    }

    public int getAnchorSelectionIndex()
    {
        return mListSelectionModel.getAnchorSelectionIndex();
    }

    public void setAnchorSelectionIndex(final int pIndex)
    {
        mListSelectionModel.setAnchorSelectionIndex(pIndex);
        handleListSelection();
    }

    public int getLeadSelectionIndex()
    {
        return mListSelectionModel.getLeadSelectionIndex();
    }

    public void setLeadSelectionIndex(final int pIndex)
    {
        mListSelectionModel.setLeadSelectionIndex(pIndex);
        handleListSelection();
    }

    public boolean isSelectionEmpty()
    {
        return mListSelectionModel.isSelectionEmpty();
    }

    public void setValueIsAdjusting(final boolean pValueIsAdjusting)
    {
        if (pValueIsAdjusting!=mListSelectionModel.getValueIsAdjusting())
        {
            mListSelectionModel.setValueIsAdjusting(pValueIsAdjusting);
            handleListSelection();
        }
    }

    public boolean getValueIsAdjusting()
    {
        return mListSelectionModel.getValueIsAdjusting();
    }

    public void setSelectionMode(final int pSelectionMode)
    {
        mListSelectionModel.setSelectionMode(pSelectionMode);
    }

    public int getSelectionMode()
    {
        return mListSelectionModel.getSelectionMode();
    }

    public void addListSelectionListener(final ListSelectionListener pListener)
    {
        mListSelectionModel.addListSelectionListener(pListener);
    }

    public void removeListSelectionListener(final ListSelectionListener pListener)
    {
        mListSelectionModel.removeListSelectionListener(pListener);
    }

	/*
	 * Implementations of ListModel-Interface
	 */
	public Object getElementAt(final int pIndex)
    {
        if (pIndex==-1)
        {
            return null;
        }
        List    list = (List) mMultiSelectionInList.getValue();
        Object  value= list.get(pIndex);
        if (mAccessValueModel != null)
        {
            value= mAccessValueModel.getValue(value);
        }
        return value;
	}

    public int getSize() 
    {   
        if (mMultiSelectionInList.getValue() != null)
        {
            return ((List) mMultiSelectionInList.getValue()).size();
        }      
        return 0;
	}

    public void addListDataListener(final ListDataListener pListener)
    {
        mListenerList.add(ListDataListener.class, pListener);
    }

    public void removeListDataListener(final ListDataListener pListener)
    {
        mListenerList.remove(ListDataListener.class, pListener);
    }
    
}
