package net.sf.cuf.state.ui;

import net.sf.cuf.state.AbstractStateAdapter;
import net.sf.cuf.state.State;
import net.sf.cuf.ui.DispatcherAction;

import javax.swing.AbstractButton;

/**
 * A SwingSelectedAdapter maps the enabeling/disabeling of of the monitored
 * state to the selection/unselection of a AbstractButton or DispatcherAction.
 */
public class SwingSelectedAdapter extends AbstractStateAdapter
{
    /**
     * Create a new adapter with no state associated.
     */
    public SwingSelectedAdapter()
    {
        super();
    }

    /**
     * Create a new adapter.
     * @param pState the state we adapt
     */
    public SwingSelectedAdapter(final State pState)
    {
        super(pState);
    }

    /**
     * We don't need special treatment for the inital step, and
     * just call processStateChange().
     * @param pTarget the target we should adjust
     * @param pEnabled the state for the target
     */
    protected void adjustInitialState(final Object pTarget, final boolean pEnabled)
    {
        processStateChange(pTarget, pEnabled);
    }

    /**
     * We map the pEnabled boolean to the selected/not selected behaviour of a
     * AbstractButton or a DispatcherAction.
     * @param pTarget  target object, either a AbstractButton or a DispatcherAction
     * @param pEnabled true if the target object should get "enabled"
     * @throws IllegalStateException if pTarget is not a AbstractButton or
     *                               DispatcherAction
     */
    protected void processStateChange(final Object pTarget, final boolean pEnabled)
    {
        if (pTarget instanceof AbstractButton)
        {
            AbstractButton button= (AbstractButton) pTarget;
            button.setSelected(pEnabled);
        }
        // start customize
        // if you don't want to use DispatcherAction, just uncomment lines until "end customize"
        else if (pTarget instanceof DispatcherAction)
        {
            DispatcherAction action= (DispatcherAction) pTarget;
            action.setSelected(pEnabled);
        }
        // end customize
        else
        {
            // you can add any objects but we won't handle them ;-)
            throw new IllegalStateException("we cant handle that object:"+pTarget);
        }
    }
}
