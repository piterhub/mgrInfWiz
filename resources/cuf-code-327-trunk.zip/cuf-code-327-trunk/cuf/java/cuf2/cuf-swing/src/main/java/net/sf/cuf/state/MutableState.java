package net.sf.cuf.state;

/**
 * The MutableState interface describes a mutable (more-or-less) binary
 * state.
 * In addition to a State, a MutableState can be changed via
 * setEnabled() and reset().
 */
public interface MutableState extends State
{
    /**
     * Sets the state.
     * @param pEnabled true if the state gets enabled
     */
    public void setEnabled(boolean pEnabled);

    /**
     * Sets the state with a reason object. The reason object
     * may be null, and is returned to a getChangeReason() call
     * during the callback.
     * @param pEnabled true if the state gets enabled
     * @param pReason null or reason for the change
     */
    public void setEnabled(boolean pEnabled, Object pReason);

    /**
     * Resets a MutableState to not initilized. Calling this
     * method will <b>not</b> trigger a notification of the
     * listeners.
     */
    public void reset();
}
