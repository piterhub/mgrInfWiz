package net.sf.cuf.model;

import java.util.Arrays;
import java.util.List;

/**
 * Simple test runner.
 */
@SuppressWarnings({"UseOfSystemOutOrSystemErr"})
public class LOVMapperRunner
{
    /**
     * We only need main.
     */
    private LOVMapperRunner()
    {
    }

    /**
     * entry point
     * @param pArgs not used
     */
    public static void main(final String[] pArgs )
    {
        ValueHolder     lofsHolder = new ValueHolder();
        ValueHolder     domainValue= new ValueHolder();
        LOVMapper       lovMapper  = new LOVMapper(lofsHolder, domainValue);
        SelectionInList sil        = new SelectionInList(lovMapper);
        String[] keys    = {"01", "02", "44"};
        String[] displays= {"München", "Hamburg", "Wien"};
        lofsHolder.setValue(new List[]{Arrays.asList(keys), Arrays.asList(displays)});

        System.out.println("current index: "+sil.getIndex());
        sil.selectionHolder().setValue(2);
        System.out.println("current domain value: "+domainValue.getValue());
        domainValue.setValue("02");
        System.out.println("current index: "+sil.getIndex());
    }
}
