package net.sf.cuf.ui.table;

import java.awt.Frame;
import javax.swing.JTable;


/**
 * Adapter over which {@link ContextMenuAction}s can access information about their context menu.
 */
public interface ContextMenuAdapter
{
    /**
     * Identifier of the context menu. This identifier should be used as a prefix of the action identifiers
     * used for internationalization.
     * @return  I18N identifier
     */
    public String getContextMenuKennung();

    /**
     * Reference to the table instance.
     * @return  table object
     */
    public JTable getTable();

    /**
     * Return view index of the column to work on.
     * This value is only valid during event dispatching.
     * @return  view column index or -1 if there is no applicable column
     */
    public int getViewColumnIndex();

    /**
     * Return model index of the column to work on.
     * This value is only valid during event dispatching.
     * @return  model column index or -1 if there is no applicable column
     */
    public int getModelColumnIndex();

    /**
     * Return index of the row to work on.
     * This value is only valid during event dispatching.
     * @return  row index or -1 if there is no applicable row
     */
    public int getRowIndex();

    /**
     * Determine the {@link Frame} the table resides in.
     * An exception is thrown if the table is not in a <code>Frame</code>.
     * @return  current frame
     * @throws  IllegalStateException  if the table does not (yet) reside in a <code>Frame</code>
     */
    public Frame getFrameForTable()
    throws IllegalStateException;
}