package net.sf.cuf.ui.table;


/**
 * Context menu action to hide a column of a {@link SortingTable}.
 * It is not possible to hide the last visible column this way.
 *
 * @author  Hendrik W&ouml;rdehoff, sd&amp;m AG
 */
public class ContextMenuActionHideColumn
extends ContextMenuAction
{
    public String getKennung()
    {
        return mAdapter.getContextMenuKennung()+"_HIDECOL";
    }

    /**
     * @return  <code>true</code> only if the user clicked on a column and this column is not the last visible column
     */
    public boolean isEnabled()
    {
        return (mAdapter.getViewColumnIndex() != -1) && (mAdapter.getTable().getColumnCount() > 1);
    }

    /**
     * The table returned by {@link ContextMenuAdapter#getTable} must be a {@link SortingTable}.
     */
    public void performAction()
    {
        ((SortingTable) mAdapter.getTable()).setColumnVisible(mAdapter.getModelColumnIndex(), false);
    }
}
