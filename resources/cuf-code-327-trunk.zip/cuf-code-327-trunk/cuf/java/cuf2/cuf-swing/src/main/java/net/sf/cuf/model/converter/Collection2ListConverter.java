package net.sf.cuf.model.converter;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import net.sf.cuf.model.ValueModel;

/**
 * Converts a {@link Collection} to {@link List} using the default order of the
 * collection as provided by the iterator. The converter is read only.
 * The implementation is not optimized for settings where {@link #getValue()}
 * is called often.
 */
public class Collection2ListConverter extends AbstractTypeConverter<List<?>, Collection<?>>
{

    /**
     * Constructor
     * @param pSubject the value model providing the {@link Collection}
     */
    public Collection2ListConverter(final ValueModel<Collection<?>> pSubject)
    {
        super(pSubject);
    }

    /**
     * throws an exception, since this converter is read only
     * {@inheritDoc}
     */
    public Collection<?> convertOwnToSubjectValue(final List<?> pOwnValue) throws ConversionException
    {
        throw new ConversionException( "Collection2ListConverter is read only", null);
    }

    /**
     * creates a list with the same content as the collection
     * {@inheritDoc}
     */
    public List<?> convertSubjectToOwnValue(final Collection<?> pSubjectValue) throws ConversionException
    {
        if (pSubjectValue==null)
        {
            return null;
        }
        List<?> result = new ArrayList(pSubjectValue);
        return result;
    }
}
