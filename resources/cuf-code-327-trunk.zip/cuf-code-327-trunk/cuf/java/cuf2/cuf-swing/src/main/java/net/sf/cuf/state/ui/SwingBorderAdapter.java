package net.sf.cuf.state.ui;

import net.sf.cuf.state.AbstractStateAdapter;
import net.sf.cuf.state.State;

import javax.swing.JComponent;
import javax.swing.UIManager;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;
import java.util.HashMap;
import java.util.Map;

/**
 * A SwingBorderAdapter adapts the "enabled" state to setting the
 * original Border of a JComponent, the "disabled" state is mapped
 * to setting the border supplied in the adapter's constructor
 * or in the setDisabledBorder method.
 */
public class SwingBorderAdapter extends AbstractStateAdapter
{
    /** the "disabled" border, never null */
    private Border                  mDisabledBorder;
    /** key= JComponent, value= original Border, map is never null */
    private Map<JComponent, Border> mOriginalBorder;

    /**
     * Create a new adapter with a state and a default disabled border.
     * @param pState the state we adapt
     */
    public SwingBorderAdapter(final State pState)
    {
        super(pState);
        Border disabledBorder= new LineBorder(UIManager.getColor("ComboBox.disabledForeground"));
        init(disabledBorder);
    }

    /**
     * Create a new adapter with no state associated.
     * @param pDisabledBorder the border for the disabled state, must not be null
     * @throws IllegalArgumentException if pDisabledBorder is null
     */
    public SwingBorderAdapter(final Border pDisabledBorder)
    {
        super();
        init(pDisabledBorder);
    }

    /**
     * Create a new adapter.
     * @param pState the state we adapt
     * @param pDisabledBorder the border for the disabled state, must not be null
     * @throws IllegalArgumentException if pDisabledBorder is null
     */
    public SwingBorderAdapter(final State pState, final Border pDisabledBorder)
    {
        super(pState);
        init(pDisabledBorder);
    }

    /**
     * Small helper for the constructors.
     * @param pDisabledBorder the border for the disabled state, must not be null
     */
    private void init(final Border pDisabledBorder)
    {
        if (pDisabledBorder==null)
        {
            throw new IllegalArgumentException("Border must not be null");
        }
        mOriginalBorder= new HashMap<JComponent, Border>(1);
        mDisabledBorder= pDisabledBorder;
    }

    /**
     * Sets the disabled border, the new border will be shown at the next
     * state change.
     * @param pDisabledBorder the border for the disabled state, must not be null
     */
    public void setBorder(final Border pDisabledBorder)
    {
        if (pDisabledBorder==null)
        {
            throw new IllegalArgumentException("Border must not be null");
        }
        mDisabledBorder= pDisabledBorder;
    }

    /**
     * We store the original border of the component, and call processStateChange()
     * afterwards.
     * @param pTarget the target we should adjust
     * @param pEnabled the state for the target
     */
    protected void adjustInitialState(final Object pTarget, final boolean pEnabled)
    {
        if (pTarget instanceof JComponent)
        {
            JComponent component = (JComponent) pTarget;
            mOriginalBorder.put(component, component.getBorder());
            processStateChange(pTarget, pEnabled);
        }
        else
        {
            // you can add any objects but we won't handle them ;-)
            throw new IllegalStateException("we cant handle that object:"+pTarget);
        }
    }

    /**
     * We map the pEnabled boolean to the setting/re-setting of a Border
     * on a JComponent.
     * @param pTarget  target object, must be a JComponent
     * @param pEnabled true if the target object should get "enabled"
     * @throws IllegalStateException if pTarget is not a JComponent
     */
    protected void processStateChange(final Object pTarget, final boolean pEnabled)
    {
        if (pTarget instanceof JComponent)
        {
            JComponent component = (JComponent) pTarget;
            if (pEnabled)
            {
                component.setBorder(mOriginalBorder.get(component));
            }
            else
            {
                component.setBorder(mDisabledBorder);
            }
        }
        else
        {
            // you can add any objects but we won't handle them ;-)
            throw new IllegalStateException("we cant handle that object:"+pTarget);
        }
    }
}
