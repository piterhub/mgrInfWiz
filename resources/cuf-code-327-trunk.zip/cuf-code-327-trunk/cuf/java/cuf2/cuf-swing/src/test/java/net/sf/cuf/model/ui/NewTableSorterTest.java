package net.sf.cuf.model.ui;

import java.util.Comparator;

import junit.framework.TestCase;

/**
 * a test for parts of the {@link NewTableSorter}
 */
public class NewTableSorterTest extends TestCase {

	/**
	 * tests some situations with the {@link NewTableSorter#LEXICAL_COMPARATOR}.
	 */
	public void testLexicalComparator()
	{
		Comparator comparator = NewTableSorter.LEXICAL_COMPARATOR;
		assertEquals(0,comparator.compare("", ""));
		assertTrue(0>comparator.compare("A", "B"));
		assertTrue(0<comparator.compare("B", "A"));
		assertEquals(0,comparator.compare(new ObjectWithExplicitToString(null), new ObjectWithExplicitToString(null)));
		assertTrue(0<comparator.compare(new ObjectWithExplicitToString("A"), new ObjectWithExplicitToString(null)));
		assertTrue(0>comparator.compare(new ObjectWithExplicitToString(null), new ObjectWithExplicitToString("B")));
	}
	
	/**
	 * test class which returns an explicit value on {@link #toString()}
	 */
	private static final class ObjectWithExplicitToString
	{
		private final String mToStringValue;

        public ObjectWithExplicitToString(String pToStringValue)
        {
			mToStringValue = pToStringValue;
		}

        @Override
		public String toString()
        {
			return mToStringValue;
		}
	}
	
}
