package net.sf.cuf.state;

import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

/**
 * Simple test driver
 */
public class SimpleStateExpressionRunner
{
    /**
     * We only need main.
     */
    private SimpleStateExpressionRunner()
    {
    }

    /**
     * Small test driver.
     * @param pArgs not used
     */
    public static void main(final String[] pArgs)
    {
        MutableState a= new SimpleState(true);
        MutableState b= new SimpleState(false);
        StateExpression c= new SimpleStateExpression(a);
        c.and(b);
        c.addChangeListener(new ChangeListener(){
            public void stateChanged(final ChangeEvent pEvent)
            {
                //noinspection UseOfSystemOutOrSystemErr
                System.out.println(pEvent);
            }
        });

        a.setEnabled(true, "eins");
        b.setEnabled(true, "zwei");
        b.setEnabled(false, "drei");
        a.setEnabled(false, "vier");
    }
}
