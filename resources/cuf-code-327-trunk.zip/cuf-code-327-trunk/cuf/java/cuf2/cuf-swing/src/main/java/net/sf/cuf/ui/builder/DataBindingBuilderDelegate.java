package net.sf.cuf.ui.builder;

import java.lang.reflect.Constructor;
import java.text.Format;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.swing.AbstractButton;
import javax.swing.ButtonGroup;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JTable;
import javax.swing.text.JTextComponent;

import net.sf.cuf.model.ExternalUpdate;
import net.sf.cuf.model.ui.FilteringListModelAdapter;
import org.jdom2.Element;

import net.sf.cuf.model.AspectAdapter;
import net.sf.cuf.model.BufferedValueHolder;
import net.sf.cuf.model.DelegateAccess;
import net.sf.cuf.model.IndexedAdapter;
import net.sf.cuf.model.LOVMapper;
import net.sf.cuf.model.MixedAccessAdapter;
import net.sf.cuf.model.MultiSelectionInList;
import net.sf.cuf.model.PropertiesAdapter;
import net.sf.cuf.model.SelectionInList;
import net.sf.cuf.model.ValueHolder;
import net.sf.cuf.model.ValueModel;
import net.sf.cuf.model.converter.FormatConverter;
import net.sf.cuf.model.converter.RegExpConverter;
import net.sf.cuf.model.converter.TypeConverter;
import net.sf.cuf.model.ui.ButtonModelAdapter;
import net.sf.cuf.model.ui.ComboBoxModelAdapter;
import net.sf.cuf.model.ui.DocumentAdapter;
import net.sf.cuf.model.ui.LOVAdapter;
import net.sf.cuf.model.ui.LabelAdapter;
import net.sf.cuf.model.ui.ListModelAdapter;
import net.sf.cuf.model.ui.ListTableMapper;
import net.sf.cuf.model.ui.MultiSelectionListModelAdapter;
import net.sf.cuf.model.ui.MultiSelectionTableModelAdapter;
import net.sf.cuf.model.ui.TableSelectionModel;
import net.sf.cuf.model.ui.ToolTipAdapter;

/**
 * The DataBindingBuilderDelegate class handles the "databinding" entry of
 * a xml2swing XML description.
 */
class DataBindingBuilderDelegate implements SwingXMLBuilder.BuilderDelegate
{
    /** the postfix for accessing the selection holder VM of a selection in list VM */
    private static final String SELECTION_HOLDER        = ".selectionHolder";
    /** the postfix for accessing the is index in list VM of a selection in list VM */
    private static final String IS_INDEX_IN_LIST_HOLDER = ".isIndexInList";
    /** the postfix for accessing the list VM of a selection in list VM */
    private static final String LIST_HOLDER             = ".listHolder";

    /**
     * Build the specific part of the delegate.
     * @param pBuilder the builder that controls the creation process
     * @param pDataBindingElement the JDOM element the delegate should handle, "databinding" in our case
     */
    public void build(final SwingXMLBuilder pBuilder, final Element pDataBindingElement)
    {
        List<Element> bindings= pDataBindingElement.getChildren();
        for (final Element element : bindings)
        {
            String objectType = element.getName();
            Object object = null;

            // get id
            String id = element.getAttributeValue(SwingXMLBuilder.ID_ATTRIBUTE);

            boolean found = true;
            try
            {
                if (objectType.equals(SwingXMLBuilder.VALUEHOLDER_ELEMENT))
                {
                    object = createValueHolder(element, id);
                }
                else if (objectType.equals(SwingXMLBuilder.BUFFEREDHOLDER_ELEMENT))
                {
                    object = createBufferdValueHolder(element, id, pBuilder);
                }
                else if (objectType.equals(SwingXMLBuilder.ASPECTADAPTER_ELEMENT))
                {
                    object = createAspectAdapter(element, id, pBuilder);
                }
                else if (objectType.equals(SwingXMLBuilder.INDEXEDADAPTER_ELEMENT))
                {
                    object = createIndexedAdapter(element, pBuilder);
                }
                else if (objectType.equals(SwingXMLBuilder.INDEXINLIST_ELEMENT))
                {
                    object = createIndexInList(element, id, pBuilder);
                }
                else if (objectType.equals(SwingXMLBuilder.PROPERTIESADAPTER_ELEMENT))
                {
                    object = createPropertiesAdapter(element, id, pBuilder);
                }
                else if (objectType.equals(SwingXMLBuilder.TYPECONVERTER_ELEMENT))
                {
                    object = createTypeConverter(element, id, pBuilder);
                }
                else if (objectType.equals(SwingXMLBuilder.FORMATCONVERTER_ELEMENT))
                {
                    object = createFormatConverter(element, id, pBuilder);
                }
                else if (objectType.equals(SwingXMLBuilder.REGEXPCONVERTER_ELEMENT))
                {
                    object = createRegexpConverter(element, id, pBuilder);
                }
                else if (objectType.equals(SwingXMLBuilder.CONVERTERINSYNC_ELEMENT))
                {
                    object = createConverterInSync(element, id, pBuilder);
                }
                else if (objectType.equals(SwingXMLBuilder.SELECTIONINLIST_ELEMENT))
                {
                    object = createSelectionInList(element, id, pBuilder);
                }
                else if (objectType.equals(SwingXMLBuilder.MULTISELECTIONINLIST_ELEMENT))
                {
                    object = createMultiSelectionInList(element, id, pBuilder);
                }
                else if (objectType.equals(SwingXMLBuilder.SETVALUE_ELEMENT))
                {
                    setValue(element, pBuilder);
                }
                else if (objectType.equals(SwingXMLBuilder.DOCUMENTADAPTER_ELEMENT))
                {
                    object = createDocumentAdapter(element, pBuilder);
                }
                else if (objectType.equals(SwingXMLBuilder.BUTTONADAPTER_ELEMENT))
                {
                    object = createButtonAdapter(element, pBuilder);
                }
                else if (objectType.equals(SwingXMLBuilder.COMBOBOXADAPTER_ELEMENT))
                {
                    object = createComboboxAdapter(element, pBuilder);
                }
                else if (objectType.equals(SwingXMLBuilder.LISTADAPTER_ELEMENT))
                {
                    object = createListAdapter(element, pBuilder);
                }
                else if (objectType.equals(SwingXMLBuilder.FILTERINGLISTADAPTER_ELEMENT))
                {
                    object = createFilteringListAdapter(element, pBuilder);
                }
                else if (objectType.equals(SwingXMLBuilder.TABLEADAPTER_ELEMENT))
                {
                    object = createTableAdapter(element, pBuilder);
                }
                else if (objectType.equals(SwingXMLBuilder.CHANGEACTION_ELEMENT))
                {
                    createListener(element, pBuilder);
                }
                else if (objectType.equals(SwingXMLBuilder.LOVMAPPER_ELEMENT))
                {
                    object = createLOVMapper(element, pBuilder);
                }
                else if (objectType.equals(SwingXMLBuilder.TOOLTIPADAPTER_ELEMENT))
                {
                    object = createToolTipAdapter(element, pBuilder);
                }
                else if (objectType.equals(SwingXMLBuilder.LABELADAPTER_ELEMENT))
                {
                    object = createLabelAdapter(element, pBuilder);
                }
                else if (objectType.equals(SwingXMLBuilder.LOVADAPTER_ELEMENT))
                {
                    object = createLOVAdapter(element, pBuilder);
                }
                else
                {
                    found = false;
                }
            }
            catch (IllegalArgumentException e)
            {
                throw SwingXMLBuilder.createException("problems during creating " + objectType,
                                                      e, element);
            }

            if (!found)
            {
                throw SwingXMLBuilder.createException("unknown data binding " + objectType,
                                                      element);
            }

            // put it in our builder's map
            if ((id != null) && (object != null))
            {
                if (pBuilder.getNameToNonVisual().containsKey(id))
                {
                    throw SwingXMLBuilder.createException("nonvisual with id " + id + " already defined", element);
                }
                else
                {
                    if (object instanceof ValueModel)
                    {
                        ((ValueModel<?>) object).setName(id);
                    }
                    pBuilder.getNameToNonVisual().put(id, object);
                }
            }

            // check if we should connect the value model to another
            String externalUpdateRef = element.getAttributeValue(SwingXMLBuilder.EXT_UPD_REF_ATTRIBUTE);
            if (externalUpdateRef!=null && object instanceof ValueModel)
            {
                Object externalUpdateVM = pBuilder.getNameToNonVisual().get(externalUpdateRef);
                if (!(externalUpdateVM instanceof ExternalUpdate))
                {
                    throw SwingXMLBuilder.createException("external update ref with id " + externalUpdateRef + " supports no external update", element);
                }

                ((ValueModel<?>) object).addChangeListener(new ExternalUpdateAdapter((ExternalUpdate)externalUpdateVM));
            }
        }
    }

    /**
     * Creates a new value holder.
     * @param pElement element describing the object
     * @param pId value of the id attribute of pElement
     * @throws IllegalArgumentException if we have a problem (parameters, ...)
     * @return the new value holder
     */
    private Object createValueHolder(final Element pElement, final String pId) throws IllegalArgumentException
    {
        if (pId==null)
            throw SwingXMLBuilder.createException("id of "+pElement.getName()+" must not be null", pElement);

        return new ValueHolder();
    }

    /**
     * Creates a new buffered value holder.
     * @param pElement element describing the object
     * @param pId value of the id attribute of pElement
     * @param pBuilder our builder
     * @throws IllegalArgumentException if we have a problem (parameters, ...)
     * @return the new buffered value holder
     */
    private Object createBufferdValueHolder(final Element pElement, final String pId, final SwingXMLBuilder pBuilder) throws IllegalArgumentException
    {
        if (pId==null)
            throw SwingXMLBuilder.createException("id of "+pElement.getName()+" must not be null", pElement);

        // get needed attributes
        String  subjectId= pElement.getAttributeValue(SwingXMLBuilder.SUBJECT_ATTRIBUTE);
        Object  subject  = pBuilder.getNonVisualObject(subjectId);
        String  triggerId= pElement.getAttributeValue(SwingXMLBuilder.TRIGGER_ATTRIBUTE);
        Object  trigger  = pBuilder.getNonVisualObject(triggerId);
        boolean deepCopy = (pElement.getAttribute(SwingXMLBuilder.DEEPCOPY_ATTRIBUTE) != null);

        if (!(subject instanceof ValueModel))
            throw SwingXMLBuilder.createException("no subject found for "+subjectId, pElement);
        if (!(trigger instanceof ValueModel))
            throw SwingXMLBuilder.createException("no trigger found for "+triggerId, pElement);

        return new BufferedValueHolder((ValueModel<?>)subject,(ValueModel<?>)trigger,deepCopy);
    }

    /**
     * Creates a new aspect adapter value model.
     * @param pElement element describing the object
     * @param pId value of the id attribute of pElement
     * @param pBuilder our builder
     * @throws IllegalArgumentException if we have a problem (parameters, ...)
     * @return the new aspect adapter
     */
    private Object createAspectAdapter(final Element pElement, final String pId, final SwingXMLBuilder pBuilder) throws IllegalArgumentException
    {
        if (pId==null)
            throw SwingXMLBuilder.createException("id of "+pElement.getName()+" must not be null", pElement);
        AspectAdapter<?,?> aspectAdapter;

        // get needed attributes
        String  triggerId       = pElement.getAttributeValue(SwingXMLBuilder.TRIGGER_ATTRIBUTE);
        Object  trigger         = pBuilder.getNonVisualObject(triggerId);
        String  getPrefix       = pElement.getAttributeValue(SwingXMLBuilder.GETPREFIX_ATTRIBUTE);
        String  setPrefix       = pElement.getAttributeValue(SwingXMLBuilder.SETPREFIX_ATTRIBUTE);
        String  access          = pElement.getAttributeValue(SwingXMLBuilder.ACCESS_ATTRIBUTE);

        if (!(trigger instanceof ValueModel))
        {
            throw SwingXMLBuilder.createException("no trigger found for "+triggerId, pElement);
        }

        Class<?> sourceClass = SwingXMLBuilder.getClass(pElement);
        if (getPrefix==null) getPrefix= AspectAdapter.GET;
        if (setPrefix==null) setPrefix= AspectAdapter.SET;

        if (sourceClass==null)
            aspectAdapter= new AspectAdapter((ValueModel<?>)trigger, access, getPrefix, setPrefix);
        else
            aspectAdapter= new AspectAdapter((ValueModel<?>)trigger, sourceClass, access, getPrefix, setPrefix);

        return aspectAdapter;
    }

    /**
     * Creates a new indexed adapter value model.
     * @param pElement element describing the object
     * @param pBuilder our builder
     * @throws IllegalArgumentException if we have a problem (parameters, ...)
     * @return the new indexed adapter
     */
    private Object createIndexedAdapter(final Element pElement, final SwingXMLBuilder pBuilder) throws IllegalArgumentException
    {
        String            triggerId     = pElement.getAttributeValue(SwingXMLBuilder.TRIGGER_ATTRIBUTE);
        ValueModel<?>     trigger       = getValueModel(pElement, triggerId, pBuilder);
        IndexedAdapter<?> indexedAdapter= new IndexedAdapter(trigger);

        return indexedAdapter;
    }

    /**
     * Creates a new ValueModel for the index-in-sync value model of an indexed adapter value model.
     * @param pElement element describing the object
     * @param pId value of the id attribute of pElement
     * @param pBuilder our builder
     * @throws IllegalArgumentException if we have a problem (parameters, ...)
     * @return the new index-in-list ValueModel
     */
    private Object createIndexInList(final Element pElement, final String pId, final SwingXMLBuilder pBuilder) throws IllegalArgumentException
    {
        if (pId==null)
            throw SwingXMLBuilder.createException("id of "+pElement.getName()+" must not be null", pElement);
        String         triggerId     = pElement.getAttributeValue(SwingXMLBuilder.REF_ATTRIBUTE);
        ValueModel<?>  trigger       = getValueModel(pElement, triggerId, pBuilder);
        if (!(trigger instanceof IndexedAdapter))
        {
            throw SwingXMLBuilder.createException("no IndexedAdapter found for "+triggerId, pElement);
        }
        ValueModel<?> indexInList= ((IndexedAdapter<?>)trigger).isIndexInList();

        return indexInList;
    }

    /**
     * Creates a new properties adapter value model.
     * @param pElement element describing the object
     * @param pId value of the id attribute of pElement
     * @param pBuilder our builder
     * @throws IllegalArgumentException if we have a problem (parameters, ...)
     * @return the new prperties adapter
     */
    private Object createPropertiesAdapter(final Element pElement, final String pId, final SwingXMLBuilder pBuilder) throws IllegalArgumentException
    {
        if (pId==null)
            throw SwingXMLBuilder.createException("id of "+pElement.getName()+" must not be null", pElement);
        String key         = pElement.getAttributeValue(SwingXMLBuilder.KEY_ATTRIBUTE);
        String defaultValue= pElement.getAttributeValue(SwingXMLBuilder.DEFAULT_ATTRIBUTE);
        Object properties  = pBuilder.getNonVisualObject(
                                pElement.getAttributeValue(SwingXMLBuilder.REF_ATTRIBUTE));

        if (!(properties instanceof Properties))
        {
            throw SwingXMLBuilder.createException("not properties object found for "+key, pElement);
        }

        return new PropertiesAdapter((Properties)properties, key, defaultValue);
    }

    /**
     * Creates a new type converter value model.
     * @param pElement element describing the object
     * @param pId value of the id attribute of pElement
     * @param pBuilder our builder
     * @throws IllegalArgumentException if we have a problem (parameters, ...)
     * @return the new type converter
     */
    private Object createTypeConverter(final Element pElement, final String pId, final SwingXMLBuilder pBuilder) throws IllegalArgumentException
    {
        if (pId == null)
            throw SwingXMLBuilder.createException("id of "+pElement.getName()+" must not be null", pElement);
        TypeConverter<?,?> typeConverter;

        // get needed attributes
        String triggerId = pElement.getAttributeValue(SwingXMLBuilder.TRIGGER_ATTRIBUTE);
        Object trigger = pBuilder.getNonVisualObject(triggerId);

        if (!(trigger instanceof ValueModel))
        {
            throw SwingXMLBuilder.createException("no trigger found for "+triggerId, pElement);
        }

        Class<?> converterClass = SwingXMLBuilder.getClass(pElement);
        if (!TypeConverter.class.isAssignableFrom(converterClass))
        {
            throw SwingXMLBuilder.createException("class parameter (" +
                                                  converterClass.getName() +
                                                  ") is not a TypeConverter", pElement);
        }
        try
        {
            Constructor<TypeConverter<?,?>> constructor = ((Class<TypeConverter<?,?>>)converterClass).getConstructor(ValueModel.class);
            typeConverter = constructor.newInstance(trigger);
        }
        catch (Exception e)
        {
            throw SwingXMLBuilder.createException("Could not instantiate type converter " +
                                                  converterClass.getName(), e, pElement);
        }

        return typeConverter;
    }

    /**
     * Creates a new format converter value model.
     * @param pElement element describing the object
     * @param pId value of the id attribute of pElement
     * @param pBuilder our builder
     * @throws IllegalArgumentException if we have a problem (parameters, ...)
     * @return the new format converter
     */
    private Object createFormatConverter(final Element pElement, final String pId, final SwingXMLBuilder pBuilder) throws IllegalArgumentException
    {
        if (pId == null)
            throw SwingXMLBuilder.createException("id of "+pElement.getName()+" must not be null", pElement);
        Format format;

        // get needed attributes
        String  triggerId= pElement.getAttributeValue(SwingXMLBuilder.TRIGGER_ATTRIBUTE);
        Object  trigger  = pBuilder.getNonVisualObject(triggerId);
        boolean invert   = "true".equals(pElement.getAttributeValue(SwingXMLBuilder.INVERT_ATTRIBUTE));

        if (!(trigger instanceof ValueModel))
        {
            throw SwingXMLBuilder.createException("no trigger found for "+triggerId, pElement);
        }

        Class<?> formatClass = SwingXMLBuilder.getClass(pElement);
        if (!Format.class.isAssignableFrom(formatClass))
        {
            throw SwingXMLBuilder.createException("class parameter (" +
                                                  formatClass.getClass().getName() +
                                                  ") is not a Format", pElement);
        }
        String formatString = pElement.getAttributeValue(SwingXMLBuilder.FORMAT_ATTRIBUTE);
        if (formatString == null)
        {
            try
            {
                format = (Format) formatClass.newInstance();
            }
            catch (Exception e)
            {
                throw SwingXMLBuilder.createException("Could not instantiate Format " +
                                                      formatClass.getClass().getName(), e, pElement);
            }
        }
        else
        {
            try
            {
                Constructor<Format> constructor = ((Class<Format>)formatClass).getConstructor(String.class);
                format = constructor.newInstance(formatString);
            }
            catch (Exception e)
            {
                throw SwingXMLBuilder.createException("Could not instantiate Format " +
                                                      formatClass.getClass().getName()+
                                                      " with format " + formatString, e, pElement);
            }
        }

        return new FormatConverter((ValueModel<?>) trigger, format, invert);
    }

    /**
     * Creates a new regexp converter value model.
     * @param pElement element describing the object
     * @param pId value of the id attribute of pElement
     * @param pBuilder our builder
     * @throws IllegalArgumentException if we have a problem (parameters, ...)
     * @return the new regexp converter
     */
    private Object createRegexpConverter(final Element pElement, final String pId, final SwingXMLBuilder pBuilder) throws IllegalArgumentException
    {
        if (pId == null)
            throw SwingXMLBuilder.createException("id of "+pElement.getName()+" must not be null", pElement);

        // get needed attributes
        String triggerId  = pElement.getAttributeValue(SwingXMLBuilder.TRIGGER_ATTRIBUTE);
        Object trigger    = pBuilder.getNonVisualObject(triggerId);
        String blockValue = pElement.getAttributeValue( SwingXMLBuilder.BLOCK_ATTRIBUTE);
        // (default for block is true)
        
        if (!(trigger instanceof ValueModel))
        {
            throw SwingXMLBuilder.createException("no trigger found for "+triggerId, pElement);
        }

        String formatString = pElement.getAttributeValue(SwingXMLBuilder.FORMAT_ATTRIBUTE);
        if (formatString == null)
        {
            throw SwingXMLBuilder.createException("no regexp found for "+triggerId, pElement);
        }
        else
        {
            try
            {
                if (blockValue==null)
                {
                    return new RegExpConverter((ValueModel<String>) trigger, formatString);
                }
                else
                {
                    boolean block = "true".equals( blockValue);
                    return new RegExpConverter((ValueModel<String>) trigger, formatString, block);
                }
            }
            catch (Exception e)
            {
                throw SwingXMLBuilder.createException("Could not instantiate RegExpConverter " +
                                                      " with regular expression " + formatString, e, pElement);
            }
        }

    }

    /**
     * Creates a new value model holding the sync information of a type converter value model.
     * @param pElement element describing the object
     * @param pId value of the id attribute of pElement
     * @param pBuilder our builder
     * @throws IllegalArgumentException if we have a problem (parameters, ...)
     * @return the new converter-in-sync ValueModel
     */
    private Object createConverterInSync(final Element pElement, final String pId, final SwingXMLBuilder pBuilder) throws IllegalArgumentException
    {
        if (pId==null)
            throw SwingXMLBuilder.createException("id of "+pElement.getName()+" must not be null", pElement);
        String         triggerId     = pElement.getAttributeValue(SwingXMLBuilder.REF_ATTRIBUTE);
        ValueModel<?>  trigger       = getValueModel(pElement, triggerId, pBuilder);
        if (!(trigger instanceof TypeConverter))
        {
            throw SwingXMLBuilder.createException("no TypeConverter found for "+triggerId, pElement);
        }
        ValueModel<Boolean> converterInSync= ((TypeConverter<?,?>)trigger).getSyncState();

        return converterInSync;
    }

    /**
     * Creates a new selection in list value model.
     * @param pElement element describing the object
     * @param pId value of the id attribute of pElement
     * @param pBuilder our builder
     * @throws IllegalArgumentException if we have a problem (parameters, ...)
     * @return the new selection-in-list ValueModel
     */
    private Object createSelectionInList(final Element pElement, final String pId, final SwingXMLBuilder pBuilder) throws IllegalArgumentException
    {
        if (pId==null)
            throw SwingXMLBuilder.createException("id of "+pElement.getName()+" must not be null", pElement);
        String modelref  = pElement.getAttributeValue(SwingXMLBuilder.MODELREF_ATTRIBUTE);
        Object listholder= pBuilder.getNonVisualObject(modelref);
        if (!(listholder instanceof ValueModel))
        {
            throw SwingXMLBuilder.createException("not a ValueModel found for "+modelref, pElement);
        }

        return new SelectionInList((ValueModel<List<?>>)listholder);
    }

    /**
     * Creates a new multiple selection in list value model.
     * @param pElement element describing the object
     * @param pId value of the id attribute of pElement
     * @param pBuilder our builder
     * @throws IllegalArgumentException if we have a problem (parameters, ...)
     * @return the new multi-selection-in-list ValueModel
     */
    private Object createMultiSelectionInList(final Element pElement, final String pId, final SwingXMLBuilder pBuilder) throws IllegalArgumentException
    {
        if (pId==null)
            throw SwingXMLBuilder.createException("id of "+pElement.getName()+" must not be null", pElement);
        String modelref  = pElement.getAttributeValue(SwingXMLBuilder.MODELREF_ATTRIBUTE);
        Object listholder= pBuilder.getNonVisualObject(modelref);
        if (!(listholder instanceof ValueModel))
        {
            throw SwingXMLBuilder.createException("not a ValueModel found for "+modelref, pElement);
        }

        return new MultiSelectionInList((ValueModel<?>)listholder);
    }

    /**
     * Set a value in a ValueModel.
     * @param pElement element describing the object
     * @param pBuilder our builder
     * @throws IllegalArgumentException if we have a problem (parameters, ...)
     */
    private void setValue(final Element pElement, final SwingXMLBuilder pBuilder) throws IllegalArgumentException
    {
        // determine the value
        Object     value;
        String     className    = pElement.getAttributeValue(SwingXMLBuilder.CLASS_ATTRIBUTE);
        String     booleanValue = pElement.getAttributeValue(SwingXMLBuilder.BOOLEAN_ATTRIBUTE);
        if (className!=null)
        {
            // use a new object as value
            try
            {
                value    = Class.forName(className).newInstance();
            }
            catch (Exception e)
            {
                throw SwingXMLBuilder.createException("Could not instantiate a object from " +
                                                      className, e, pElement);
            }
        }
        else if (booleanValue!=null)
        {
            value = Boolean.valueOf( booleanValue);
        }
        else
        {
            // use pcdata as value
            value= pElement.getText();
        }
        // determine the target of the setValue
        String     modelRef     = pElement.getAttributeValue(SwingXMLBuilder.MODELREF_ATTRIBUTE);
        String     ref          = pElement.getAttributeValue(SwingXMLBuilder.REF_ATTRIBUTE);
        String     access       = pElement.getAttributeValue(SwingXMLBuilder.ACCESS_ATTRIBUTE);
        if ((modelRef==null && ref==null) || (modelRef!=null && ref!=null))
        {
            throw SwingXMLBuilder.createException( SwingXMLBuilder.SETVALUE_ELEMENT+
                    " must have either a "+SwingXMLBuilder.MODELREF_ATTRIBUTE+
                    " attribute or a "+SwingXMLBuilder.REF_ATTRIBUTE+" attribute",
                    pElement);
        }
        if (modelRef!=null)
        {
            ValueModel<?> valueModel= getValueModel(pElement, modelRef, pBuilder);
            valueModel.setObjectValue(value);
        }
        else
        {
            Object target = pBuilder.getNonVisualObject( ref);
            if (target==null)
            {
                throw SwingXMLBuilder.createException( "Could not find a nonvisual object with id "+ref, pElement);
            }
            if (access==null)
            {
                throw SwingXMLBuilder.createException( "attribute "+SwingXMLBuilder.ACCESS_ATTRIBUTE+
                        " required with "+SwingXMLBuilder.REF_ATTRIBUTE);
            }
            MixedAccessAdapter accessAdapter = new MixedAccessAdapter( access);
            accessAdapter.setValue( target, value);
        }
    }

    /**
     * Creates an adapter between a ValueModel and a JTextComponent.
     * @param pElement element describing the object
     * @param pBuilder our builder
     * @throws IllegalArgumentException if we have a problem (parameters, ...)
     * @return the new document adapter
     */
    private Object createDocumentAdapter(final Element pElement, final SwingXMLBuilder pBuilder) throws IllegalArgumentException
    {
        String              modelRef         = pElement.getAttributeValue(SwingXMLBuilder.MODELREF_ATTRIBUTE);
        ValueModel<String>  valueModel       = (ValueModel<String>)getValueModel(pElement, modelRef, pBuilder);
        String              textComponentName= pElement.getAttributeValue(SwingXMLBuilder.WIDGETREF_ATTRIBUTE);
        Object              textComponent    = pBuilder.getComponentByAnyName(textComponentName);
        if (!(textComponent instanceof JTextComponent))
        {
            throw SwingXMLBuilder.createException("no JTextComponent found for "+textComponentName, pElement);
        }

        return new DocumentAdapter(valueModel, (JTextComponent)textComponent);
    }

    /**
     * Creates an adapter between a ValueModel and a AbstractButton.
     * @param pElement element describing the object
     * @param pBuilder our builder
     * @throws IllegalArgumentException if we have a problem (parameters, ...)
     * @return the new button adapter
     */
    private Object createButtonAdapter(final Element pElement, final SwingXMLBuilder pBuilder) throws IllegalArgumentException
    {
        String              modelRef           = pElement.getAttributeValue(SwingXMLBuilder.MODELREF_ATTRIBUTE);
        ValueModel<Boolean> valueModel         = (ValueModel<Boolean>)getValueModel(pElement, modelRef, pBuilder);
        String              buttonComponentName= pElement.getAttributeValue(SwingXMLBuilder.WIDGETREF_ATTRIBUTE);
        Object              buttonComponent    = pBuilder.getComponentByAnyName(buttonComponentName);
        String              invert             = pElement.getAttributeValue(SwingXMLBuilder.INVERT_ATTRIBUTE);
        if (!(buttonComponent instanceof AbstractButton))
        {
            throw SwingXMLBuilder.createException("no AbstractButton found for "+buttonComponentName, pElement);
        }


        return new ButtonModelAdapter(valueModel,
                                      ((AbstractButton)buttonComponent).getModel(),
                                      "true".equals(invert));
    }

    /**
     * Creates an adapter between a ValueModel and a JComboBox.
     * @param pElement element describing the object
     * @param pBuilder our builder
     * @throws IllegalArgumentException if we have a problem (parameters, ...)
     * @return the new combobox adapter
     */
    private Object createComboboxAdapter(final Element pElement, final SwingXMLBuilder pBuilder) throws IllegalArgumentException
    {
        String              modelRef             = pElement.getAttributeValue(SwingXMLBuilder.MODELREF_ATTRIBUTE);
        ValueModel<Integer> valueModel           = (ValueModel<Integer>)getValueModel(pElement, modelRef, pBuilder);
        String              comboboxComponentName= pElement.getAttributeValue(SwingXMLBuilder.WIDGETREF_ATTRIBUTE);
        Object              comboboxComponent    = pBuilder.getComponentByAnyName(comboboxComponentName);
        if (!(comboboxComponent instanceof JComboBox))
        {
            throw SwingXMLBuilder.createException("no JComboBox found for "+comboboxComponentName, pElement);
        }

        return new ComboBoxModelAdapter(valueModel, ((JComboBox)comboboxComponent).getModel());
    }

    /**
     * Creates an adapter between a SelectionInList ValueModel and a JList.
     * @param pElement element describing the object
     * @param pBuilder our builder
     * @throws IllegalArgumentException if we have a problem (parameters, ...)
     * @return the new list adapter
     */
    private Object createListAdapter(final Element pElement, final SwingXMLBuilder pBuilder) throws IllegalArgumentException
    {
        String         modelRef             = pElement.getAttributeValue(SwingXMLBuilder.MODELREF_ATTRIBUTE);
        ValueModel<?>  selectionValueModel  = getValueModel(pElement, modelRef, pBuilder);

        String         accessRef            = pElement.getAttributeValue(SwingXMLBuilder.ACCESSREF_ATTRIBUTE);
        DelegateAccess accessValueModel     = null;
        if (accessRef != null)
        {
            accessValueModel= getDelegateAccess(pElement, accessRef, pBuilder);
        }

        String listComponentName= pElement.getAttributeValue(SwingXMLBuilder.WIDGETREF_ATTRIBUTE);
        Object listComponent    = pBuilder.getComponentByAnyName(listComponentName);

        if (listComponent instanceof JList)
        {
            if (selectionValueModel instanceof SelectionInList)
            {
                return new ListModelAdapter((JList) listComponent,
                        (SelectionInList<?>) selectionValueModel,
                        accessValueModel);
            }
            else if (selectionValueModel instanceof MultiSelectionInList)
            {
                return new MultiSelectionListModelAdapter((JList) listComponent,
                        (MultiSelectionInList) selectionValueModel,
                        accessValueModel);
            }
            else 
            {
                throw SwingXMLBuilder.createException("no SelectionInList or MultiSelectionInList ValueModel found for "+modelRef, pElement);
            }

        }
        else if (listComponent instanceof JComboBox)
        {
            if (!(selectionValueModel instanceof SelectionInList))
            {
                throw SwingXMLBuilder.createException("no SelectionInList ValueModel found for "+modelRef, pElement);
            }
            
            return new ListModelAdapter((JComboBox) listComponent,
                                        (SelectionInList<?>) selectionValueModel,
                                        accessValueModel);
        }
        else
        {
            throw SwingXMLBuilder.createException("no JList or JComboBox found for "+listComponentName, pElement);
        }
    }

    /**
     * Creates an filtering adapter between a SelectionInList ValueModel and a JComboBox.
     * @param pElement element describing the object
     * @param pBuilder our builder
     * @throws IllegalArgumentException if we have a problem (parameters, ...)
     * @return the new list adapter
     */
    private Object createFilteringListAdapter(final Element pElement, final SwingXMLBuilder pBuilder) throws IllegalArgumentException
    {
        String         modelRef             = pElement.getAttributeValue(SwingXMLBuilder.MODELREF_ATTRIBUTE);
        ValueModel     selectionValueModel  = getValueModel(pElement, modelRef, pBuilder);

        String         accessRef            = pElement.getAttributeValue(SwingXMLBuilder.ACCESSREF_ATTRIBUTE);
        DelegateAccess accessValueModel     = null;
        if (accessRef != null)
        {
            accessValueModel= getDelegateAccess(pElement, accessRef, pBuilder);
        }

        String listComponentName= pElement.getAttributeValue(SwingXMLBuilder.WIDGETREF_ATTRIBUTE);
        Object listComponent    = pBuilder.getComponentByAnyName(listComponentName);

        if (listComponent instanceof JComboBox)
        {
            if (!(selectionValueModel instanceof SelectionInList))
            {
                throw SwingXMLBuilder.createException("no SelectionInList ValueModel found for "+modelRef, pElement);
            }

            selectionValueModel.setValue(new ArrayList());
            return new FilteringListModelAdapter((JComboBox) listComponent,
                                                 (SelectionInList) selectionValueModel,
                                                 accessValueModel);
        }
        else
        {
            throw SwingXMLBuilder.createException("no JComboBox found for " + listComponentName, pElement);
        }
    }

    /**
     * Creates a TableSelectionModel or a ListTableMapper adapter between a ValueModel and a JTable.
     * @param pElement element describing the object
     * @param pBuilder our builder
     * @throws IllegalArgumentException if we have a problem (parameters, ...)
     * @return the new table adapter
     */
    private Object createTableAdapter(final Element pElement, final SwingXMLBuilder pBuilder) throws IllegalArgumentException
    {
        String         modelRef  = pElement.getAttributeValue(SwingXMLBuilder.MODELREF_ATTRIBUTE);
        ValueModel<?>  valueModel= getValueModel(pElement, modelRef, pBuilder);
        String         tableName = pElement.getAttributeValue(SwingXMLBuilder.WIDGETREF_ATTRIBUTE);
        Object         table     = pBuilder.getComponentByAnyName(tableName);
        if (!(table instanceof JTable))
        {
            throw SwingXMLBuilder.createException("no JTable found for "+tableName, pElement);
        }

        // we generate a TableSelectionModel if there is a class attribute,
        // and a ListTableMapper if not, only the TableSelectionModel supports editing a column
        Object back;
        Class<?>  listEntryClass= SwingXMLBuilder.getClass(pElement);
        if (listEntryClass!=null)
        {
            /*
             * case TableSelectionModel
             */
            if (!(valueModel instanceof SelectionInList))
            {
                throw SwingXMLBuilder.createException("no ValueModel of type SelectionInList found for "+modelRef, pElement);
            }

            // check if table is sortable
            boolean sortable= "true".equals(pElement.getAttributeValue(SwingXMLBuilder.SORTABLE_ATTRIBUTE));

            // build mapping
            List<Element>                     mappingElements= pElement.getChildren(SwingXMLBuilder.COLUMN_ELEMENT);
            List<TableSelectionModel.Mapping> mappings       = new ArrayList(mappingElements.size());
            for (final Element element : mappingElements)
            {
                StringBuilder errorInfo = new StringBuilder();
                try
                {
                    String  attributName= element.getAttributeValue(SwingXMLBuilder.ACCESS_ATTRIBUTE);
                    errorInfo.append("\nattributName :").append(attributName);
                    String  isEditable= element.getAttributeValue(SwingXMLBuilder.EDITABLE_ATTRIBUTE);
                    errorInfo.append("\nisEditable :").append(isEditable);
                    String  columnTitle = pBuilder.getTitle(element);
                    errorInfo.append("\ncolumnTitle :").append(columnTitle);
                    String  columnAlignment = element.getAttributeValue(SwingXMLBuilder.ALIGN_ATTRIBUTE);
                    errorInfo.append("\ncolumnAlignment :").append(columnAlignment);
                    Class<?> columnClass = SwingXMLBuilder.getClass(element);
                    errorInfo.append("\ncolumnClass :").append(columnClass);

                    TableSelectionModel.Mapping mapping= new TableSelectionModel.Mapping(
                            attributName, Boolean.valueOf(isEditable),
                            columnTitle, columnAlignment, columnClass);
                    mappings.add(mapping);
                }
                catch (Exception e)
                {
                    throw SwingXMLBuilder.createException("could not read mapping for the tableadapter"+
                                                          errorInfo.toString(),
                                                          e, element);
                }
            }

            // create adapter
            TableSelectionModel tableSelectionModel= new TableSelectionModel(
                    (JTable)table, (SelectionInList<?>)valueModel,
                    listEntryClass, mappings, sortable);

            back= tableSelectionModel;
        }
        else
        {
            /*
             * case ListTableMapper
             */
            if (!(valueModel instanceof SelectionInList || valueModel instanceof MultiSelectionInList))
            {
                throw SwingXMLBuilder.createException("no ValueModel of type SelectionInList or MultiSelectionInList found for "+modelRef, pElement);
            }

            // check if table is sortable
            boolean sortable= "true".equals(pElement.getAttributeValue(SwingXMLBuilder.SORTABLE_ATTRIBUTE));

            // build mapping
            List<Element>                 mappingElements= pElement.getChildren(SwingXMLBuilder.COLUMN_ELEMENT);
            List<ListTableMapper.Mapping> mappings       = new ArrayList(mappingElements.size());
            for (final Element element : mappingElements)
            {
                try
                {
                    String         columnTitle          = pBuilder.getTitle(element);
                    String         columnAlignment      = element.getAttributeValue(SwingXMLBuilder.ALIGN_ATTRIBUTE);
                    Class<?>       columnClass          = SwingXMLBuilder.getClass(element);
                    String         columnPrefWidth      = element.getAttributeValue(SwingXMLBuilder.PREF_WIDTH_ATTRIBUTE);
                    String         columnModelRef       = element.getAttributeValue(SwingXMLBuilder.MODELREF_ATTRIBUTE);
                    DelegateAccess columnValueModel     = getDelegateAccess(element, columnModelRef, pBuilder);
                    String         columnModelSortRef   = element.getAttributeValue(SwingXMLBuilder.MODELREF_ATTRIBUTE);
                    DelegateAccess columnValueModelSort = (DelegateAccess)pBuilder.getNonVisualObject(columnModelSortRef);
                    boolean        columnSortable       = "true".equals(element.getAttributeValue(SwingXMLBuilder.SORTABLE_ATTRIBUTE));
                    String         columnComparatorClass= element.getAttributeValue(SwingXMLBuilder.COMPARATORCLASS_ATTRIBUTE);

                    ListTableMapper.Mapping mapping=
                            new ListTableMapper.Mapping(columnTitle,
                                                        columnAlignment,
                                                        columnPrefWidth,
                                                        columnClass,
                                                        columnValueModel,
                                                        columnValueModelSort,
                                                        columnSortable,
                                                        columnComparatorClass);
                    mappings.add(mapping);
                }
                catch (Exception e)
                {
                    throw SwingXMLBuilder.createException("could not read mapping for the tableadapter",
                                                          e, element);
                }
            }

            // get column for initial sorting
            String      columnInitialSorting   = pElement.getAttributeValue(SwingXMLBuilder.INITIAL_SORTING_COLUMN_ATTRIBUTE);
            int         columnForInitialSorting= -1;
            try
            {
                columnForInitialSorting = Integer.parseInt(columnInitialSorting);
            }
            catch (Exception e)
            {
                // ignore exception -> no initial sorting for this table
            }

            // create adapter
            if (valueModel instanceof SelectionInList)
            {
                ListTableMapper listTableMapper=
                       new ListTableMapper((JTable)table,
                                           (SelectionInList<?>)valueModel,
                                           mappings,
                                           sortable,
                                           columnForInitialSorting);
                back= listTableMapper;
            }
            else
            {
                MultiSelectionTableModelAdapter multiListTableAdapter=
                        new MultiSelectionTableModelAdapter((JTable)table,
                                                            (MultiSelectionInList)valueModel,
                                                            mappings,
                                                            sortable,
                                                            columnForInitialSorting);
                back= multiListTableAdapter;
            }
        }

        return back;
    }

    /**
     * Connects a dependent to a ValueModel.
     * @param pElement element describing the object
     * @param pBuilder our builder
     */
    private void createListener(final Element pElement, final SwingXMLBuilder pBuilder)
    {
        String         source    = pElement.getAttributeValue(SwingXMLBuilder.SOURCE_ATTRIBUTE);
        ValueModel<?>  valueModel= getValueModel(pElement, source, pBuilder);
        String         targetName= pElement.getAttributeValue(SwingXMLBuilder.TARGET_ATTRIBUTE);
        Object         target    = pBuilder.getNonVisualObject(targetName);
        String         methodName= pElement.getAttributeValue(SwingXMLBuilder.METHOD_ATTRIBUTE);

        if (target == null)
        {
            throw SwingXMLBuilder.createException("no target object found for "+targetName, pElement);
        }

        valueModel.onChangeSend(target, methodName);
    }

    /**
     * Creates and returns a LOVMapper object.
     * @param pElement element describing the object
     * @param pBuilder our builder
     * @throws IllegalArgumentException if we have a problem (parameters, ...)
     * @return the list-of-values mapper
     */
    private Object createLOVMapper(final Element pElement, final SwingXMLBuilder pBuilder)
    {
        String                lovsRef   = pElement.getAttributeValue(SwingXMLBuilder.LOVSREF_ATTRIBUTE);
        ValueModel<List<?>[]> lofsHolder= (ValueModel<List<?>[]>)getValueModel(pElement, lovsRef, pBuilder);
        String                modelRef  = pElement.getAttributeValue(SwingXMLBuilder.MODELREF_ATTRIBUTE);
        ValueModel<?>         domainVM  = getValueModel(pElement, modelRef, pBuilder);

        return new LOVMapper(lofsHolder, domainVM);
    }

    /**
     * Creates an adapter between a ValueModel and a the tooltip of a JComponent.
     * @param pElement element describing the object
     * @param pBuilder our builder
     * @throws IllegalArgumentException if we have a problem (parameters, ...)
     * @return the tool tip adapter
     */
    private Object createToolTipAdapter(final Element pElement, final SwingXMLBuilder pBuilder) throws IllegalArgumentException
    {
        String         modelRef     = pElement.getAttributeValue(SwingXMLBuilder.MODELREF_ATTRIBUTE);
        ValueModel<?>  valueModel   = getValueModel(pElement, modelRef, pBuilder);
        String         componentName= pElement.getAttributeValue(SwingXMLBuilder.WIDGETREF_ATTRIBUTE);
        Object         component    = pBuilder.getComponentByAnyName(componentName);
        if (!(component instanceof JComponent))
        {
            throw SwingXMLBuilder.createException("no JComponent found for "+componentName, pElement);
        }

        return new ToolTipAdapter(valueModel, (JComponent)component);
    }

    /**
     * Creates an adapter between a ValueModel and a JLabel.
     * @param pElement element describing the object
     * @param pBuilder our builder
     * @throws IllegalArgumentException if we have a problem (parameters, ...)
     * @return the label adapter
     */
    private Object createLabelAdapter(final Element pElement, final SwingXMLBuilder pBuilder) throws IllegalArgumentException
    {
        String         modelRef  = pElement.getAttributeValue(SwingXMLBuilder.MODELREF_ATTRIBUTE);
        ValueModel<?>  valueModel= getValueModel(pElement, modelRef, pBuilder);
        String         labelName= pElement.getAttributeValue(SwingXMLBuilder.WIDGETREF_ATTRIBUTE);
        Object         label    = pBuilder.getComponentByAnyName(labelName);
        if (!(label instanceof JLabel))
        {
            throw SwingXMLBuilder.createException("no JLabel found for "+labelName, pElement);
        }

        return new LabelAdapter(valueModel, (JLabel)label);
    }

    /**
     * Creates an adapter between a ValueModel and some Lists/ValueModels and a
     * JComboBox or a JList.
     * @param pElement element describing the object
     * @param pBuilder our builder
     * @throws IllegalArgumentException if we have a problem (parameters, ...)
     * @return the list-of-values adapter
     */
    private Object createLOVAdapter(final Element pElement, final SwingXMLBuilder pBuilder) throws IllegalArgumentException
    {
        String         modelRef  = pElement.getAttributeValue(SwingXMLBuilder.MODELREF_ATTRIBUTE);
        ValueModel<?>  valueModel= getValueModel(pElement, modelRef, pBuilder);
        String         widgetName= pElement.getAttributeValue(SwingXMLBuilder.WIDGETREF_ATTRIBUTE);
        JComponent     widget    = pBuilder.getComponentByAnyName(widgetName);
        if (!((widget instanceof JComboBox) || (widget instanceof JList)))
        {
            if (widget==null)
            {
                throw SwingXMLBuilder.createException("no JComboBox/JList/ButtonGroup found for "+widgetName, pElement);
            }
            Object buttonGroup= widget.getClientProperty(SwingXMLBuilder.BUTTONGROUP_PROPERTY);
            if (!(buttonGroup instanceof ButtonGroup))
            {
                throw SwingXMLBuilder.createException("no JComboBox/JList/ButtonGroup found for "+widgetName, pElement);
            }
        }

        String itemsRef  = pElement.getAttributeValue(SwingXMLBuilder.ITEMSREF_ATTRIBUTE);
        String keysRef   = pElement.getAttributeValue(SwingXMLBuilder.KEYSREF_ATTRIBUTE);
        String items     = pElement.getAttributeValue(SwingXMLBuilder.ITEMS_ATTRIBUTE);
        String keys      = pElement.getAttributeValue(SwingXMLBuilder.KEYS_ATTRIBUTE);

        boolean             useVMs;
        List<?>             itemList= null;
        List<?>             keyList = null;
        ValueModel<List<?>> itemsVM = null;
        ValueModel<List<?>> keysVM  = null;
        if (itemsRef==null && keysRef==null && items!=null && keys!=null)
        {
            // use two lists as item/key provider
            Object itemL= pBuilder.getNonVisualObject(items);
            if (!(itemL instanceof List))
            {
                throw SwingXMLBuilder.createException("no item List found for "+items, pElement);
            }
            Object keyL= pBuilder.getNonVisualObject(keys);
            if (!(keyL instanceof List))
            {
                throw SwingXMLBuilder.createException("no key List found for "+keys, pElement);
            }
            useVMs  = false;
            itemList= (List<?>)itemL;
            keyList = (List<?>)keyL;
        }
        else if (itemsRef!=null && keysRef!=null && items==null && keys==null)
        {
            // use two value models as item/key provider
            useVMs = true;
            itemsVM= (ValueModel<List<?>>)getValueModel(pElement, itemsRef, pBuilder);
            keysVM = (ValueModel<List<?>>)getValueModel(pElement, keysRef, pBuilder);
        }
        else
        {
            throw SwingXMLBuilder.createException("either the itemsref/keysref or the " +
                                                  "items/keys attributes must be used", pElement);
        }

        Object unselected= pBuilder.getNonVisualObject(
                pElement.getAttributeValue(SwingXMLBuilder.UNSELECTED_ATTRIBUTE));

        if (widget instanceof JComboBox)
        {
            if (useVMs)
                return new LOVAdapter((JComboBox)widget, itemsVM, keysVM, valueModel, unselected);
            else
                return new LOVAdapter((JComboBox)widget, itemList, keyList, valueModel, unselected);
        }
        else if (widget instanceof JList)
        {
            if (useVMs)
                return new LOVAdapter((JList)widget, itemsVM, keysVM, valueModel, unselected);
            else
                return new LOVAdapter((JList)widget, itemList, keyList, valueModel, unselected);
        }
        else
        {
            ButtonGroup buttongroup = (ButtonGroup) widget.getClientProperty(SwingXMLBuilder.BUTTONGROUP_PROPERTY);
            if (useVMs)
                return new LOVAdapter(buttongroup, itemsVM, keysVM, valueModel, unselected);
            else
                return new LOVAdapter(buttongroup, itemList, keyList, valueModel, unselected);
        }
    }

    /**
     * Get a DelegateAccess object from pBuilder by name.
     * @param pElement element describing the object
     * @param pId id of the DelegateAccess
     * @param pBuilder our builder
     * @return a DelegateAccess, never null
     * @throws IllegalArgumentException if we have a problem (parameters, ...)
     */
    private DelegateAccess getDelegateAccess(final Element pElement, final String pId, final SwingXMLBuilder pBuilder)
    {
        if (pId==null)
            throw SwingXMLBuilder.createException("value model id of "+pElement.getName()+" must not be null", pElement);

        Object delegateAccess= pBuilder.getNonVisualObject(pId);
        if (!(delegateAccess instanceof DelegateAccess))
        {
            throw SwingXMLBuilder.createException("The accessref '"+pId+
                                                  "' is no 'DelegateAccess' type", pElement);
        }

        return (DelegateAccess)delegateAccess;
    }

    /**
     * Get a ValueModel object from pBuilder by name, for a SelectionInList ValueModel
     * the ValueModel of the selectionHolder, isIndexInList and listHolder attributes
     * are suppored.
     * @param pElement element describing the object
     * @param pId id of the value model
     * @param pBuilder our builder
     * @return a value model, never null
     * @throws IllegalArgumentException if we have a problem (parameters, ...)
     */
    private ValueModel<?> getValueModel(final Element pElement, final String pId, final SwingXMLBuilder pBuilder)
    {
        if (pId==null)
            throw SwingXMLBuilder.createException("value model id of "+pElement.getName()+" must not be null", pElement);

        if (pId.endsWith(SELECTION_HOLDER))
        {
            String baseVM= pId.substring(0, pId.lastIndexOf(SELECTION_HOLDER));
            ValueModel<?> vm= getValueModel(pElement, baseVM, pBuilder);
            if (!(vm instanceof SelectionInList))
            {
                throw SwingXMLBuilder.createException(baseVM+ "is no SelectionInList", pElement);
            }
            return ((SelectionInList<?>)vm).selectionHolder();
        }

        if (pId.endsWith(IS_INDEX_IN_LIST_HOLDER))
        {
            String baseVM= pId.substring(0, pId.lastIndexOf(IS_INDEX_IN_LIST_HOLDER));
            ValueModel<?> vm= getValueModel(pElement, baseVM, pBuilder);
            if (!(vm instanceof SelectionInList))
            {
                throw SwingXMLBuilder.createException(baseVM+ "is no SelectionInList", pElement);
            }
            return ((SelectionInList<?>)vm).isIndexInList();
        }

        if (pId.endsWith(LIST_HOLDER))
        {
            String baseVM= pId.substring(0, pId.lastIndexOf(LIST_HOLDER));
            ValueModel<?> vm= getValueModel(pElement, baseVM, pBuilder);
            if (!(vm instanceof SelectionInList))
            {
                throw SwingXMLBuilder.createException(baseVM+ "is no SelectionInList", pElement);
            }
            return ((SelectionInList<?>)vm).listHolder();
        }

        Object valueModel= pBuilder.getNonVisualObject(pId);
        if (!(valueModel instanceof ValueModel))
        {
            throw SwingXMLBuilder.createException("no ValueModel found for "+pId, pElement);
        }

        return (ValueModel<?>)valueModel;
    }

}
