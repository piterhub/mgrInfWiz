package net.sf.cuf.ui.builder;

import net.sf.cuf.model.ExternalUpdate;

import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

/**
 * Small adapter that maps a change event to calling external update on a value model.
 */
public class ExternalUpdateAdapter implements ChangeListener
{
    /** our VM to call back, never null */
    private ExternalUpdate mExternalUpdate;

    /**
     * Create a new adapter
     * @param pExternalUpdateVM the VM, must not be null
     */
    public ExternalUpdateAdapter(final ExternalUpdate pExternalUpdateVM)
    {
        if (pExternalUpdateVM==null)
            throw new IllegalArgumentException("external update must not be null");
        mExternalUpdate= pExternalUpdateVM;
    }

    @Override
    public void stateChanged(ChangeEvent e)
    {
        mExternalUpdate.signalExternalUpdate();
    }
}
