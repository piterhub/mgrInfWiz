package net.sf.cuf.model;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import junit.framework.TestCase;

/**
 * tests a few aspects of the {@link SelectionInList}
 */
public class SelectionInListTest extends TestCase
{

    /**
     * Tests the behaviour on {@link SelectionInList#setValue(Object)}
     */
    public void testSetValue() 
    {
        ValueHolder<List<Object>> vh = new ValueHolder<List<Object>>();
        SelectionInList<Object> sil = new SelectionInList( vh);
        List<Object> list = new ArrayList<Object>();
        assertNull( "value must be null", sil.getValue());
        assertNull( "base value must be null", vh.getValue());
        sil.setValue( list);
        assertSame( "value must be out list", list, sil.getValue());
        assertSame( "base value must be our list", list, vh.getValue());
    }
    
    /**
     * tests manipulation of the {@link SelectionInList#selectionHolder()}
     */
    public void testSetIndex() 
    {
        ValueHolder<List<Object>> vh = new ValueHolder();
        SelectionInList<Object> sil = new SelectionInList( vh);
        ValueModel<Integer> sh = sil.selectionHolder();
        CallbackTarget silChange = new CallbackTarget();
        sil.addChangeListener( silChange);
        CallbackTarget selectionChange = new CallbackTarget();
        sh.addChangeListener( selectionChange);
        // test with null value
        assertEquals( "no selection", -1, sh.intValue());
        try
        {
            sh.setValue( 0);
            fail( "illegal index must produce IllegalArgumentException");
        } 
        catch (IllegalArgumentException e)
        {
            // expected
        }
        // test with empty list
        List<Object> list = new ArrayList<Object>();
        vh.setValue( list);
        assertEquals( "no selection", -1, sh.intValue());
        try
        {
            sh.setValue( 0);
            fail( "illegal index must produce IllegalArgumentException");
        } 
        catch (IllegalArgumentException e)
        {
            // expected
        }
        // test with list with entry
        list.add( "Test");
        vh.signalExternalUpdate();
        assertEquals( "no selection", -1, sh.intValue());
        sh.setValue( 0);
        assertEquals( "selection correct", 0, sh.intValue());
        try
        {
            sh.setValue( 1);
            fail( "illegal index must produce IllegalArgumentException");
        } 
        catch (IllegalArgumentException e)
        {
            // expected
        }
        // reset to null
        vh.setValue(null);
        assertEquals( "no selection", -1, sh.intValue());
    }
    
    /**
     * tests if the events concerning change are fired correctly
     * in default mode (we don't try to keep the selection when updating a list)
     */
    public void testSetValueEventsDefault()
    {
        ValueHolder<List<String>> vh = new ValueHolder();
        SelectionInList<String> sil = new SelectionInList( vh);
        ValueModel<Integer> sh = sil.selectionHolder();
        CallbackTarget silChange = new CallbackTarget();
        sil.addChangeListener( silChange);
        CallbackTarget selectionChange = new CallbackTarget();
        sh.addChangeListener( selectionChange);
        
        vh.setValue( new ArrayList<String>());
        assertEquals( "no selection", -1, sh.intValue());
        assertTrue( "notification for value change must have happened", silChange.isStateChangedCalled());
        assertFalse( "no selection change must have happened", selectionChange.isStateChangedCalled());
        silChange.reset();
        selectionChange.reset();
        
        vh.setValue( new ArrayList<String>());
        assertEquals( "no selection", -1, sh.intValue());
        assertFalse( "no notification for value change must have happened", silChange.isStateChangedCalled());
        assertFalse( "no selection change must have happened", selectionChange.isStateChangedCalled());
        silChange.reset();
        selectionChange.reset();
        
        vh.setValue( new ArrayList<String>(), true);
        assertEquals( "no selection", -1, sh.intValue());
        assertTrue( "notification for value change must have happened", silChange.isStateChangedCalled());
        assertFalse( "no selection change must have happened", selectionChange.isStateChangedCalled());
        silChange.reset();
        selectionChange.reset();
        
        vh.setValue( Arrays.asList("Value1", "Value2"));
        assertEquals( "no selection", -1, sh.intValue());
        assertTrue( "notification for value change must have happened", silChange.isStateChangedCalled());
        assertFalse( "no selection change must have happened", selectionChange.isStateChangedCalled());
        silChange.reset();
        selectionChange.reset();
        
        vh.setValue( Arrays.asList("Value1", "Value2"));
        assertEquals( "no selection", -1, sh.intValue());
        assertFalse( "no notification for value change must have happened", silChange.isStateChangedCalled());
        assertFalse( "no selection change must have happened", selectionChange.isStateChangedCalled());
        silChange.reset();
        selectionChange.reset();
        
        sil.setValue( Arrays.asList("Value1", "Value2"));
        // This is not intuitive, but means backwards compatibility:
        // a set value on the SIL fires a change even when there is not a change
        // (and the same change on the backing value holder will not produce a notification)
        assertEquals( "no selection", -1, sh.intValue());
        assertTrue( "notification for value change must have happened", silChange.isStateChangedCalled());
        assertFalse( "no selection change must have happened", selectionChange.isStateChangedCalled());
        silChange.reset();
        selectionChange.reset();
        
        // select entry
        sh.setValue( 1);
        assertEquals( "selection correct", 1, sh.intValue());
        assertFalse( "no notification for value change must have happened", silChange.isStateChangedCalled());
        assertTrue( "selection change must have happened", selectionChange.isStateChangedCalled());
        silChange.reset();
        selectionChange.reset();
        
        // select entry
        sh.setValue( 1);
        assertEquals( "selection correct", 1, sh.intValue());
        assertFalse( "no notification for value change must have happened", silChange.isStateChangedCalled());
        assertFalse( "no selection change must have happened", selectionChange.isStateChangedCalled());
        silChange.reset();
        selectionChange.reset();
        
        vh.setValue( Arrays.asList("Value1", "Value2"));
        // this is stopped in the ValueHolder (no change)
        assertEquals( "selection correct", 1, sh.intValue());
        assertFalse( "no notification for value change must have happened", silChange.isStateChangedCalled());
        assertFalse( "no selection change must have happened", selectionChange.isStateChangedCalled());
        silChange.reset();
        selectionChange.reset();

        vh.setValue( Arrays.asList("Value1", "Value2"), true);
        assertEquals( "no selection", -1, sh.intValue());
        assertTrue( "notification for value change must have happened", silChange.isStateChangedCalled());
        assertTrue( "selection change must have happened", selectionChange.isStateChangedCalled());
        silChange.reset();
        selectionChange.reset();

        // select entry
        sh.setValue( 1);
        assertEquals( "selection correct", 1, sh.intValue());
        assertFalse( "no notification for value change must have happened", silChange.isStateChangedCalled());
        assertTrue( "selection change must have happened", selectionChange.isStateChangedCalled());
        silChange.reset();
        selectionChange.reset();
        
        sil.setValue( Arrays.asList("Value1", "Value2"));
        assertEquals( "no selection", -1, sh.intValue());
        assertTrue( "notification for value change must have happened", silChange.isStateChangedCalled());
        assertTrue( "selection change must have happened", selectionChange.isStateChangedCalled());
        silChange.reset();
        selectionChange.reset();
        
        // select entry
        sh.setValue( 1);
        assertEquals( "selection correct", 1, sh.intValue());
        assertFalse( "no notification for value change must have happened", silChange.isStateChangedCalled());
        assertTrue( "selection change must have happened", selectionChange.isStateChangedCalled());
        silChange.reset();
        selectionChange.reset();
        
        vh.setValue( new ArrayList());
        assertEquals( "no selection", -1, sh.intValue());
        assertTrue( "notification for value change must have happened", silChange.isStateChangedCalled());
        assertTrue( "selection change must have happened", selectionChange.isStateChangedCalled());
        silChange.reset();
        selectionChange.reset();
    }
    
    /**
     * tests if the events concerning change are fired correctly
     * when we have configured the SIL to keep the selection if possible.
     */
    public void testSetValueEventsKeepSelection()
    {
        ValueHolder<List<String>> vh = new ValueHolder();
        SelectionInList<String> sil = new SelectionInList( vh);
        sil.setKeepSelection(true);
        ValueModel<Integer> sh = sil.selectionHolder();
        CallbackTarget silChange = new CallbackTarget();
        sil.addChangeListener( silChange);
        CallbackTarget selectionChange = new CallbackTarget();
        sh.addChangeListener( selectionChange);
        
        vh.setValue( new ArrayList());
        assertEquals( "no selection", -1, sh.intValue());
        assertTrue( "notification for value change must have happened", silChange.isStateChangedCalled());
        assertFalse( "no selection change must have happened", selectionChange.isStateChangedCalled());
        silChange.reset();
        selectionChange.reset();
        
        vh.setValue( new ArrayList<String>());
        assertEquals( "no selection", -1, sh.intValue());
        assertFalse( "no notification for value change must have happened", silChange.isStateChangedCalled());
        assertFalse( "no selection change must have happened", selectionChange.isStateChangedCalled());
        silChange.reset();
        selectionChange.reset();
        
        vh.setValue( new ArrayList<String>(), true);
        assertEquals( "no selection", -1, sh.intValue());
        assertTrue( "notification for value change must have happened", silChange.isStateChangedCalled());
        assertFalse( "no selection change must have happened", selectionChange.isStateChangedCalled());
        silChange.reset();
        selectionChange.reset();
        
        vh.setValue( Arrays.asList("Value1", "Value2"));
        assertEquals( "no selection", -1, sh.intValue());
        assertTrue( "notification for value change must have happened", silChange.isStateChangedCalled());
        assertFalse( "no selection change must have happened", selectionChange.isStateChangedCalled());
        silChange.reset();
        selectionChange.reset();
        
        vh.setValue( Arrays.asList("Value1", "Value2"));
        assertEquals( "no selection", -1, sh.intValue());
        assertFalse( "no notification for value change must have happened", silChange.isStateChangedCalled());
        assertFalse( "no selection change must have happened", selectionChange.isStateChangedCalled());
        silChange.reset();
        selectionChange.reset();
        
        sil.setValue( Arrays.asList("Value1", "Value2"));
        // This is not intuitive, but means backwards compatibility:
        // a set value on the SIL fires a change even when there is not a change
        // (and the same change on the backing value holder will not produce a notification)
        assertEquals( "no selection", -1, sh.intValue());
        assertTrue( "notification for value change must have happened", silChange.isStateChangedCalled());
        assertFalse( "no selection change must have happened", selectionChange.isStateChangedCalled());
        silChange.reset();
        selectionChange.reset();
        
        // select entry
        sh.setValue( 1);
        assertEquals( "selection correct", 1, sh.intValue());
        assertFalse( "no notification for value change must have happened", silChange.isStateChangedCalled());
        assertTrue( "selection change must have happened", selectionChange.isStateChangedCalled());
        silChange.reset();
        selectionChange.reset();
        
        // select entry
        sh.setValue( 1);
        assertEquals( "selection correct", 1, sh.intValue());
        assertFalse( "no notification for value change must have happened", silChange.isStateChangedCalled());
        assertFalse( "no selection change must have happened", selectionChange.isStateChangedCalled());
        silChange.reset();
        selectionChange.reset();
        
        vh.setValue( Arrays.asList("Value1", "Value2"));
        // this is stopped in the ValueHolder (no change)
        assertEquals( "selection correct", 1, sh.intValue());
        assertFalse( "no notification for value change must have happened", silChange.isStateChangedCalled());
        assertFalse( "no selection change must have happened", selectionChange.isStateChangedCalled());
        silChange.reset();
        selectionChange.reset();

        vh.setValue( Arrays.asList("Value1", "Value2"), true);
        assertEquals( "selection correct", 1, sh.intValue());
        assertTrue( "notification for value change must have happened", silChange.isStateChangedCalled());
        assertTrue( "selection change must have happened", selectionChange.isStateChangedCalled());
        silChange.reset();
        selectionChange.reset();

        vh.setValue( Arrays.asList("Value2", "Value1"), true);
        assertEquals( "selection correct", 0, sh.intValue());
        assertTrue( "notification for value change must have happened", silChange.isStateChangedCalled());
        assertTrue( "selection change must have happened", selectionChange.isStateChangedCalled());
        silChange.reset();
        selectionChange.reset();

        sil.setValue( Arrays.asList("Value1", "Value2"));
        assertEquals( "selection correct", 1, sh.intValue());
        assertTrue( "notification for value change must have happened", silChange.isStateChangedCalled());
        assertTrue( "selection change must have happened", selectionChange.isStateChangedCalled());
        silChange.reset();
        selectionChange.reset();
        
        vh.setValue( new ArrayList());
        assertEquals( "no selection", -1, sh.intValue());
        assertTrue( "notification for value change must have happened", silChange.isStateChangedCalled());
        assertTrue( "selection change must have happened", selectionChange.isStateChangedCalled());
        silChange.reset();
        selectionChange.reset();
    }
    
}
