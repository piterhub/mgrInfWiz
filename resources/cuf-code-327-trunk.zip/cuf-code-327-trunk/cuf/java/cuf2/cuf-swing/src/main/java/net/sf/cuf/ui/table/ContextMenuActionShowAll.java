package net.sf.cuf.ui.table;


/**
 * Context menu action to show all hidden columns of a {@link SortingTable}.
 *
 * @author  Hendrik W&ouml;rdehoff, sd&amp;m AG
 */
public class ContextMenuActionShowAll
extends ContextMenuAction
{
    public String getKennung()
    {
        return mAdapter.getContextMenuKennung()+"_SHOWALL";
    }

    /**
     * The table returned by {@link ContextMenuAdapter#getTable} must be a {@link SortingTable}.
     */
    public boolean isEnabled()
    {
        return !((SortingTable) mAdapter.getTable()).isAllColumnsVisible();
    }

    /**
     * The table returned by {@link ContextMenuAdapter#getTable} must be a {@link SortingTable}.
     */
    public void performAction()
    {
        ((SortingTable) mAdapter.getTable()).setAllColumnsVisible();
    }
}
