package net.sf.cuf.model.state;

import junit.framework.TestCase;

import net.sf.cuf.model.ValueHolder;

/**
 * tests {@link ValueState}
 */
public class ValueStateTest extends TestCase
{
    
    public void testCreation()
    {
        ValueHolder vm = new ValueHolder();
        ValueState valueState = new ValueState( vm);
        assertFalse( "null value must result in not initialized", valueState.isInitialized());
        assertFalse( "null value must result in not enabled", valueState.isEnabled());
    }
    
    public void testTrue()
    {
        ValueHolder vm = new ValueHolder();
        ValueState valueState = new ValueState( vm);
        vm.setValue( true);
        assertTrue( "true value must result in initialized", valueState.isInitialized());
        assertTrue( "true value must result in enabled", valueState.isEnabled());
        vm.setValue( "true");
        assertTrue( "\"true\" value must result in initialized", valueState.isInitialized());
        assertTrue( "\"true\" value must result in enabled", valueState.isEnabled());
    }
    
    public void testFalse()
    {
        ValueHolder vm = new ValueHolder();
        ValueState valueState = new ValueState( vm);
        vm.setValue( false);
        assertTrue( "false value must result in initialized", valueState.isInitialized());
        assertFalse( "false value must result in enabled", valueState.isEnabled());
        vm.setValue( "false");
        assertTrue( "\"false\" value must result in initialized", valueState.isInitialized());
        assertFalse( "\"false\" value must result in enabled", valueState.isEnabled());
    }
    
    public void testNull()
    {
        ValueHolder vm = new ValueHolder();
        ValueState valueState = new ValueState( vm);
        valueState.setMeaningOfNull( null);
        assertFalse( "null value must result in not initialized", valueState.isInitialized());
        assertFalse( "null value must result in not enabled", valueState.isEnabled());
        valueState.setMeaningOfNull( Boolean.FALSE);
        assertTrue( "null value must result in initialized", valueState.isInitialized());
        assertFalse( "null value must result in not enabled", valueState.isEnabled());
        valueState.setMeaningOfNull( Boolean.TRUE);
        assertTrue( "null value must result in initialized", valueState.isInitialized());
        assertTrue( "null value must result in enabled", valueState.isEnabled());
    }
    
}
