package net.sf.cuf.model.converter;

import junit.framework.TestCase;

import net.sf.cuf.model.ValueHolder;

/**
 * Tests the {@link LongStringConverter}
 */
public class LongStringConverterTest extends TestCase
{

    /**
     * Tests the conversion for the default settings which are
     * <UL>
     * <LI>null valid without substitute
     * <LI>propagate exceptions
     * </UL>
     */
    public void testConversionWithNullAndEx()
    {
        ValueHolder valueHolder = new ValueHolder();
        LongStringConverter converter = new LongStringConverter( valueHolder);
        // get
        valueHolder.setValue( new Long( 17));
        assertEquals( "value must be correct", "17", converter.getValue());
        assertTrue( "converter must be in sync", converter.getSyncState().booleanValue());
        valueHolder.setValue( Long.MAX_VALUE);
        assertEquals( "value must be correct", "9223372036854775807", converter.getValue());
        assertTrue( "converter must be in sync", converter.getSyncState().booleanValue());
        valueHolder.setValue( null);
        assertEquals( "value must be correct", null, converter.getValue());
        // the following is not intuitive, 
        // but it is the current behaviour, 
        // so we keep it for backwards compatibility
        // (I would expect a true here, since null is valid)
        assertFalse( "converter must be out of sync", converter.getSyncState().booleanValue());
        try 
        {
            valueHolder.setValue( "invalid");
            fail( "converter must throw exception for invalid value");
        } 
        catch (ClassCastException ex)
        {
            // correct
        }
        try 
        {
            converter.getValue();
            fail( "converter must throw exception for invalid value");
        } 
        catch (ClassCastException ex)
        {
            // correct
        }
        assertFalse( "converter must be out of sync", converter.getSyncState().booleanValue());
        // set
        converter.setValue( "42");
        assertEquals( "value must be correct", (long) 42, valueHolder.getValue());
        assertTrue( "converter must be in sync", converter.getSyncState().booleanValue());
        converter.setValue( "9223372036854775807");
        assertEquals( "value must be correct", Long.MAX_VALUE, valueHolder.getValue());
        assertTrue( "converter must be in sync", converter.getSyncState().booleanValue());
        // the following is not intuitive, 
        // but it is the current behaviour, 
        // so we keep it for backwards compatibility
        // (I would expect an exception here)
        converter.setValue( "invalid");
        assertEquals( "value must be substitute", null, valueHolder.getValue());
        assertFalse( "converter must be out of sync", converter.getSyncState().booleanValue());
        // the following is not intuitive, 
        // but it is the current behaviour, 
        // so we keep it for backwards compatibility
        // (I would expect an exception here)
        converter.setValue( "9223372036854775808");
        assertEquals( "value must be substitute", null, valueHolder.getValue());
        assertFalse( "converter must be out of sync", converter.getSyncState().booleanValue());
        // the following is not intuitive, 
        // but it is the current behaviour, 
        // so we keep it for backwards compatibility
        // (I would expect an exception here)
        converter.setValue( "");
        assertEquals( "value must be substitute", null, valueHolder.getValue());
        assertFalse( "converter must be out of sync", converter.getSyncState().booleanValue());
        // the following is not intuitive, 
        // but it is the current behaviour, 
        // so we keep it for backwards compatibility
        // (I would expect an exception here)
        converter.setValue( null);
        assertEquals( "value must be substitute", null, valueHolder.getValue());
        assertFalse( "converter must be out of sync", converter.getSyncState().booleanValue());
    }
    
    /**
     * Tests the conversion for 
     * <UL>
     * <LI>null valid with substitute
     * <LI>propagate exceptions
     * </UL>
     */
    public void testConversionWithNullSubstAndEx()
    {
        ValueHolder valueHolder = new ValueHolder();
        LongStringConverter converter = new LongStringConverter( valueHolder);
        converter.setNullSubstitute((long) -12345);
        // get
        valueHolder.setValue( new Long( 17));
        assertEquals( "value must be correct", "17", converter.getValue());
        assertTrue( "converter must be in sync", converter.getSyncState().booleanValue());
        valueHolder.setValue( Long.MAX_VALUE);
        assertEquals( "value must be correct", "9223372036854775807", converter.getValue());
        assertTrue( "converter must be in sync", converter.getSyncState().booleanValue());
        valueHolder.setValue( null);
        assertEquals( "value must be correct", null, converter.getValue());
        // the following is not intuitive, 
        // but it is the current behaviour, 
        // so we keep it for backwards compatibility
        // (I would expect a true here, since null is valid)
        assertFalse( "converter must be out of sync", converter.getSyncState().booleanValue());
        try 
        {
            valueHolder.setValue( "invalid");
            fail( "converter must throw exception for invalid value");
        } 
        catch (ClassCastException ex)
        {
            // correct
        }
        try 
        {
            converter.getValue();
            fail( "converter must throw exception for invalid value");
        } 
        catch (ClassCastException ex)
        {
            // correct
        }
        assertFalse( "converter must be out of sync", converter.getSyncState().booleanValue());
        // set
        converter.setValue( "42");
        assertEquals( "value must be correct", (long) 42, valueHolder.getValue());
        assertTrue( "converter must be in sync", converter.getSyncState().booleanValue());
        converter.setValue( "9223372036854775807");
        assertEquals( "value must be correct", Long.MAX_VALUE, valueHolder.getValue());
        assertTrue( "converter must be in sync", converter.getSyncState().booleanValue());
        // the following is not intuitive, 
        // but it is the current behaviour, 
        // so we keep it for backwards compatibility
        // (I would expect an exception here)
        converter.setValue( "invalid");
        assertEquals( "value must be substitute", (long) -12345, valueHolder.getValue());
        assertFalse( "converter must be out of sync", converter.getSyncState().booleanValue());
        // the following is not intuitive, 
        // but it is the current behaviour, 
        // so we keep it for backwards compatibility
        // (I would expect an exception here)
        converter.setValue( "9223372036854775808");
        assertEquals( "value must be substitute", (long) -12345, valueHolder.getValue());
        assertFalse( "converter must be out of sync", converter.getSyncState().booleanValue());
        // the following is not intuitive, 
        // but it is the current behaviour, 
        // so we keep it for backwards compatibility
        // (I would expect an exception here)
        converter.setValue( "");
        assertEquals( "value must be substitute", (long) -12345, valueHolder.getValue());
        assertFalse( "converter must be out of sync", converter.getSyncState().booleanValue());
        // the following is not intuitive, 
        // but it is the current behaviour, 
        // so we keep it for backwards compatibility
        // (I would expect an exception here)
        converter.setValue( null);
        assertEquals( "value must be substitute", (long) -12345, valueHolder.getValue());
        assertFalse( "converter must be out of sync", converter.getSyncState().booleanValue());
    }
    
    /**
     * Tests the conversion for 
     * <UL>
     * <LI>null invalid
     * <LI>propagate exceptions
     * </UL>
     */
    public void testConversionWithNotNullAndEx()
    {
        ValueHolder valueHolder = new ValueHolder();
        LongStringConverter converter = new LongStringConverter( valueHolder, false);
        // get
        valueHolder.setValue( new Long( 17));
        assertEquals( "value must be correct", "17", converter.getValue());
        assertTrue( "converter must be in sync", converter.getSyncState().booleanValue());
        valueHolder.setValue( Long.MAX_VALUE);
        assertEquals( "value must be correct", "9223372036854775807", converter.getValue());
        assertTrue( "converter must be in sync", converter.getSyncState().booleanValue());
        valueHolder.setValue( null);
        try 
        {
            converter.getValue();
            fail( "converter must throw exception for invalid value");
        } 
        catch (IllegalStateException ex)
        {
            // correct
        }
        assertFalse( "converter must be out of sync", converter.getSyncState().booleanValue());
        try 
        {
            valueHolder.setValue( "invalid");
            fail( "converter must throw exception for invalid value");
        } 
        catch (ClassCastException ex)
        {
            // correct
        }
        try 
        {
            converter.getValue();
            fail( "converter must throw exception for invalid value");
        } 
        catch (Exception ex)
        {
            // correct
        }
        assertFalse( "converter must be out of sync", converter.getSyncState().booleanValue());
        // set
        converter.setValue( "42");
        assertEquals( "value must be correct", (long) 42, valueHolder.getValue());
        assertTrue( "converter must be in sync", converter.getSyncState().booleanValue());
        converter.setValue( "9223372036854775807");
        assertEquals( "value must be correct", Long.MAX_VALUE, valueHolder.getValue());
        assertTrue( "converter must be in sync", converter.getSyncState().booleanValue());
        try 
        {
            converter.setValue( "invalid");
            fail( "converter must throw exception for invalid value");
        }
        catch (IllegalStateException ex)
        {
            // correct
        }
        assertEquals( "value must be unchanged", Long.MAX_VALUE, valueHolder.getValue());
        assertFalse( "converter must be out of sync", converter.getSyncState().booleanValue());
        try 
        {
            converter.setValue( "9223372036854775808");
            fail( "converter must throw exception for invalid value");
        }
        catch (IllegalStateException ex)
        {
            // correct
        }
        assertEquals( "value must be unchanged", Long.MAX_VALUE, valueHolder.getValue());
        assertFalse( "converter must be out of sync", converter.getSyncState().booleanValue());
        try 
        {
            converter.setValue( "");
            fail( "converter must throw exception for invalid value");
        }
        catch (IllegalStateException ex)
        {
            // correct
        }
        assertEquals( "value must be unchanged", Long.MAX_VALUE, valueHolder.getValue());
        assertFalse( "converter must be out of sync", converter.getSyncState().booleanValue());
        try 
        {
            converter.setValue( null);
            fail( "converter must throw exception for invalid value");
        }
        catch (IllegalStateException ex)
        {
            // correct
        }
        assertEquals( "value must be unchanged", Long.MAX_VALUE, valueHolder.getValue());
        assertFalse( "converter must be out of sync", converter.getSyncState().booleanValue());
    }
    
    /**
     * Tests the conversion for
     * <UL>
     * <LI>null valid without substitute
     * <LI>ignore exceptions
     * </UL>
     */
    public void testConversionWithNullAndNoEx()
    {
        ValueHolder valueHolder = new ValueHolder();
        LongStringConverter converter = new LongStringConverter( valueHolder);
        converter.setPropagateFailedConversions( false);
        // get
        valueHolder.setValue( new Long( 17));
        assertEquals( "value must be correct", "17", converter.getValue());
        assertTrue( "converter must be in sync", converter.getSyncState().booleanValue());
        valueHolder.setValue( Long.MAX_VALUE);
        assertEquals( "value must be correct", "9223372036854775807", converter.getValue());
        assertTrue( "converter must be in sync", converter.getSyncState().booleanValue());
        valueHolder.setValue( null);
        assertEquals( "value must be correct", null, converter.getValue());
        // the following is not intuitive, 
        // but it is the current behaviour, 
        // so we keep it for backwards compatibility
        // (I would expect a true here, since null is valid)
        assertFalse( "converter must be out of sync", converter.getSyncState().booleanValue());
        try 
        {
            valueHolder.setValue( "invalid");
            fail( "converter must throw exception for invalid value");
        } 
        catch (ClassCastException ex)
        {
            // correct
        }
        try 
        {
            converter.getValue();
            fail( "converter must throw exception for invalid value");
        } 
        catch (ClassCastException ex)
        {
            // correct
        }
        assertFalse( "converter must be out of sync", converter.getSyncState().booleanValue());
        // set
        converter.setValue( "42");
        assertEquals( "value must be correct", (long) 42, valueHolder.getValue());
        assertTrue( "converter must be in sync", converter.getSyncState().booleanValue());
        converter.setValue( "9223372036854775807");
        assertEquals( "value must be correct", Long.MAX_VALUE, valueHolder.getValue());
        assertTrue( "converter must be in sync", converter.getSyncState().booleanValue());
        converter.setValue( "invalid");
        assertEquals( "value must be substitute", null, valueHolder.getValue());
        assertFalse( "converter must be out of sync", converter.getSyncState().booleanValue());
        converter.setValue( "9223372036854775808");
        assertEquals( "value must be substitute", null, valueHolder.getValue());
        assertFalse( "converter must be out of sync", converter.getSyncState().booleanValue());
        converter.setValue( "");
        assertEquals( "value must be substitute", null, valueHolder.getValue());
        assertFalse( "converter must be out of sync", converter.getSyncState().booleanValue());
        converter.setValue( null);
        assertEquals( "value must be substitute", null, valueHolder.getValue());
        assertFalse( "converter must be out of sync", converter.getSyncState().booleanValue());
    }
    
    /**
     * Tests the conversion for
     * <UL>
     * <LI>null valid with substitute
     * <LI>ignore exceptions
     * </UL>
     */
    public void testConversionWithNullSubstAndNoEx()
    {
        ValueHolder valueHolder = new ValueHolder();
        LongStringConverter converter = new LongStringConverter( valueHolder);
        converter.setNullSubstitute((long) -12345);
        converter.setPropagateFailedConversions( false);
        // get
        valueHolder.setValue( new Long( 17));
        assertEquals( "value must be correct", "17", converter.getValue());
        assertTrue( "converter must be in sync", converter.getSyncState().booleanValue());
        valueHolder.setValue( Long.MAX_VALUE);
        assertEquals( "value must be correct", "9223372036854775807", converter.getValue());
        assertTrue( "converter must be in sync", converter.getSyncState().booleanValue());
        valueHolder.setValue( null);
        assertEquals( "value must be correct", null, converter.getValue());
        // the following is not intuitive, 
        // but it is the current behaviour, 
        // so we keep it for backwards compatibility
        // (I would expect a true here, since null is valid)
        assertFalse( "converter must be out of sync", converter.getSyncState().booleanValue());
        try 
        {
            valueHolder.setValue( "invalid");
            fail( "converter must throw exception for invalid value");
        } 
        catch (ClassCastException ex)
        {
            // correct
        }
        try 
        {
            converter.getValue();
            fail( "converter must throw exception for invalid value");
        } 
        catch (ClassCastException ex)
        {
            // correct
        }
        assertFalse( "converter must be out of sync", converter.getSyncState().booleanValue());
        // set
        converter.setValue( "42");
        assertEquals( "value must be correct", (long) 42, valueHolder.getValue());
        assertTrue( "converter must be in sync", converter.getSyncState().booleanValue());
        converter.setValue( "9223372036854775807");
        assertEquals( "value must be correct", Long.MAX_VALUE, valueHolder.getValue());
        assertTrue( "converter must be in sync", converter.getSyncState().booleanValue());
        converter.setValue( "invalid");
        assertEquals( "value must be substitute", (long) -12345, valueHolder.getValue());
        assertFalse( "converter must be out of sync", converter.getSyncState().booleanValue());
        converter.setValue( "9223372036854775808");
        assertEquals( "value must be substitute", (long) -12345, valueHolder.getValue());
        assertFalse( "converter must be out of sync", converter.getSyncState().booleanValue());
        converter.setValue( "");
        assertEquals( "value must be substitute", (long) -12345, valueHolder.getValue());
        assertFalse( "converter must be out of sync", converter.getSyncState().booleanValue());
        converter.setValue( null);
        assertEquals( "value must be substitute", (long) -12345, valueHolder.getValue());
        assertFalse( "converter must be out of sync", converter.getSyncState().booleanValue());
    }
    
    /**
     * Tests the conversion for 
     * <UL>
     * <LI>null invalid
     * <LI>ignore exceptions
     * </UL>
     */
    public void testConversionWithNotNullAndNoEx()
    {
        ValueHolder valueHolder = new ValueHolder();
        LongStringConverter converter = new LongStringConverter( valueHolder, false);
        converter.setPropagateFailedConversions( false);
        // get
        valueHolder.setValue( new Long( 17));
        assertEquals( "value must be correct", "17", converter.getValue());
        assertTrue( "converter must be in sync", converter.getSyncState().booleanValue());
        valueHolder.setValue( Long.MAX_VALUE);
        assertEquals( "value must be correct", "9223372036854775807", converter.getValue());
        assertTrue( "converter must be in sync", converter.getSyncState().booleanValue());
        valueHolder.setValue( null);
        assertNull( "value must be null for invalid value", converter.getValue());
        assertFalse( "converter must be out of sync", converter.getSyncState().booleanValue());
        try 
        {
            valueHolder.setValue( "invalid");
            fail( "converter must throw exception for invalid value");
        } 
        catch (ClassCastException ex)
        {
            // correct
        }
        try 
        {
            converter.getValue();
            fail( "converter must throw exception for invalid value");
        } 
        catch (Exception ex)
        {
            // correct
        }
        assertFalse( "converter must be out of sync", converter.getSyncState().booleanValue());
        // set
        converter.setValue( "42");
        assertEquals( "value must be correct", (long) 42, valueHolder.getValue());
        assertTrue( "converter must be in sync", converter.getSyncState().booleanValue());
        converter.setValue( "9223372036854775807");
        assertEquals( "value must be correct", Long.MAX_VALUE, valueHolder.getValue());
        assertTrue( "converter must be in sync", converter.getSyncState().booleanValue());
        converter.setValue( "invalid");
        assertEquals( "value must be unchanged", Long.MAX_VALUE, valueHolder.getValue());
        assertFalse( "converter must be out of sync", converter.getSyncState().booleanValue());
        converter.setValue( "9223372036854775808");
        assertEquals( "value must be unchanged", Long.MAX_VALUE, valueHolder.getValue());
        assertFalse( "converter must be out of sync", converter.getSyncState().booleanValue());
        converter.setValue( "");
        assertEquals( "value must be unchanged", Long.MAX_VALUE, valueHolder.getValue());
        assertFalse( "converter must be out of sync", converter.getSyncState().booleanValue());
        converter.setValue( null);
        assertEquals( "value must be unchanged", Long.MAX_VALUE, valueHolder.getValue());
        assertFalse( "converter must be out of sync", converter.getSyncState().booleanValue());
    }
    
}
