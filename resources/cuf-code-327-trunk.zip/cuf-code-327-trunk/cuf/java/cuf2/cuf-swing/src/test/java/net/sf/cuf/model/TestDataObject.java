package net.sf.cuf.model;

/**
 * Object containing data used for test purposes.
 */
public class TestDataObject
{
    /**
     * The RuntimeException thrown in {@link #getWithRuntimeException()} and {@link #setWithRuntimeException(Object)}.
     */
    public static final RuntimeException RUNTIME_EXCEPTION = new RuntimeException("Exception while accessing value");

    /**
     * The Exception thrown in {@link #getWithException()} and {@link #setWithException(Object)}.
     */
    public static final Exception EXCEPTION = new Exception("Exception while accessing value");

    /**
     * a string value.
     */
    private String mString;
    
    /**
     * a int value
     */
    private int mInt;

    /**
     * @return the string value
     */
    public String getString()
    {
        return mString;
    }

    /**
     * @param string new string value
     */
    public void setString(final String string)
    {
        mString = string;
    }

    /**
     * @return the read only value of {@link #mString} (since there is no corresponding getter)
     */
    public String getROString()
    {
        return mString;
    }
    
    /**
     * sets the value of {@link #mString} as a write only setter
     * (since there is no corresponding getter)
     * @param string the new string value
     */
    public void setWOString( final String string)
    {
        mString = string;
    }

    /**
     * Always throws a RuntimeException when called.
     * @param obj ignored
     * @throws RuntimeException always
     */
    public void setWithRuntimeException(final Object obj)
    {
        throw RUNTIME_EXCEPTION;
    }

    /**
     * Always throws a RuntimeException when called.
     * @return will not return
     * @throws RuntimeException always
     */
    public Object getWithRuntimeException()
    {
        throw RUNTIME_EXCEPTION;
    }

    /**
     * Always throws a Exception when called.
     * @param obj ignored
     * @throws Exception always
     */
    public void setWithException(final Object obj) throws Exception
    {
        throw EXCEPTION;
    }

    /**
     * Always throws a Exception when called.
     * @return will not return
     * @throws Exception always
     */
    public Object getWithException() throws Exception
    {
        throw EXCEPTION;
    }
    
    /**
     * set the int value
     * @param pInt the new int value
     */
    public void setInt(final int pInt)
    {
        mInt = pInt;
    }
    
    /**
     * @return the int value
     */
    public int getInt()
    {
        return mInt;
    }

}
