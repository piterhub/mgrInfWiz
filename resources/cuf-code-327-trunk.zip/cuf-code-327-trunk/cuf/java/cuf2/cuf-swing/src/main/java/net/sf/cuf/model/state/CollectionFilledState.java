package net.sf.cuf.model.state;

import java.util.Collection;

import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import net.sf.cuf.model.ValueModel;
import net.sf.cuf.state.AbstractState;

/**
 * A state that monitors a value model and is enabled if the value is a collection
 * and the collection is neither null nor empty.
 * <P>
 * Please be aware that changes in the collection's content are
 * only registered when an update is fired for those
 * changes.
 */
public class CollectionFilledState extends AbstractState implements ChangeListener
{
    /** the ValueModel we are responsible for, never null */
    private ValueModel<Collection<?>> mTrigger;

    /**
     * Create a new CollectionFilledState, the given ValueModel serves as a
     * trigger for this state.
     * @param pTrigger the ValueModel to be used as a trigger for
     * this state, must not be null.
     * @throws IllegalArgumentException if pTrigger is null
     */
    public CollectionFilledState(final ValueModel<Collection<?>> pTrigger)
    {
        super();
        if (pTrigger==null)
        {
            throw new IllegalArgumentException("trigger value model must not be null");
        }
        mTrigger      = pTrigger;
        mIsInitialized= true;
        checkValue( mTrigger.getValue());
        mReason       = mTrigger;

        mTrigger.addChangeListener(this);
    }

    /**
     * Callback if our value model changes.
     * @param pEvent not used
     */
    public void stateChanged(final ChangeEvent pEvent)
    {
        checkValue( mTrigger.getValue());
    }

    /**
     * checks the value and adjust the state.
     * @param pValue the value of our trigger
     */
    private void checkValue(final Object pValue)
    {
        boolean newEnabled;
        if (pValue instanceof Collection)
        {
            newEnabled = !((Collection<?>)pValue).isEmpty();
        }
        else
        {
            newEnabled = false; // null or no Collection
        }
        if (newEnabled != mIsEnabled)
        {
            mIsEnabled= newEnabled;
            fireStateChanged();
        }
    }

}
