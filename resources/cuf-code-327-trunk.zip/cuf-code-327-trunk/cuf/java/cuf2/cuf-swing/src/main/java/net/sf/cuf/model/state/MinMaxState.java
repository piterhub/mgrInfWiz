package net.sf.cuf.model.state;

import net.sf.cuf.model.ValueModel;
import net.sf.cuf.state.AbstractState;

import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

/**
 * The MinMaxState is a state that is enabled if the value model has a string value
 * where the length of the string is between a min and max value or the number value of
 * that value model is between min and max. If the value model value is out of range or
 * the value of a different type (not a CharSequence or a Number), this state is disabled.
 * A null value is considered as int zero.
 */
public class MinMaxState extends AbstractState implements ChangeListener
{

    /**
     * the value model we are responsible for, never null
     */
    private ValueModel<?> mTrigger;

    /**
     * null or the min value
     */
    private Integer mMinValue;

    /**
     * null or the max value
     */
    private Integer mMaxValue;

    /** false or true if we should invert the min/max result */
    private boolean mInvert;

    /**
     * Creates a new RegExpState for the given value model and
     * the given regular expression pattern
     * @param pTrigger the trigger value model whose value is observed and checked, must not be null
     * @param pMinValue null or the min value
     * @param pMaxValue null or the max value
     * @param pInvert flag if we should invert the comparison
     */
    public MinMaxState(final ValueModel<?> pTrigger, final Integer pMinValue, final Integer pMaxValue, final boolean pInvert)
    {
        if (pTrigger==null)
        {
            throw new IllegalArgumentException( "pTrigger must not be null");
        }
        mTrigger = pTrigger;
        mMinValue= pMinValue;
        mMaxValue= pMaxValue;
        mInvert  = pInvert;

        mIsInitialized = true;
        mTrigger.addChangeListener( this);
        checkTriggerValue();
    }
    
    /**
     * called when our trigger changes
     * {@inheritDoc}
     */
    public void stateChanged(final ChangeEvent pE)
    {
        checkTriggerValue();
    }

    /**
     * checks the value of our trigger and computes this state value
     */
    private void checkTriggerValue()
    {
        boolean newIsEnabled = false;
        Object value = mTrigger.getValue();
        if (value instanceof CharSequence)
        {
            int length= ((CharSequence)value).length();
            newIsEnabled = isEnabled(length);
        }
        else if (value instanceof Number)
        {
            int intValue= ((Number)value).intValue();
            newIsEnabled = isEnabled(intValue);
        }
        else if (value==null)
        {
            newIsEnabled = isEnabled(0);
        }
        if (newIsEnabled!=mIsEnabled)
        {
            mIsEnabled = newIsEnabled;
            fireStateChanged();
        }
    }


    /**
     * Helper to check if the given value fits our constraints or not.
     * @param pValue the value to check
     * @return true if we consider the value as enabled
     */
    private boolean isEnabled(int pValue)
    {
        boolean isEnabled;
        if (mMinValue!=null && mMaxValue!=null)
        {
            isEnabled = pValue >=mMinValue && pValue <=mMaxValue;
        }
        else if (mMinValue!=null && pValue >=mMinValue)
        {
            isEnabled = true;
        }
        else if (mMaxValue!=null && pValue <=mMaxValue)
        {
            isEnabled = true;
        }
        else
        {
            isEnabled= false;
        }

        if (mInvert)
        {
            return !isEnabled;
        }
        else
        {
            return isEnabled;
        }
    }
}
