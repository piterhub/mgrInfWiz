package net.sf.cuf.state;

/**
 * The StateAdapter interface describes the observer of a State Object.<br/>
 * A StateAdapter monitors one (or none) state object, and notifies its
 * target objects whenever the monitored state changes.<br/>
 * A implementation class of the StateAdapter interfaces defines the semantics
 * of what really happens if the monitored state changes, the StateAdapter
 * interface describes only the protocol to setup/tear down the connections.
 */
public interface StateAdapter
{
    /**
     * Return the name of the state adapter.
     * @return the name of the state (never null)
     */
    public String getName();

    /**
     * Set the name of the state adapter.
     * @param pName the name of the state (must not be null)
     * @throws IllegalArgumentException if pName is null
     */
    public void setName(String pName);


    /**
     * Sets (or resets if pState=null) the state this adapter acts on.
     * @param pState null or the state we act upon
     */
    public void setState(State pState);


    /**
     * Add a target object to our adapter. What happens to the
     * target is depending on the concrete implementaion.
     * @param pTarget target we should act on when our state changes
     * @throws IllegalArgumentException if pTarget is null
     */
    public void add(Object pTarget);

    /**
     * Add a target object with inverted state change logic to our adapter.
     * What happens to the target is depending on the concrete implementaion.
     * @param pTarget target we should act on when our state changes
     * @throws IllegalArgumentException if pTarget is null
     */
    public void addInvert(Object pTarget);

    /**
     * Add a target object to our adapter. What happens to the
     * target is depending on the concrete implementaion.
     * @param pTarget target we should act on when our state changes
     * @param pInvert flag if we should invert the state change
     * @throws IllegalArgumentException if pTarget is null
     */
    public void add(Object pTarget, boolean pInvert);

    /**
     * Removes the handed object of our adapter. Does nothing if
     * pTarget is null or unknown.
     * @param pTarget target we should remove
     */
    public void remove(Object pTarget);
}
