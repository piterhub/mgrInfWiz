package net.sf.cuf.model;

import junit.framework.TestCase;

import java.util.List;
import java.util.Arrays;

/**
 * Tests {@link LOVMapper}.
 */
public class LOVMapperTest extends TestCase
{
    /**
     * Tests the basics of a LOVMapper.
     */
    public void testBasics()
    {
        ValueHolder     lofsHolder = new ValueHolder();
        ValueHolder     domainValue= new ValueHolder();
        LOVMapper       lovMapper  = new LOVMapper(lofsHolder, domainValue);
        SelectionInList sil        = new SelectionInList(lovMapper);
        String[] keys    = {"01", "02", "44"};
        String[] displays= {"M�nchen", "Hamburg", "Wien"};
        lofsHolder.setValue(new List[]{Arrays.asList(keys), Arrays.asList(displays)});

        assertTrue(sil.getIndex()==-1);
        sil.selectionHolder().setValue(2);
        assertTrue(sil.getIndex()==2);
        assertTrue(domainValue.getValue().equals("44"));
        domainValue.setValue("02");
        assertTrue(sil.getIndex()==1);
    }
}
