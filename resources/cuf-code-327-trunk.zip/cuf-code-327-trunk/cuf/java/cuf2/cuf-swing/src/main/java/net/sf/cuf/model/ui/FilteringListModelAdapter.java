package net.sf.cuf.model.ui;

import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import javax.swing.AbstractListModel;
import javax.swing.ComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.event.ChangeEvent;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.JTextComponent;
import javax.swing.text.PlainDocument;

import net.sf.cuf.model.DelegateAccess;
import net.sf.cuf.model.SelectionInList;

/**
 * Adapter class for the combo box widget. Makes the combo box able to filter contents appearing in the
 * dropdown. The user can type a substring of the element he wishes to select and becomes a subset of the
 * elements in the dropdown shown.
 */
public class FilteringListModelAdapter
{

    /** Combobox to set the adapter for, never null. */
    private final JComboBox mComboBox;
    /** SIL to set the adapter for, never null. */
    private final SelectionInList mSil;
    /** ValueModel to get the values to be show, may be null. */
    private final DelegateAccess mDelegateAccess;

    /** Text component of the combo box, never null. */
    private final JTextComponent mTextComponent;
    /** Model to be set in the combobox. Enables filtering of the dropdown elements. Never null. */
    private final FilteringListModel mModel;
    /** Marker if we are inside a selection change, we then ignore other selection changes. */
    private boolean mInSelectionChange;
    /** Document to be set in the text component. Never null. */
    private final FilteringDocument mDocument;

    /**
     * Creates a new adapter between a combo box and a SelectionInList value model.
     *
     * @param pComboBox Combo box to set the adapter for. Never null.
     * @param pSil Selection in list to set the adapter for. Never null.
     * @param pDelegateAccess the converter we use to map between the SelectionInList list objects and the
     *            display objects. Nullable.
     * @throws IllegalArgumentException if not nullable parameters are null.
     */
    public FilteringListModelAdapter(final JComboBox pComboBox,
                                     final SelectionInList pSil,
                                     final DelegateAccess pDelegateAccess)
    {
        this(pComboBox, pSil, pDelegateAccess, true);
    }

    /**
     * Creates a new adapter between a combo box and a SelectionInList value model.
     *
     * @param pComboBox Combo box to set the adapter for. Never null.
     * @param pSil Selection in list to set the adapter for. Never null.
     * @param pDelegateAccess null or the converter we use to map between the SelectionInList list objects and
     *            the display objects.
     * @param pDeleteInvalidFilterAfterFocusLost if true, after the focus on the combo box is lost a check
     *            will be performed, if the filtering text is present in the value model. If the text is not
     *            present, it will be deleted.
     * @throws IllegalArgumentException if not nullable parameters are null.
     */
    public FilteringListModelAdapter(final JComboBox pComboBox,
                                     final SelectionInList pSil,
                                     final DelegateAccess pDelegateAccess,
                                     final boolean pDeleteInvalidFilterAfterFocusLost)
    {
        if (pComboBox == null)
        {
            throw new IllegalArgumentException("pComboBox must not be null");
        }
        if (pSil == null)
        {
            throw new IllegalArgumentException("pComboBox must not be null");
        }

        mComboBox = pComboBox;
        mSil = pSil;
        mDelegateAccess = pDelegateAccess;
        mTextComponent = (JTextComponent) mComboBox.getEditor().getEditorComponent();

        // sets document and model of the combo box
        mComboBox.setEditable(true);
        mModel = new FilteringListModel();
        mComboBox.setModel(mModel);
        mDocument = new FilteringDocument();
        mTextComponent.setDocument(mDocument);

        // model update listeners
        mSil.onChangeSend(this, "vmDataChanged");
        mSil.selectionHolder().onChangeSend(this, "vmSelectionChanged");

        // things to do after the focus is lost
        mTextComponent.addFocusListener(new FocusAdapter()
        {
            public void focusLost(final FocusEvent pE)
            {
                // if the filtering content is invalid after focus lost -> delete it
                if (pDeleteInvalidFilterAfterFocusLost)
                {
                    deleteFilteringTextIfInvalid();
                }

                mComboBox.hidePopup();
                mModel.setPattern("");
                mDocument.clearFlags();
            }

        });
    }

    /**
     * Our own document to listen for all relevant filtering pattern changes.
     */
    private class FilteringDocument extends PlainDocument
    {

        /** Default serial version UID */
        private static final long serialVersionUID = 1L;

        // we want to handle arrows and enter in special way and not update model if the keys are pressed
        // reason: if someone inputs a pattern and moves one element down, we don't want this element to be the
        // new pattern. we want this pattern to be ignored

        /** Flag, if the up/down arrow keys have been pressed. */
        private boolean mArrowKeyPressed = false;
        /** Flag, if the enter key have been pressed. */
        private boolean mEnterKeyPressed = false;

        /**
         * Default constructor.
         */
        public FilteringDocument()
        {
            mTextComponent.addKeyListener(new KeyAdapter()
            {
                public void keyPressed(final KeyEvent pE)
                {
                    if (pE.getKeyCode() > KeyEvent.VK_0)
                    {
                        mComboBox.showPopup();
                    }

                    int key = pE.getKeyCode();
                    if (key == KeyEvent.VK_UP || key == KeyEvent.VK_DOWN)
                    {
                        mArrowKeyPressed = true;
                    }
                    if (key == KeyEvent.VK_ENTER)
                    {
                        mEnterKeyPressed = true;
                    }
                }
            });
        }

        /** {@inheritDoc} */
        public void remove(final int pOffs, final int pLen) throws BadLocationException
        {
            super.remove(pOffs, pLen);
            if (mArrowKeyPressed)
            {
                mArrowKeyPressed = false;
            }
            else
            {
                updateModel();
            }
        }

        /** {@inheritDoc} */
        public void insertString(final int pOffs, final String pStr, final AttributeSet pA) throws BadLocationException
        {
            super.insertString(pOffs, pStr, pA);
            if (mEnterKeyPressed)
            {
                mEnterKeyPressed = false;
                return;
            }

            String text = getText(0, getLength());
            if (mArrowKeyPressed)
            {
                mModel.setSelectedItem(text);
                mArrowKeyPressed = false;
            }
            else if (!text.equals(mModel.getSelectedItem()))
            {
                updateModel();
            }
        }

        /**
         * Updates the model of our filtering widget. Notifies, that the filtering pattern has been changed.
         */
        private void updateModel()
        {
            String textToMatch = mTextComponent.getText();
            mModel.setPattern(textToMatch);
        }

        /**
         * Clears the key flags.
         */
        public void clearFlags()
        {
            mEnterKeyPressed = false;
            mArrowKeyPressed = false;
        }

    }

    /**
     * Data model of our filtering combo box. Holds a subset of data to be shown in the drop down.
     */
    private class FilteringListModel extends AbstractListModel implements ComboBoxModel
    {

        /** Default serial version UID */
        private static final long serialVersionUID = 1L;

        /** Content of the drop down list. */
        private final FilteredData mData = new FilteredData();

        /**
         * Helper class holding the content of the drop down list.
         */
        class FilteredData
        {

            /** Collection holding the filtered values as strings. */
            private List mFilteredData;

            /**
             * @return Filtered data.
             */
            List getData()
            {
                return mFilteredData == null ? Collections.EMPTY_LIST : mFilteredData;
            }

            /**
             * Triggers the refiltering after the pattern has changed.
             *
             * @param pPattern Pattern to filter after.
             */
            void setPattern(final String pPattern)
            {
                String patternLc = pPattern == null ? "" : pPattern.toLowerCase();
                filter(patternLc);
            }

            /**
             * Performs the filtering for the specified pattern.
             *
             * @param pPattern Pattern to filter after.
             */
            private void filter(final String pPattern)
            {
                mFilteredData = new ArrayList();
                List list = (List) mSil.getValue();
                if (list == null)
                {
                    return;
                }
                for (Iterator i = list.iterator(); i.hasNext();)
                {
                    Object value = getValueFromObject(i.next());
                    filterElement(pPattern, value);
                }
            }

            /**
             * Performs the filtering for one element. If the element contains the pattern specified, it will
             * be added to the filtering data.
             *
             * @param pPattern Pattern to filter after.
             * @param pObject Element to check.
             */
            private void filterElement(final String pPattern, final Object pObject)
            {
                // sicher is sicher
                if (pObject == null)
                {
                    if ("".equals(pPattern))
                    {
                        mFilteredData.add(null);
                    }
                }
                else
                {
                    String string = pObject.toString();
                    if (string.toLowerCase().contains(pPattern))
                    {
                        mFilteredData.add(string);
                    }
                }
            }
        }

        /**
         * Constructor.
         */
        public FilteringListModel()
        {
            // init empty
            setPattern("");
        }

        /**
         * Triggers the filtering for the given pattern.
         *
         * @param pPattern Pattern to filter after.
         */
        public void setPattern(final String pPattern)
        {
            List pre = mData.getData();
            mData.setPattern(pPattern);
            List post = mData.getData();
            // update dropdown content if necessary
            if (!pre.equals(post))
            {
                // Workround over a Swing bug. See: http://bugs.sun.com/bugdatabase/view_bug.do?bug_id=4743225
                if (mComboBox.isPopupVisible())
                {
                    mComboBox.hidePopup();
                    mComboBox.showPopup();
                }
            }
        }

        /** {@inheritDoc} */
        public Object getSelectedItem()
        {
            int index = mSil.getIndex();
            if (index < 0 || mSil.getValue() == null)
            {
                return null;
            }
            else
            {
                Object object = ((List) mSil.getValue()).get(index);
                return getValueFromObject(object);
            }
        }

        /** {@inheritDoc} */
        public void setSelectedItem(final Object pAnObject)
        {
            int index = getIndexByObject(pAnObject);
            mSil.selectionHolder().setValue(index);
            if (index >= 0)
            {
                mTextComponent.setText((String) getSelectedItem());
            }
            else
            {
                mTextComponent.setText("");
            }
        }

        /** {@inheritDoc} */
        public int getSize()
        {
            return mData.getData().size();
        }

        /** {@inheritDoc} */
        public Object getElementAt(final int pIndex)
        {
            return mData.getData().get(pIndex);
        }

        /**
         * Informs all listeners that the content has been changed.
         */
        public void fireContentChanged()
        {
            fireContentsChanged(FilteringListModel.this, -1, -1);
        }
    }

    /**
     * Small helper to find a item in our list. The item may be of a different type than the entries in our
     * list, if a DelegateAccess object is used for display conversion.
     *
     * @param pItem the (display) object we are searching
     * @return -1 or the index of the item
     */
    public int getIndexByObject(final Object pItem)
    {
        List list = (List) mSil.getValue();
        if (list == null)
        {
            return -1;
        }
        int index = -1;
        if (mDelegateAccess != null)
        {
            for (int i = 0, n = list.size(); i < n; i++)
            {
                Object item = mDelegateAccess.getValue(list.get(i));
                if (pItem == item || pItem != null && pItem.equals(item))
                {
                    index = i;
                    break;
                }
            }
        }
        else
        {
            index = list.indexOf(pItem);
        }
        return index;
    }

    /**
     * This operation is called after the value models data has been changed.
     *
     * @param pEvent Additional event information.
     */
    public void vmDataChanged(final ChangeEvent pEvent)
    {
        if (mInSelectionChange)
        {
            return;
        }

        mInSelectionChange = true;
        try
        {
            if ("".equals(mTextComponent.getText()))
            {
                mModel.setPattern("");
            }
            else
            {
                mTextComponent.setText("");
            }
            mModel.fireContentChanged();
        }
        finally
        {
            mInSelectionChange = false;
        }
    }

    /**
     * This is called after the selection in value model changes.
     *
     * @param pEvent Additional event information.
     */
    public void vmSelectionChanged(final ChangeEvent pEvent)
    {
        if (mInSelectionChange)
        {
            return;
        }

        int index = mSil.selectionHolder().intValue();

        mInSelectionChange = true;
        try
        {
            List list = (List) mSil.getValue();
            if (list == null)
            {
                return;
            }
            if (index == -1)
            {
                mTextComponent.setText("");
            }
            else
            {
                Object selectedItem = list.get(index);
                Object value = getValueFromObject(selectedItem);
                if (value != null)
                {
                    mTextComponent.setText(value.toString());
                }
                else
                {
                    mTextComponent.setText("");
                }
            }
        }
        finally
        {
            mInSelectionChange = false;
        }
    }

    /**
     * Depending on the delegate access object beeing set or not, fetches the displayable object from the
     * item.
     *
     * @param pObject Object.
     * @return Displayable object.
     */
    private Object getValueFromObject(final Object pObject)
    {
        if (mDelegateAccess == null)
        {
            return pObject;
        }
        else
        {
            return mDelegateAccess.getValue(pObject);
        }
    }

    /**
     * If the filtering text is invalid (not present in the value model) it will be deleted.
     */
    public void deleteFilteringTextIfInvalid()
    {
        String text = mTextComponent.getText();
        int index = getIndexByObject(text);
        if (index < 0)
        {
            mModel.setSelectedItem(null);
        }
    }

    /**
     * Sets filtering for the specified pattern.
     *
     * @param pPattern Pattern.
     */
    public void setPattern(final String pPattern)
    {
        mModel.setPattern(pPattern);
    }

}
