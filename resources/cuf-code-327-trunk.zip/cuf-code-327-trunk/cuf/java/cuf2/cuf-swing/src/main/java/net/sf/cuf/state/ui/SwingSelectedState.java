package net.sf.cuf.state.ui;

import net.sf.cuf.state.State;

import javax.swing.ButtonModel;
import javax.swing.AbstractButton;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

/**
 * The SwingSelectedState class models a State with a Swing ButtonModel
 * as the state source.<br/>
 */
public class SwingSelectedState extends AbstractSwingState implements State, ChangeListener
{
    /** the ButtonModel we use as enable/disable source, never null */
    private ButtonModel       mModel;

    /**
     * Creates a new initialized state with the model of the handed button
     * as its state.
     * @param pButton the button, must not be null
     */
    public SwingSelectedState(final AbstractButton pButton)
    {
        super();
        if (pButton==null)
        {
            throw new IllegalArgumentException("Button must not be null");
        }
        mName= pButton.getName();
        init(pButton.getModel());
    }
    /**
     * Creates a new initialized state with the handed model as state and
     * with an empty string as name.
     * @param pModel the model, must not be null
     * @throws IllegalArgumentException if pModel is null
     */
    public SwingSelectedState(final ButtonModel pModel)
    {
        super();
        init(pModel);
    }

    /**
     * Common init stuff of the constructors.
     * @param pModel the button model, must not be null
     */
    private void init(final ButtonModel pModel)
    {
        if (pModel==null)
        {
            throw new IllegalArgumentException("ButtonModel must not be null");
        }
        if (mName==null)
            mName= "";
        mModel= pModel;

        // initially set the state according to selection model
        mIsEnabled = getInternalState();

        mModel.addChangeListener(this);
    }

    /**
     * Invoked when the target of the listener has changed its state.
     *
     * @param pEvent  a ChangeEvent object
     */
    public void stateChanged(final ChangeEvent pEvent)
    {
        checkStateChange();
    }

    /**
     * Returns the selection state of our button model.
     * @return true if our button model is selected
     */
    protected boolean getInternalState()
    {
        return mModel.isSelected();
    }

    /**
     * Set the source of the state as the reason for a change.
     */
    protected void setReason()
    {
        mReason= mModel;
    }

}
