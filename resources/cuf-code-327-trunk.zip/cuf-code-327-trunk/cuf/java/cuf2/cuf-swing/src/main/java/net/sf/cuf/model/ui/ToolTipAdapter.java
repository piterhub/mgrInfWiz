package net.sf.cuf.model.ui;

import net.sf.cuf.model.ValueModel;

import javax.swing.JComponent;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;

/**
 * A ToolTipAdapter connects the value of a ValueModel to the
 * tooltip text a JComponent. This is a one way adapter, changes
 * of the tooltip of the JComponent are not propagated to the
 * ValueModel.
 * The tool tip text is initially set from the value model.
 */
public class ToolTipAdapter implements ChangeListener
{
    /** the value model we adapt to, never null */
    private ValueModel<?>  mValueModel;
    /** the component we set the tooltip for, never null */
    private JComponent  mComponent;

    /**
     * Creates a new adapter between a ValueModel and a JComponent .
     * Whenever the ValueModel changes, the tooltip is adjusted accordingly.
     * @param pValueModel the value model, must not be null
     * @param pComponent the swing component, must not be null
     */
    public ToolTipAdapter(final ValueModel<?> pValueModel, final JComponent pComponent)
    {
        if (pValueModel==null)
            throw new IllegalArgumentException("value model must not be null");
        if (pComponent==null)
            throw new IllegalArgumentException("swing component must not be null");

        mValueModel= pValueModel;
        mComponent = pComponent;
        stateChanged(null);
        mValueModel.addChangeListener(this);
    }

    /**
     * Invoked during construction or when the value model changed its state.
     * @param pEvent a ChangeEvent object, not nused
     */
    public void stateChanged(final ChangeEvent pEvent)
    {
        Object value= mValueModel.getValue();
        String tooltip= (value==null) ?  null : value.toString();
        if ("".equals(tooltip)) tooltip= null;
        mComponent.setToolTipText(tooltip);
    }
}
