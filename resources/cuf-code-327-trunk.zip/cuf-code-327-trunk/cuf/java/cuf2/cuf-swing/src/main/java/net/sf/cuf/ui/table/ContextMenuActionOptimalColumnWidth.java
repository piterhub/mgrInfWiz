package net.sf.cuf.ui.table;


/**
 * Context menu action to set a table column to its optimal size.
 * It uses {@link OptimalColumnWidthSupport}.
 *
 * @author  Hendrik W&ouml;rdehoff, sd&amp;m AG
 */
public class ContextMenuActionOptimalColumnWidth
extends ContextMenuAction
{
    public String getKennung()
    {
        return mAdapter.getContextMenuKennung()+"_OPTIMALWIDTH";
    }

    /**
     * @return  <code>true</code> only if the user clicked on a column
     */
    public boolean isEnabled()
    {
        return mAdapter.getViewColumnIndex() != -1;
    }

    public void performAction()
    {
        OptimalColumnWidthSupport.adjustToOptimalColumnWidth(mAdapter.getTable(), mAdapter.getViewColumnIndex());
    }
}