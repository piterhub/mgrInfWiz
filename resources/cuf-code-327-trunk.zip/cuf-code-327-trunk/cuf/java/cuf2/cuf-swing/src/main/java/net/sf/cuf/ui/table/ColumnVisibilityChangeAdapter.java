package net.sf.cuf.ui.table;


/**
 * Dummy implementation of the listener interface for showing/hiding of table columns.
 *
 * @author  Hendrik W&ouml;rdehoff, sd&amp;m AG
 */
public class ColumnVisibilityChangeAdapter
implements ColumnVisibilityChangeListener
{
    /**
     * Ignore that a table column was shown.
     *
     * @param  pEvent  information about the shown column
     */
    public void columnShown(final ColumnVisibilityChangeEvent pEvent)
    {
    }

    /**
     * Ignore that a table column was hidden.
     *
     * @param  pEvent  information about the shown column
     */
    public void columnHidden(final ColumnVisibilityChangeEvent pEvent)
    {
    }
}