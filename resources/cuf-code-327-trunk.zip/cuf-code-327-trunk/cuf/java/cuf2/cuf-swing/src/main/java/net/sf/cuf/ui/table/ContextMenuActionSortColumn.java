package net.sf.cuf.ui.table;


/**
 * Context menu action to set sorting on a column of a table with a {@link TableSorter} table model.
 * The action provides for ascending and descending sorting.
 *
 * @author  Hendrik W&ouml;rdehoff, sd&amp;m AG
 */
public class ContextMenuActionSortColumn
extends ContextMenuAction
{
    private boolean mAscending;

    public ContextMenuActionSortColumn(final boolean pAscending)
    {
        this.mAscending = pAscending;
    }

    public String getKennung()
    {
        return mAdapter.getContextMenuKennung()+(mAscending ? "_SORTCOLASC" : "_SORTCOLDESC");
    }

    /**
     * @return  <code>true</code> only if the user clicked on a column
     */
    public boolean isEnabled()
    {
        return mAdapter.getViewColumnIndex() != -1;
    }

    public void performAction()
    {
        TableSorter sorter = (TableSorter) mAdapter.getTable().getModel();
        sorter.resetColumns();
        sorter.sortByColumn(mAdapter.getModelColumnIndex(), mAscending);
    }
}
