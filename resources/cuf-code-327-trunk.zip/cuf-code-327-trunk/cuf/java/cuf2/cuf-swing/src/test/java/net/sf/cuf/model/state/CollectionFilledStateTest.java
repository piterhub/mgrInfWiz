package net.sf.cuf.model.state;

import java.util.ArrayList;
import java.util.List;

import junit.framework.TestCase;

import net.sf.cuf.model.ValueHolder;

/**
 * tests {@link CollectionFilledState}
 */
public class CollectionFilledStateTest extends TestCase
{
    
    public void testCreation()
    {
        ValueHolder vm = new ValueHolder();
        CollectionFilledState state = new CollectionFilledState( vm);
        assertFalse( "null value must lead to disabled", state.isEnabled());
    }
    
    public void testNoCollection()
    {
        ValueHolder vm = new ValueHolder();
        CollectionFilledState state = new CollectionFilledState( vm);
        vm.setValue( "Test");
        assertFalse( "String value must lead to disabled", state.isEnabled());
    }
    
    public void testEmptyCollection()
    {
        ValueHolder vm = new ValueHolder();
        CollectionFilledState state = new CollectionFilledState( vm);
        vm.setValue( new ArrayList());
        assertFalse( "empty collection value must lead to disabled", state.isEnabled());
    }
    
    public void testFilledCollection()
    {
        ValueHolder vm = new ValueHolder();
        CollectionFilledState state = new CollectionFilledState( vm);
        List list = new ArrayList();
        list.add( "Element");
        vm.setValue( list);
        assertTrue( "filled collection value must lead to enabled", state.isEnabled());
    }
    
}
