package net.sf.cuf.model.converter;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import junit.framework.TestCase;

import net.sf.cuf.model.ValueHolder;

/**
 * Tests the {@link ListFilterConverter}
 */
public class ListFilterConverterTest extends TestCase
{

    /**
     * tests a converter with no filter
     */
    public void testNoFilter()
    {
        ValueHolder valueHolder = new ValueHolder();
        ListFilterConverter listFilterConverter = new ListFilterConverter( valueHolder);
        // null value
        assertNull( "null must be passed through", listFilterConverter.getValue());
        // empty list
        valueHolder.setValue(new ArrayList());
        assertTrue( "empty list must be passed through", ((List)listFilterConverter.getValue()).isEmpty());
        // list with values
        List baseList = Arrays.asList("Hugo Boss", "Sony Entertainment", "sd&m");
        valueHolder.setValue( baseList);
        assertEquals( "list must be passed through", baseList, listFilterConverter.getValue());
    }
    
    /**
     * tests a converter with a filter
     */
    public void testWithFilter()
    {
        ValueHolder valueHolder = new ValueHolder();
        ListFilterConverter listFilterConverter = new ListFilterConverter( valueHolder);
        listFilterConverter.setFilter( new ListFilterConverter.Filter() {
            public boolean accept(final Object pEntry)
            {
                return ((String)pEntry).length()>4;
            }
        });
        // null value
        assertNull( "null must be passed through", listFilterConverter.getValue());
        // empty list
        valueHolder.setValue(new ArrayList());
        assertTrue( "empty list must be passed through", ((List)listFilterConverter.getValue()).isEmpty());
        // list with values
        List baseList = Arrays.asList("Hugo Boss", "Sony Entertainment", "sd&m");
        valueHolder.setValue( baseList);
        List targetList = Arrays.asList("Hugo Boss", "Sony Entertainment");
        assertEquals( "list must be filtered", targetList, listFilterConverter.getValue());
    }
    
}
