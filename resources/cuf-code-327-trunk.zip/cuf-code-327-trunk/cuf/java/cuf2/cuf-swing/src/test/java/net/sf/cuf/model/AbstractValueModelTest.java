package net.sf.cuf.model;

import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import junit.framework.TestCase;


/**
 * Tests the {@link AbstractValueModel}.
 */
public class AbstractValueModelTest extends TestCase
{

    /**
     * Tests notification registration.
     */
    public void testOnChangeSend()
    {
        AVMTestImpl avm = new AVMTestImpl();
        try
        {
            avm.onChangeSend(null, "");
            fail("Calling onChangeSend with a not null object must result in IllegalArgumentException");
        }
        catch (IllegalArgumentException ex)
        {
            // correct
        }
        try
        {
            avm.onChangeSend(this, "THIS METHOD DOES NOT EXIST");
            fail("Calling onChangeSend with a not existing method must result in IllegalArgumentException");
        }
        catch (IllegalArgumentException ex)
        {
            // correct
        }
        try
        {
            avm.onChangeSend(this, "testOnChangeSend");
            fail("Calling onChangeSend with an illegal method signature must result in IllegalArgumentException");
        }
        catch (IllegalArgumentException ex)
        {
            // correct
        }
        CallbackTarget callbackTarget = new CallbackTarget();
        avm.onChangeSend(callbackTarget, "stateChanged");
        assertFalse(
                "Initial value of callbackTarget.wasCalledChange() must be false",
                callbackTarget.isStateChangedCalled());
        assertNull(
                "Initial value of callbackTarget.getChangeEvent() must be null",
                callbackTarget.getStateChangedEvent());
        avm.fireStateChanged();
        assertTrue("While fireStateChange the callback method must be called.", callbackTarget.isStateChangedCalled());
        assertTrue(
                "While fireStateChange the callback method must be called with a ChangeEvent",
                callbackTarget.getStateChangedEvent() instanceof ChangeEvent);
        assertSame(
                "While fireStateChange the callback method must be called with a ChangeEvent that refers to the model",
                avm,
                callbackTarget.getStateChangedEvent().getSource());
        callbackTarget.reset();
        avm.retractInterestsFor(callbackTarget);
        assertFalse(
                "Initial value of callbackTarget.wasCalledChange() must be false",
                callbackTarget.isStateChangedCalled());
        assertNull(
                "Initial value of callbackTarget.getChangeEvent() must be null",
                callbackTarget.getStateChangedEvent());
        avm.fireStateChanged();
        assertFalse(
                "After retractInterestsFor events callbackTarget must no longer be notified",
                callbackTarget.isStateChangedCalled());
    }

    /**
     * Tests the retracting of interests
     */
    public void testRetractInterestsFor()
    {
        AVMTestImpl avm = new AVMTestImpl();
        CallbackTarget callbackTarget = new CallbackTarget();
        avm.addChangeListener(callbackTarget);
        avm.onChangeSend(callbackTarget, "stateChanged");
        avm.retractInterestsFor(callbackTarget);
        avm.fireStateChanged();
        assertTrue(
                "Even after retracting the interests a registered change listener must be called.",
                callbackTarget.isStateChangedCalled());
    }

    /**
     * Tests listener registration.
     */
    public void testAddChangeListener()
    {
        AVMTestImpl avm = new AVMTestImpl();
        try
        {
            avm.addChangeListener(null);
            fail("Calling addChangeListener with a not null object must result in IllegalArgumentException");
        }
        catch (IllegalArgumentException ex)
        {
            // correct
        }
        CallbackTarget callbackTarget = new CallbackTarget();
        avm.addChangeListener(callbackTarget);
        assertFalse(
                "Initial value of callbackTarget.isStateChangedCalled() must be false",
                callbackTarget.isStateChangedCalled());
        assertNull(
                "Initial value of callbackTarget.getStateChangedEvent() must be null",
                callbackTarget.getStateChangedEvent());
        avm.fireStateChanged();
        assertTrue("While fireStateChange the callback method must be called.", callbackTarget.isStateChangedCalled());
        assertTrue(
                "While fireStateChange the callback method must be called with a ChangeEvent",
                callbackTarget.getStateChangedEvent() instanceof ChangeEvent);
        assertSame(
                "While fireStateChange the callback method must be called with a ChangeEvent that refers to the model",
                avm,
                callbackTarget.getStateChangedEvent().getSource());
        callbackTarget.reset();
        avm.removeChangeListener(callbackTarget);
        assertFalse(
                "Initial value of callbackTarget.isStateChangedCalled() must be false",
                callbackTarget.isStateChangedCalled());
        assertNull(
                "Initial value of callbackTarget.getStateChangedEvent() must be null",
                callbackTarget.getStateChangedEvent());
        avm.fireStateChanged();
        assertFalse(
                "After retractInterestsFor events callbackTarget must no longer be notified",
                callbackTarget.isStateChangedCalled());
    }

    /**
     * Tests the removal of listeners
     */
    public void testRemoveChangeListener()
    {
        AVMTestImpl avm = new AVMTestImpl();
        CallbackTarget callbackTarget = new CallbackTarget();
        avm.addChangeListener(callbackTarget);
        avm.onChangeSend(callbackTarget, "stateChanged");
        avm.removeChangeListener(callbackTarget);
        avm.fireStateChanged();
        assertTrue(
                "Even after removing a ChangeListener the registered methods must be called.",
                callbackTarget.isStateChangedCalled());
    }

    /**
     * Test for dispose.
     */
    public void testDispose()
    {
        AVMTestImpl avm = new AVMTestImpl();
        CallbackTarget callbackTarget = new CallbackTarget();
        avm.addChangeListener(callbackTarget);
        avm.onChangeSend(callbackTarget, "stateChanged");
        avm.dispose();
        avm.fireStateChanged();
        assertFalse(
                "After disposing, no events should come to registered listeners.",
                callbackTarget.isStateChangedCalled());
    }

    /**
     * Test for setValue with null
     */
    public void testSetValueNull()
    {
        AVMTestImpl avm = new AVMTestImpl();
        assertFalse("Initially, setValueCalled must be false", avm.mSetValueCalled);
        avm.setValue(null);
        assertTrue("setValue(o,f) must have been called", avm.mSetValueCalled);
        assertSame("setValue(o,f) must have been called with o==null", null, avm.mValue);
        assertFalse("setValue(o,f) must have been called with f==false", avm.mWasSetForced);
    }

    /**
     * Test for setValue with an object
     */
    public void testSetValueNotNull()
    {
        AVMTestImpl avm = new AVMTestImpl();
        assertFalse("Initially, setValueCalled must be false", avm.mSetValueCalled);
        Object obj = new Object();
        avm.setValue(obj);
        assertTrue("setValue(o,f) must have been called", avm.mSetValueCalled);
        assertSame("setValue(o,f) must have been called with o==obj", obj, avm.mValue);
        assertFalse("setValue(o,f) must have been called with f==false", avm.mWasSetForced);
    }

    /**
     * Test for setValueForced with null
     */
    public void testSetValueForcedNull()
    {
        AVMTestImpl avm = new AVMTestImpl();
        assertFalse("Initially, setValueCalled must be false", avm.mSetValueCalled);
        avm.setValueForced(null);
        assertTrue("setValue(o,f) must have been called", avm.mSetValueCalled);
        assertSame("setValue(o,f) must have been called with o==null", null, avm.mValue);
        assertTrue("setValue(o,f) must have been called with f==true", avm.mWasSetForced);
    }

    /**
     * Test for setValueForced with an object
     */
    public void testSetValueForcedNotNull()
    {
        AVMTestImpl avm = new AVMTestImpl();
        assertFalse("Initially, setValueCalled must be false", avm.mSetValueCalled);
        Object obj = new Object();
        avm.setValueForced(obj);
        assertTrue("setValue(o,f) must have been called", avm.mSetValueCalled);
        assertSame("setValue(o,f) must have been called with o==obj", obj, avm.mValue);
        assertTrue("setValue(o,f) must have been called with f==true", avm.mWasSetForced);
    }

    /**
     * Test for signalExternalUpdate
     */
    public void testSignalExternalUpdate()
    {
        final AVMTestImpl avm = new AVMTestImpl();
        avm.addChangeListener(new ChangeListener()
        {
            /**
             * @see javax.swing.event.ChangeListener#stateChanged(javax.swing.event.ChangeEvent)
             */
            public void stateChanged(final ChangeEvent e)
            {
                assertSame("Event must come from the avm", avm, e.getSource());
                assertFalse("avm must not be in setValue", avm.isInSetValue());
                assertTrue("avm must be in forced mode", avm.isSetForced());
            }
        });
        avm.signalExternalUpdate();
    }

    /**
     * Tests setInSetValue, getInSetValue, and isSetForced
     */
    public void testSetInSetValue()
    {
        AVMTestImpl avm = new AVMTestImpl();
        assertFalse("Initially inSetValue must be false", avm.isInSetValue());
        assertFalse("Initially isSetForced must be false", avm.isSetForced());
        avm.setInSetValue(true, false);
        assertTrue("inSetValue must be true", avm.isInSetValue());
        assertFalse("isSetForced must be false", avm.isSetForced());
        avm.setInSetValue(false, true);
        assertFalse("inSetValue must be false", avm.isInSetValue());
        assertTrue("isSetForced must be true", avm.isSetForced());
        avm.setInSetValue(true, true);
        assertTrue("inSetValue must be true", avm.isInSetValue());
        assertTrue("isSetForced must be true", avm.isSetForced());
        avm.setInSetValue(false, false);
        assertFalse("inSetValue must be false", avm.isInSetValue());
        assertFalse("isSetForced must be false", avm.isSetForced());
    }

    /**
     * Tests {@link AbstractValueModel#setValue(boolean)}
     */
    public void testSetValueBoolean()
    {
        AVMTestImpl avm = new AVMTestImpl();
        assertFalse("Initially, setValueCalled must be false", avm.mSetValueCalled);
        avm.setValue(true);
        assertTrue("setValue(o,f) must have been called", avm.mSetValueCalled);
        assertSame("setValue(o,f) must have been called with o==Boolean.TRUE", Boolean.TRUE, avm.mValue);
        avm.reset();
        avm.setValue(false);
        assertTrue("setValue(o,f) must have been called", avm.mSetValueCalled);
        assertSame("setValue(o,f) must have been called with o==Boolean.FALSE", Boolean.FALSE, avm.mValue);
    }

    /**
     * Tests {@link AbstractValueModel#booleanValue()}.
     */
    public void testBooleanValue()
    {
        AVMTestImpl avm = new AVMTestImpl();
        assertFalse("Initially, getValueCalled must be false", avm.mGetValueCalled);
        avm.mValue = Boolean.TRUE;
        assertTrue("booleanValue() must return true for value Boolean.TRUE", avm.booleanValue());
        assertTrue("getValue() must have been called", avm.mGetValueCalled);
        avm.mValue = Boolean.FALSE;
        assertFalse("booleanValue() must return false for value Boolean.FALSE", avm.booleanValue());
        avm.mValue = "true";
        assertTrue("booleanValue() must return true for value 'true'", avm.booleanValue());
        avm.mValue = "false";
        assertFalse("booleanValue() must return false for value 'false'", avm.booleanValue());
        avm.mValue = "no value";
        assertFalse("booleanValue() must return false for value 'no value'", avm.booleanValue());
        try
        {
            avm.booleanValue();
        }
        catch (Exception ex)
        {
            fail("booleanValue() must not throw an Exception for non-null value");
        }
        avm.mValue = null;
        boolean avmBoolean= avm.booleanValue();
        assertFalse("booleanValue() must return false for value null", avmBoolean);
    }

    /**
     * Tests {@link AbstractValueModel#setValue(int)}
     */
    public void testSetValueInteger()
    {
        AVMTestImpl avm = new AVMTestImpl();
        assertFalse("Initially, setValueCalled must be false", avm.mSetValueCalled);
        avm.setValue(0);
        assertTrue("setValue(o,f) must have been called", avm.mSetValueCalled);
        assertEquals("setValue(o,f) must have been called with o==Integer(0)", 0, avm.mValue);
        avm.reset();
        avm.setValue(Integer.MAX_VALUE);
        assertTrue("setValue(o,f) must have been called", avm.mSetValueCalled);
        assertEquals(
                "setValue(o,f) must have been called with o==Integer(Integer.MAX_VALUE)",
                Integer.MAX_VALUE,
                avm.mValue);
        avm.reset();
        avm.setValue(Integer.MIN_VALUE);
        assertTrue("setValue(o,f) must have been called", avm.mSetValueCalled);
        assertEquals(
                "setValue(o,f) must have been called with o==Integer(Integer.MIN_VALUE)",
                Integer.MIN_VALUE,
                avm.mValue);
    }

    /**
     * Tests {@link AbstractValueModel#intValue()}.
     */
    public void testIntValue()
    {
        AVMTestImpl avm = new AVMTestImpl();
        assertFalse("Initially, getValueCalled must be false", avm.mGetValueCalled);
        avm.mValue = 0;
        assertEquals("intValue() must return 0 for value Integer(0)", 0, avm.intValue());
        assertTrue("getValue() must have been called", avm.mGetValueCalled);
        avm.mValue = Integer.MAX_VALUE;
        assertEquals(
                "intValue() must return Integer.MAX_VALUE for value Integer(Integer.MAX_VALUE)",
                Integer.MAX_VALUE,
                avm.intValue());
        avm.mValue = Integer.MIN_VALUE;
        assertEquals(
                "intValue() must return Integer.MIN_VALUE for value Integer(Integer.MIN_VALUE)",
                Integer.MIN_VALUE,
                avm.intValue());
        avm.mValue = "17";
        assertEquals("intValue() must return 17 for value '17'", 17, avm.intValue());
        avm.mValue = "-1829371";
        assertEquals("intValue() must return -1829371 for value '-1829371'", -1829371, avm.intValue());
        avm.mValue = String.valueOf((long) Integer.MAX_VALUE + 1);
        try
        {
            avm.intValue();
            fail("intValue() must throw NumberFormatException for value '" + ((long) Integer.MAX_VALUE + 1) + '\'');
        }
        catch (NumberFormatException ex)
        {
            // correct
        }
        avm.mValue = "no value";
        try
        {
            avm.intValue();
            fail("intValue() must throw NumberFormatException for value 'no value'");
        }
        catch (NumberFormatException ex)
        {
            // correct
        }
        avm.mValue = null;
        int avmInt= avm.intValue();
        assertTrue("intValue() must return 0 for value null", avmInt==0);
    }

    /**
     * Tests {@link AbstractValueModel#setValue(long)}
     */
    public void testSetValueLong()
    {
        AVMTestImpl avm = new AVMTestImpl();
        assertFalse("Initially, setValueCalled must be false", avm.mSetValueCalled);
        avm.setValue((long) 0);
        assertTrue("setValue(o,f) must have been called", avm.mSetValueCalled);
        assertEquals("setValue(o,f) must have been called with o==Long(0)", (long) 0, avm.mValue);
        avm.reset();
        avm.setValue(Long.MAX_VALUE);
        assertTrue("setValue(o,f) must have been called", avm.mSetValueCalled);
        assertEquals(
                "setValue(o,f) must have been called with o==Long(Long.MAX_VALUE)",
                Long.MAX_VALUE,
                avm.mValue);
        avm.reset();
        avm.setValue(Long.MIN_VALUE);
        assertTrue("setValue(o,f) must have been called", avm.mSetValueCalled);
        assertEquals(
                "setValue(o,f) must have been called with o==Long(Long.MIN_VALUE)",
                Long.MIN_VALUE,
                avm.mValue);
    }

    /**
     * Tests {@link AbstractValueModel#longValue()}.
     */
    public void testLongValue()
    {
        AVMTestImpl avm = new AVMTestImpl();
        assertFalse("Initially, getValueCalled must be false", avm.mGetValueCalled);
        avm.mValue = (long) 0;
        assertEquals("longValue() must return 0 for value Long(0)", 0, avm.longValue());
        assertTrue("getValue() must have been called", avm.mGetValueCalled);
        avm.mValue = Long.MAX_VALUE;
        assertEquals(
                "longValue() must return Long.MAX_VALUE for value Long(Long.MAX_VALUE)",
                Long.MAX_VALUE,
                avm.longValue());
        avm.mValue = Long.MIN_VALUE;
        assertEquals(
                "longValue() must return Long.MIN_VALUE for value Long(Long.MIN_VALUE)",
                Long.MIN_VALUE,
                avm.longValue());
        avm.mValue = "17";
        assertEquals("longValue() must return 17 for value '17'", 17, avm.longValue());
        avm.mValue = "-1829371801";
        assertEquals("longValue() must return -1829371801 for value '-1829371801'", -1829371801, avm.longValue());
        avm.mValue = "no value";
        try
        {
            avm.longValue();
            fail("longValue() must throw NumberFormatException for value 'no value'");
        }
        catch (NumberFormatException ex)
        {
            // correct
        }
        avm.mValue = null;
        long avmLong= avm.longValue();
        assertTrue("longValue() must return 0 for value null", avmLong==0);
    }

    /**
     * Tests {@link AbstractValueModel#setValue(float)}
     */
    public void testSetValueFloat()
    {
        AVMTestImpl avm = new AVMTestImpl();
        assertFalse("Initially, setValueCalled must be false", avm.mSetValueCalled);
        avm.setValue((float) 0);
        assertTrue("setValue(o,f) must have been called", avm.mSetValueCalled);
        assertEquals("setValue(o,f) must have been called with o==Float(0)", (float) 0, avm.mValue);
        avm.reset();
        avm.setValue(Float.MAX_VALUE);
        assertTrue("setValue(o,f) must have been called", avm.mSetValueCalled);
        assertEquals(
                "setValue(o,f) must have been called with o==Float(Float.MAX_VALUE)",
                Float.MAX_VALUE,
                avm.mValue);
        avm.reset();
        avm.setValue(Float.MIN_VALUE);
        assertTrue("setValue(o,f) must have been called", avm.mSetValueCalled);
        assertEquals(
                "setValue(o,f) must have been called with o==Float(Float.MIN_VALUE)",
                Float.MIN_VALUE,
                avm.mValue);
    }

    /**
     * Tests {@link AbstractValueModel#floatValue()}.
     */
    public void testFloatValue()
    {
        AVMTestImpl avm = new AVMTestImpl();
        assertFalse("Initially, getValueCalled must be false", avm.mGetValueCalled);
        avm.mValue = (float) 0;
        assertEquals("floatValue() must return 0 for value Float(0)", 0, avm.floatValue(), 0);
        assertTrue("getValue() must have been called", avm.mGetValueCalled);
        avm.mValue = Float.MAX_VALUE;
        assertEquals(
                "floatValue() must return Float.MAX_VALUE for value Float(Float.MAX_VALUE)",
                Float.MAX_VALUE,
                avm.floatValue(),
                0);
        avm.mValue = Float.MIN_VALUE;
        assertEquals(
                "floatValue() must return Float.MIN_VALUE for value Float(Float.MIN_VALUE)",
                Float.MIN_VALUE,
                avm.floatValue(),
                0);
        avm.mValue = "17.75";
        assertEquals("floatValue() must return 17.75 for value '17.75'", 17.75, avm.floatValue(), 0);
        avm.mValue = String.valueOf(-5.15e-17);
        assertEquals(
                "floatValue() must return " + String.valueOf(-5.15e-17) + " for value '" + avm.mValue + '\'',
                Float.parseFloat((String) avm.mValue),
                avm.floatValue(),
                0);
        avm.mValue = "no value";
        try
        {
            avm.floatValue();
            fail("floatValue() must throw NumberFormatException for value 'no value'");
        }
        catch (NumberFormatException ex)
        {
            // correct
        }
        avm.mValue = null;
        float avmFloat= avm.floatValue();
        assertTrue("floatValue() must return 0 for value null", avmFloat==0);
    }

    /**
     * Tests {@link AbstractValueModel#setValue(double)}
     */
    public void testSetValueDouble()
    {
        AVMTestImpl avm = new AVMTestImpl();
        assertFalse("Initially, setValueCalled must be false", avm.mSetValueCalled);
        avm.setValue((double) 0);
        assertTrue("setValue(o,f) must have been called", avm.mSetValueCalled);
        assertEquals("setValue(o,f) must have been called with o==Double(0)", (double) 0, avm.mValue);
        avm.reset();
        avm.setValue(Double.MAX_VALUE);
        assertTrue("setValue(o,f) must have been called", avm.mSetValueCalled);
        assertEquals(
                "setValue(o,f) must have been called with o==Double(Double.MAX_VALUE)",
                Double.MAX_VALUE,
                avm.mValue);
        avm.reset();
        avm.setValue(Double.MIN_VALUE);
        assertTrue("setValue(o,f) must have been called", avm.mSetValueCalled);
        assertEquals(
                "setValue(o,f) must have been called with o==Double(Double.MIN_VALUE)",
                Double.MIN_VALUE,
                avm.mValue);
    }

    /**
     * Tests {@link AbstractValueModel#doubleValue()}.
     */
    public void testDoubleValue()
    {
        AVMTestImpl avm = new AVMTestImpl();
        assertFalse("Initially, getValueCalled must be false", avm.mGetValueCalled);
        avm.mValue = (double) 0;
        assertEquals("floatValue() must return 0 for value Double(0)", 0, avm.doubleValue(), 0);
        assertTrue("getValue() must have been called", avm.mGetValueCalled);
        avm.mValue = Double.MAX_VALUE;
        assertEquals(
                "doubleValue() must return Double.MAX_VALUE for value Double(Double.MAX_VALUE)",
                Double.MAX_VALUE,
                avm.doubleValue(),
                0);
        avm.mValue = Double.MIN_VALUE;
        assertEquals(
                "doubleValue() must return Double.MIN_VALUE for value Double(Double.MIN_VALUE)",
                Double.MIN_VALUE,
                avm.doubleValue(),
                0);
        avm.mValue = "17.75";
        assertEquals("doubleValue() must return 17.75 for value '17.75'", 17.75, avm.doubleValue(), 0);
        avm.mValue = String.valueOf(-5.15e-17);
        assertEquals(
                "doubleValue() must return " + String.valueOf(-5.15e-17) + " for value '" + avm.mValue + '\'',
                Double.parseDouble((String) avm.mValue),
                avm.doubleValue(),
                0);
        avm.mValue = "no value";
        try
        {
            avm.doubleValue();
            fail("doubleValue() must throw NumberFormatException for value 'no value'");
        }
        catch (NumberFormatException ex)
        {
            // correct
        }
        avm.mValue = null;
        double avmDouble= avm.doubleValue();
        assertTrue("doubleValue() must return 0 for value null", avmDouble==0);
    }

    /**
     * Tests {@link AbstractValueModel#stringValue()}.
     */
    public void testStringValue()
    {
        AVMTestImpl avm = new AVMTestImpl();
        assertFalse("Initially, getValueCalled must be false", avm.mGetValueCalled);
        avm.mValue = "TestString";
        assertSame("stringValue() must return reference of value", avm.mValue, avm.stringValue());
        assertTrue("getValue() must have been called", avm.mGetValueCalled);
        avm.mValue = 112358;
        assertEquals("stringValue() must return '112358' for Integer(112358)", "112358", avm.stringValue());
        avm.mValue = null;
        avm.stringValue();
    }
}

