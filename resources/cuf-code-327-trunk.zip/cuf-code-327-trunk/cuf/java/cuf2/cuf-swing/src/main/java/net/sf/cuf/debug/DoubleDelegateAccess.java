package net.sf.cuf.debug;

import net.sf.cuf.model.DelegateAccess;


public class DoubleDelegateAccess implements DelegateAccess
{

    private DelegateAccess mDA1;
    private DelegateAccess mDA2;

    public DoubleDelegateAccess( final DelegateAccess pDA1, final DelegateAccess pDA2)
    {
        mDA1 = pDA1;
        mDA2 = pDA2;
    }

    public Object getValue(final Object pValue)
    {
        return mDA2.getValue( mDA1.getValue( pValue));
    }

}
