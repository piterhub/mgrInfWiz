package net.sf.cuf.model.state;

import junit.framework.TestCase;

import net.sf.cuf.model.CallbackTarget;
import net.sf.cuf.model.ValueHolder;

/**
 * tests {@link RegExpState}
 */
public class RegExpStateTest extends TestCase
{

    public void testCreation()
    {
        ValueHolder vh = new ValueHolder();
        RegExpState res = new RegExpState( vh, ".*");
        assertTrue( "state must be initialized", res.isInitialized());
        assertFalse( "state must be disabled for null value", res.isEnabled());
    }

    public void testValues()
    {
        ValueHolder vh = new ValueHolder();
        RegExpState res = new RegExpState( vh, "a|b");
        CallbackTarget callbackTarget = new CallbackTarget();
        res.addChangeListener( callbackTarget);
        assertTrue( "state must be initialized", res.isInitialized());
        assertFalse( "state must be disabled for null value", res.isEnabled());
        assertFalse("listeners must not have been notified", callbackTarget.isStateChangedCalled());
        
        vh.setValue( "a");
        assertTrue( "state must be initialized", res.isInitialized());
        assertTrue( "state must be enabled for matching value", res.isEnabled());
        assertTrue( "listeners must have been notified", callbackTarget.isStateChangedCalled());
        callbackTarget.reset();
        
        vh.setValue( "b");
        assertTrue( "state must be initialized", res.isInitialized());
        assertTrue( "state must be enabled for matching value", res.isEnabled());
        assertFalse( "listeners must not have been notified", callbackTarget.isStateChangedCalled());
        
        vh.setValue( null);
        assertTrue( "state must be initialized", res.isInitialized());
        assertFalse( "state must be disabled for null value", res.isEnabled());
        assertTrue("listeners must have been notified", callbackTarget.isStateChangedCalled());
        callbackTarget.reset();
        
        vh.setValue( "mismatch");
        assertTrue( "state must be initialized", res.isInitialized());
        assertFalse( "state must be disabled for not matching value", res.isEnabled());
        assertFalse( "listeners must not have been notified", callbackTarget.isStateChangedCalled());
    }
}
