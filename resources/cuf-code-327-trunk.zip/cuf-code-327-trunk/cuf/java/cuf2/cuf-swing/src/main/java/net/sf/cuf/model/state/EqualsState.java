package net.sf.cuf.model.state;

import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import net.sf.cuf.model.ValueHolder;
import net.sf.cuf.model.ValueModel;
import net.sf.cuf.state.AbstractState;

/**
 * A ValueState compares the values of two value models or a value model and an object
 * and is enabled when both values are null or the value of the second model is equal
 * to the value of the first model.
 */
public class EqualsState extends AbstractState implements ChangeListener
{
    /** the first value model */
    private ValueModel<?> mTrigger1;

    /** the second value model */
    private ValueModel<?> mTrigger2;

    /**
     * Constructor
     * 
     * @param pTrigger the value model, must not be null
     * @param pReferenceValue the object to compare the trigger's value to, may be null
     */
    public EqualsState(final ValueModel<?> pTrigger, final Object pReferenceValue)
    {
        this( pTrigger, new ValueHolder( pReferenceValue));
    }

    /**
     * Constructor
     * 
     * @param pTrigger1
     *            the first value model, must not be null
     * @param pTrigger2
     *            the second value model, must not be null
     */
    public EqualsState(final ValueModel<?> pTrigger1, final ValueModel<?> pTrigger2)
    {
        if (pTrigger1 == null)
        {
            throw new IllegalArgumentException(
                    "first trigger value model must not be null");
        }
        if (pTrigger2 == null)
        {
            throw new IllegalArgumentException(
                    "second trigger value model must not be null");
        }
        mTrigger1 = pTrigger1;
        mTrigger2 = pTrigger2;
        mIsInitialized = true;
        mTrigger1.addChangeListener(this);
        mTrigger2.addChangeListener(this);
        computeState();
    }
    
    /**
     * {@inheritDoc}
     */
    public void dispose()
    {
        super.dispose();
        if (!mTrigger1.isDisposed())
        {
            mTrigger1.removeChangeListener(this);
        }
        if (!mTrigger2.isDisposed())
        {
            mTrigger2.removeChangeListener(this);
        }
    }

    /**
     * Called when one of the trigger values changes, computes the value of the
     * state.
     * @param pEvent the change event
     */
    public void stateChanged(final ChangeEvent pEvent)
    {
        computeState();
    }

    /**
     * computes the value of the state based on the values of the triggers.
     */
    private void computeState()
    {
        Object value1 = mTrigger1.getValue();
        Object value2 = mTrigger2.getValue();
        //noinspection ObjectEquality
        if (value1==value2)
        {
            internalSetEnabled( true);
        }
        else if (value1==null)
        {
            internalSetEnabled( false);
        }
        else if (value1.equals( value2))
        {
            internalSetEnabled( true);
        }
        else
        {
            internalSetEnabled( false);
        }
    }

    /**
     * sets the enabled value of the state and
     * notifies the listeners if a change occurred
     * @param pEnabled the new state value
     */
    private void internalSetEnabled(final boolean pEnabled)
    {
        if (mIsEnabled!=pEnabled)
        {
            mIsEnabled = pEnabled;
            fireStateChanged();
        }
    }

}
