package net.sf.cuf.model.state;

import net.sf.cuf.state.State;
import net.sf.cuf.state.AbstractState;
import net.sf.cuf.model.ValueModel;

import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

/**
 * A NullState monitors the value of a ValueModel.
 * Whenever the ValueModel holds null, the state is enabled.
 */
public class NullState extends AbstractState implements State, ChangeListener
{
    /** the ValueModel we are responsible for, never null`*/
    private ValueModel<?> mTrigger;

    /**
     * Create a new NullState, the given ValueModel serves as a
     * trigger for this state.
     * @param pTrigger the ValueModel to be used as a trigger for
     * this state, must not be null. If the value of this
     * ValueModel changes to null or vice versa, the listeners of
     * this state are notified.
     * @throws IllegalArgumentException if pTrigger is null
     */
    public NullState(final ValueModel<?> pTrigger)
    {
        super();
        if (pTrigger==null)
        {
            throw new IllegalArgumentException("trigger value model must not be null");
        }
        mTrigger      = pTrigger;
        mIsInitialized= true;
        mIsEnabled    = (mTrigger.getValue() == null);
        mReason       = mTrigger;

        mTrigger.addChangeListener(this);
    }

    /**
     * Callback if our value model changes.
     * @param pEvent not used
     */
    public void stateChanged(final ChangeEvent pEvent)
    {
        boolean valueIsNull= (mTrigger.getValue() == null);
        if (valueIsNull != mIsEnabled)
        {
            mIsEnabled= valueIsNull;
            fireStateChanged();
        }
    }
}
