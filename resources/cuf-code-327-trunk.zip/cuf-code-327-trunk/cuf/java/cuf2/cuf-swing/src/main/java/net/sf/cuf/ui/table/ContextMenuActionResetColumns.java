package net.sf.cuf.ui.table;

import javax.swing.JTable;


/**
 * Context menu action to move all columns visible to their original positions.
 * The widths of the columns are not adjusted so that any changes made by the user or the program will be preserved.
 * If we are operation on a {@link SortingTable} we make all columns visible first.
 *
 * @author  Hendrik W&ouml;rdehoff, sd&amp;m AG
 */
public class ContextMenuActionResetColumns
extends ContextMenuAction
{
    public String getKennung()
    {
        return mAdapter.getContextMenuKennung()+"_RESET";
    }

    /**
     * This action is always enabled since it is too difficult to find out when we really need it.
     * It would also be bad user interface style to enable/disable an action governed by rules the user will not be
     * able to comprehend.
     */
    public boolean isEnabled()
    {
        return true;
    }

    /**
     * Reorder the table columns to the original ordering.
     * If the table returned by {@link ContextMenuAdapter#getTable} is a {@link SortingTable}
     * we make all columns visible first.
     */
    public void performAction()
    {
        JTable table = mAdapter.getTable();
        // make columns visible if this is a SortingTable
        if ( table instanceof SortingTable )
        {
            ((SortingTable)table).setAllColumnsVisible();
        }
        // move view columns to their model positions
        int columnCount = table.getColumnCount();
        for ( int i = 0; i < columnCount; i++ )
        {
            int j = table.convertColumnIndexToView(i);
            // do not try to move columns, which are removed from the model before
            // (in this case convertColumnIndexToView(...) returns "-1")
            if (j >= 0)
            {
                table.moveColumn(j, i);
            }
        }
    }
}