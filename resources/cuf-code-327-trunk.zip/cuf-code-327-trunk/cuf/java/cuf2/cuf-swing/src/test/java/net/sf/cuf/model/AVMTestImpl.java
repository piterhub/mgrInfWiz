package net.sf.cuf.model;

/**
 * Implementation of {@link AbstractValueModel} for test purpose.
 */
public class AVMTestImpl extends AbstractValueModel
{
    /**
     * The value set by {@link #setValue(Object, boolean)} and
     * returned by {@link #getValue()}.
     */
    public Object mValue;

    /**
     * The value of the pIsSetForced parameter of the
     * last call to {@link #setValue(Object, boolean)}.
     */
    public boolean mWasSetForced;

    /**
     * Flag, true if setValue has been called.
     */
    public boolean mSetValueCalled;

    /**
     * Flag, true if getValue has been called.
     */
    public boolean mGetValueCalled;

    /**
     * Resets the stored values.
     */
    public void reset()
    {
        mValue = null;
        mWasSetForced = false;
        mSetValueCalled = false;
        mGetValueCalled = false;
    }

    public boolean isEditable()
    {
        return true;
    }

    /* (non-Javadoc)
    * @see ValueModel#getValue()
    */
    public Object getValue()
    {
        mGetValueCalled = true;
        return mValue;
    }

    /* (non-Javadoc)
     * @see ValueModel#setValue(Object, boolean)
     */
    public void setValue(final Object pValue, final boolean pIsSetForced)
    {
        mValue = pValue;
        mWasSetForced = pIsSetForced;
        mSetValueCalled = true;
    }
}
