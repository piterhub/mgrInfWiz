package net.sf.cuf.ui.table;

import java.util.EventObject;
import javax.swing.JTable;
import javax.swing.table.TableColumn;


/**
 * Event for showing/hiding of table columns.
 *
 * @author  Hendrik W&ouml;rdehoff, sd&amp;m AG
 */
public class ColumnVisibilityChangeEvent
extends EventObject
{
    /** The table to which the shown/hidden column belongs. */
    protected JTable mTable;

    /** The column that was shown/hidden. */
    protected TableColumn mColumn;

    /**
     * Constructor.
     *
     * @param  pSource  event source
     * @param  pTable  table on which the event occurred
     * @param  pColumn  column that was shown/hidden
     */
    public ColumnVisibilityChangeEvent(final Object pSource, final JTable pTable, final TableColumn pColumn)
    {
        super(pSource);
        mTable = pTable;
        mColumn = pColumn;
    }

    /**
     * Get the table to which the shown/hidden column belongs.
     *
     * @return  table object
     */
    public JTable getTable()
    {
        return mTable;
    }

    /**
     * Get the column that was shown/hidden.
     *
     * @return  column object
     */
    public TableColumn getColumn()
    {
        return mColumn;
    }
}