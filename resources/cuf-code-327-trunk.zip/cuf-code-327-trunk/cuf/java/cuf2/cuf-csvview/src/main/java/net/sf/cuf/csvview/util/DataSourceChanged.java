package net.sf.cuf.csvview.util;

import net.sf.cuf.appevent.AppEvent;

/**
 * AppEvent posted when the input of our data changed.
 */
public class DataSourceChanged extends AppEvent
{
    /**
     * Creates a new DataSourceChanged event.
     * @param pSource the source posting the event
     */
    public DataSourceChanged(final Object pSource)
    {
        super(pSource);
    }
}
