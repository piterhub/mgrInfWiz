package net.sf.cuf.csvview.browse;

import net.sf.cuf.xfer.Request;

/**
 * Base interface for all our different load requests.
 */
public interface LoadDataRequest<T> extends Request<T>
{
}
