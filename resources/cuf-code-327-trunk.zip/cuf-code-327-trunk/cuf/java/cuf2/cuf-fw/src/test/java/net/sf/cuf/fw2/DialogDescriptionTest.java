package net.sf.cuf.fw2;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.cuf.fw.Application;
import net.sf.cuf.fw.Dc;

import junit.framework.TestCase;

/**
 * test cases for {@link DialogDescription}
 */
public class DialogDescriptionTest extends TestCase
{
    
    /**
     * tests loading a minimal dialog description
     */
    public void testMinimum()
    {
        Map dialogDescriptions = DialogDescription.loadKnownDialogs( "net/sf/cuf/fw2/dd_minimum.properties");
        assertEquals( 2, dialogDescriptions.size());
        // dialog descriptions must be ordered as in file
        List dialogList = new ArrayList( dialogDescriptions.values());
        DialogDescription dd = (DialogDescription) dialogList.get(0);
        assertNotNull( dd);
        assertEquals( "id1", dd.getDialogId());
        assertEquals( TestDc1.class, dd.getDialogClass());
        assertNull( dd.getDialogIcon());
        assertNull( dd.getDialogName());
        assertNull( dd.getParameters());
        assertNull( dd.getDc());
        dd = (DialogDescription) dialogList.get(1);
        assertNotNull( dd);
        assertEquals( "id2", dd.getDialogId());
        assertEquals( TestDc2.class, dd.getDialogClass());
        assertNull( dd.getDialogIcon());
        assertNull( dd.getDialogName());
        assertNull( dd.getParameters());
        assertNull( dd.getDc());
    }
    
    /**
     * tests loading a default dialog description
     * (with the explicit parameters)
     */
    public void testDefault()
    {
        Map dialogDescriptions = DialogDescription.loadKnownDialogs( "net/sf/cuf/fw2/dd_default.properties");
        assertEquals( 2, dialogDescriptions.size());
        // dialog descriptions must be ordered as in file
        List dialogList = new ArrayList( dialogDescriptions.values());
        DialogDescription dd = (DialogDescription) dialogList.get(0);
        assertNotNull( dd);
        assertEquals( "id1", dd.getDialogId());
        assertEquals( TestDc1.class, dd.getDialogClass());
        assertEquals( "Icon1", dd.getDialogIcon());
        assertEquals( "DialogName1", dd.getDialogName());
        assertNull( dd.getParameters());
        assertNull( dd.getDc());
        dd = (DialogDescription) dialogList.get(1);
        assertNotNull( dd);
        assertEquals( "id2", dd.getDialogId());
        assertEquals( TestDc2.class, dd.getDialogClass());
        assertEquals( "Icon2", dd.getDialogIcon());
        assertEquals( "DialogName2", dd.getDialogName());
        assertNull( dd.getParameters());
        assertNull( dd.getDc());
    }
    
    /**
     * tests loading a dialog description with additional parameters
     */
    public void testParameters()
    {
        Map dialogDescriptions = DialogDescription.loadKnownDialogs( "net/sf/cuf/fw2/dd_parameters.properties");
        assertEquals( 2, dialogDescriptions.size());
        // dialog descriptions must be ordered as in file
        List dialogList = new ArrayList( dialogDescriptions.values());
        DialogDescription dd = (DialogDescription) dialogList.get(0);
        assertNotNull( dd);
        assertEquals( "id1", dd.getDialogId());
        assertEquals( TestDc1.class, dd.getDialogClass());
        assertNull( dd.getDialogIcon());
        assertNull( dd.getDialogName());
        assertEquals( 2, dd.getParameters().size());
        assertEquals( "Value1", dd.getParameters().get("param1"));
        assertEquals( "Value1WithDots", dd.getParameters().get("param.with.dots"));
        assertNull( dd.getDc());
        dd = (DialogDescription) dialogList.get(1);
        assertNotNull( dd);
        assertEquals( "id2", dd.getDialogId());
        assertEquals( TestDc2.class, dd.getDialogClass());
        assertNull( dd.getDialogIcon());
        assertNull( dd.getDialogName());
        assertEquals( 2, dd.getParameters().size());
        assertEquals( "Value2", dd.getParameters().get("param2"));
        assertEquals( "Value2WithDots", dd.getParameters().get("param.with.dots"));
        assertNull( dd.getDc());
    }
    
    /**
     * tests {@link DialogDescription#initDialogs(Map, net.sf.cuf.fw.Application, net.sf.cuf.fw.Dc, Map)}
     */
    public void testInitialization()
    {
        Map dialogDescriptions = DialogDescription.loadKnownDialogs( "net/sf/cuf/fw2/dd_init.properties");
        TestApp app = new TestApp();
        Dc parentDc = new TestDc1();
        Map initArgs = new HashMap();
        initArgs.put( Application.APPLICATION_KEY, "should be replaced");
        initArgs.put( "newParam", "should not be replaced");
        initArgs.put( "param1", "replaces config in some dialogs");
        DialogDescription.initDialogs( dialogDescriptions, app, parentDc, initArgs);
        TestDc1 testDc1 = (TestDc1) ((DialogDescription) dialogDescriptions.get("id1")).getDc();
        assertNotNull( testDc1);
        assertSame( parentDc, testDc1.getParent());
        assertEquals( 3, testDc1.getArgs().size());
        assertSame( app, testDc1.getArgs().get( Application.APPLICATION_KEY));
        assertEquals( "replaces config in some dialogs", testDc1.getArgs().get( "param1"));
        assertEquals( "should not be replaced", testDc1.getArgs().get( "newParam"));
        TestDc1 testDc2 = (TestDc1) ((DialogDescription) dialogDescriptions.get("id2")).getDc();
        assertNotNull( testDc2);
        assertSame( parentDc, testDc2.getParent());
        assertEquals( 4, testDc2.getArgs().size());
        assertSame( app, testDc2.getArgs().get( Application.APPLICATION_KEY));
        assertEquals( "replaces config in some dialogs", testDc2.getArgs().get( "param1"));
        assertEquals( "Param2Value2", testDc2.getArgs().get( "param2"));
        assertEquals( "should not be replaced", testDc2.getArgs().get( "newParam"));
    }
    
}
