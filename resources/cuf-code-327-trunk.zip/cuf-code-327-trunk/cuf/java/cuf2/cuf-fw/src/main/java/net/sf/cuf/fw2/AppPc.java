package net.sf.cuf.fw2;

import net.sf.cuf.appevent.AppEventSupport;
import net.sf.cuf.fw.Pc;

/**
 * A AppPc enhances the basic Pc interface with support for AppEvent's
 * and an enhanced life cycle.
 */
public interface AppPc extends Pc, AppEventSupport, Disposable
{
}
