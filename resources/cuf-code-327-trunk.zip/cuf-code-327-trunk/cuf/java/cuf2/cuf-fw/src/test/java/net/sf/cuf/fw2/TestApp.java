package net.sf.cuf.fw2;

import java.util.Map;
import java.util.Properties;

import net.sf.cuf.fw.Application;

/**
 * a test application that does nothing and provides nothing
 */
public class TestApp implements Application
{

    public Map<String, Object> getAppModel()
    {
        return null;
    }

    public Properties getProperties()
    {
        return null;
    }

    public String getProperty(final String pKey, final String pDefault)
    {
        return null;
    }

    public void setProperty(final String pKey, final String pValue)
    {
    }

    public void doStart(final String[] pArgs)
    {
    }

    public void doStop()
    {
    }

}
