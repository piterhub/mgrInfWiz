package net.sf.cuf.csvviewfx.main;

import net.sf.cuf.xfer.Request;

/**
 * Base interface for all our different load requests.
 */
public interface LoadDataRequest<T> extends Request<T>
{
}
