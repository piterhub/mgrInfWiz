package net.sf.cuf.csvviewfx;

import net.sf.cuf.appevent.AppEvent;

/**
 * AppEvent posted when the data source was changed.
 */
public class DataSourceChanged extends AppEvent
{
    /**
     * Creates a new DataSourceChanged event.
     * @param pSource the source posting the event
     */
    public DataSourceChanged(final Object pSource)
    {
        super(pSource);
    }
}
