package net.sf.cuf.examples.state;

/**
 * AppData contains application wide constants.
 */
public class AppData
{
    // Main
    public static final String XML_UI_NAME       = "statetest.xml";
    public static final String APP_NAME          = "statetest";
    public static final String USER_PROPERTIES   = APP_NAME+"_user.properties";

    // StatePc
    public static final String DEFAULT_WIDTH_KEY = "windowsize.width";
    public static final String DEFAULT_WIDTH     = "600";
    public static final String DEFAULT_HEIGHT_KEY= "windowsize.height";
    public static final String DEFAULT_HEIGHT    = "450";
    public static final String DEFAULT_X_KEY     = "windowsize.x";
    public static final String DEFAULT_X         = "40";
    public static final String DEFAULT_Y_KEY     = "windowsize.y";
    public static final String DEFAULT_Y         = "30";

}
