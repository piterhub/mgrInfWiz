package net.sf.cuf.examples.model;

/**
 * This class holds constants that are used in various parts of the application.
 */
public class AppData
{
    // Main
    public static final String XML_APP_UI_NAME       = "modeltest/modeltest.xml";
    public static final String XML_APP_UC1_NAME      = "modeltest/uc1.xml";
    public static final String XML_APP_UC2_NAME      = "modeltest/uc2.xml";
    public static final String XML_APP_UC3_NAME      = "modeltest/uc3.xml";
    public static final String XML_APP_UC4_NAME      = "modeltest/uc4.xml";
    public static final String XML_APP_MULTI_NAME    = "modeltest/multi.xml";
    public static final String XML_APP_MODAL_NAME    = "modeltest/modal.xml";
    public static final String APP_DIALOG            = "modeltest/appdialog.properties";
    public static final String UC_DIALOGS            = "modeltest/ucdialogs.properties";
    public static final String UC3_DIALOGS           = "modeltest/uc3.properties";
    public static final String APPDC_ID              = "AppDc";
    public static final String APP_NAME              = "modeltest";
    public static final String USER_PROPERTIES       = APP_NAME+"_user.properties";
    public static final String TABLE_DATA            = "TableData";

    // PortalPc
    public static final String DEFAULT_WIDTH_KEY     = "windowsize.width";
    public static final String DEFAULT_WIDTH         = "600";
    public static final String DEFAULT_HEIGHT_KEY    = "windowsize.height";
    public static final String DEFAULT_HEIGHT        = "450";
    public static final String DEFAULT_X_KEY         = "windowsize.x";
    public static final String DEFAULT_X             = "40";
    public static final String DEFAULT_Y_KEY         = "windowsize.y";
    public static final String DEFAULT_Y             = "30";
    public static final String DEFAULT_TABLE_SETTINGS= "tablesettings";
}
