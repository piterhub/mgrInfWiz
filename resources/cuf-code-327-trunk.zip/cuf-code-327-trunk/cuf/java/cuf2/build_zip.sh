#!/bin/sh
# small script to bundle the stuff for the SF download
#

VERSION=2.0.0
RELEASE=CUF-Java-$VERSION-2014-01-02

rm -rf $RELEASE
rm -f $RELEASE.zip
mkdir $RELEASE

# first copy the read me
cat > $RELEASE/README.txt <<ReadMeText
CUF 2.0.0
=========
This is a API breaking release with the following changes:
o changed: switched to Java 7
o changed: switched to Maven build system and delivery
o changed: switch to JDOM 2.0.5, JGoodies Looks 2.5.3, JGoodies Forms 1.7.2
o changed: new package prefix
  + from com.sdm.util.ui.fw/com.sdm.util.ui.fw2 to net.sf.cuf.fw/net.sf.cuf.fw2 for the framework stuff
  + from com.sdm.util to net.sf.cuf for all other stuff
o changed: the Dispatcher class was removed, use the Dispatch interface and 
           the SwingDispatcher or JavaFXDispatcher class instead
o changed: the start() and stop() Methods in Application where renamed to doStart() and 
           doStop() to solve the conflict with the JavaFX Application class
o added: FilteringListModelAdapter including XML Support
o added: JavaFX Support
o fixed: TableLayout2 support now works also with Java7
o fixed: possible NPE in NewTableSorter
o changed: Switch to Intellij 13 (only relevant for CUF core development, not relevant for use)


Usage
=====
Since CUF 2.0.0, CUF is contained in Maven Central, so you can use the simple lines
    <dependency>
        <groupId>net.sf.cuf</groupId>
        <artifactId>cuf-swing</artifactId>
        <version>$VERSION</version>
    </dependency>
in your Maven pom for your CUF Swing Projects and
    <dependency>
        <groupId>net.sf.cuf</groupId>
        <artifactId>cuf-javafx</artifactId>
        <version>$VERSION</version>
    </dependency>
for your CUF JavaFX Projects to get the latest version of CUF.

As an alternative, the $RELEASE.zip file contains most Maven artefacts as
well as some documentation:

cuf-fw-$VERSION.jar                                the CUF framework (both for Swing/JavaFX)
cuf-fw-$VERSION-sources.jar                        the CUF framework sources
cuf-swing-$VERSION.jar                             the CUF Swing support
cuf-swing-$VERSION-sources.jar                     the CUF Swing support sources
cuf-javafx-$VERSION.jar                            the CUF JavaFX support
cuf-javafx-$VERSION-sources.jar                    the CUF JavaFX support sources

cuf-csvview-$VERSION-jar-with-dependencies.jar     the executable Swing CSV sample app
cuf-csvview-$VERSION-sources.jar                   the sources for the Swing CSV sample app
cuf-csvviewfx-$VERSION-app                         the executable JavaFX CSV sample app
cuf-csvviewfx-$VERSION-sources.jar                 the sources for the JavaFX CSV sample app
cuf-swing-examples-$VERSION-sources.jar            the sources of additional CUF Swing examples

cuf-doc                                         some CUF documentation
ReadMeText

# now copy the files
cp cuf-fw/target/cuf-fw-$VERSION.jar $RELEASE
cp cuf-fw/target/cuf-fw-$VERSION-sources.jar $RELEASE
cp cuf-swing/target/cuf-swing-$VERSION.jar $RELEASE
cp cuf-swing/target/cuf-swing-$VERSION-sources.jar $RELEASE
cp cuf-javafx/target/cuf-javafx-$VERSION.jar $RELEASE
cp cuf-javafx/target/cuf-javafx-$VERSION-sources.jar $RELEASE
cp cuf-csvview/target/cuf-csvview-$VERSION-jar-with-dependencies.jar $RELEASE
cp cuf-csvview/target/cuf-csvview-$VERSION-sources.jar $RELEASE
cp -r cuf-csvviewfx/target/jfx/app $RELEASE/cuf-csvviewfx-$VERSION-app
cp cuf-csvviewfx/target/cuf-csvviewfx-$VERSION-sources.jar $RELEASE
cp cuf-swing-examples/target/cuf-swing-examples-$VERSION-sources.jar $RELEASE
cp -r cuf-doc $RELEASE

# and zip it
zip -r $RELEASE.zip $RELEASE

