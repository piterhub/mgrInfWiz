Swing CUF [kuff] Client Utilities und Framework

A (initial) documentation about what CUF is can be found in the doc 
directory, a sample application can be started with calling
"ant" from this directory.

The license of CUF (Common Public License - v 1.0, sd&m AG) is inside 
the doc directory.

Jürgen Zeller, jzeller@jzeller.eu, 2004-11-30
