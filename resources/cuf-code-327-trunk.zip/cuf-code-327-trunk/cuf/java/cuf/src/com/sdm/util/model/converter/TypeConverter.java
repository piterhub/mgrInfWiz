package com.sdm.util.model.converter;

import com.sdm.util.model.ValueModel;

/**
 * A TypeConverter is a ValueModel modelled after the Adapter-Pattern:
 * it monitors a value model (called the subject) and converts the
 * type of the subject's value to its own value type. <br/>
 * A TypeConverter provides also a sync state to check if the
 * subject's value and the value of our users are in sync.
 * @param <OwnT> the type of the own value
 * @param <SubjectT> the type of the subject value
 */
public interface TypeConverter<OwnT, SubjectT> extends ValueModel<OwnT>
{
    /**
     * Return a ValueModel containing a Boolean that shows if the last
     * conversion in setValue() or getValue() was sucessfull.
     * @return a ValueModel holding either Boolean.TRUE or
     *         Boolean.FALSE.
     */
    public ValueModel<Boolean> getSyncState();

    /**
     * Get the sync key for the sync state.
     * @return an key, may be null
     */
    public Object getSyncKey();

    /**
     * Set the sync key for the sync state.
     * @param pKey a key, may be null
     */
    public void setSyncKey(Object pKey);

    /**
     * Return a sync message, usefull when the conversation fails.
     * If no one was set, a default message is returned.
     * @return a sync message, never null
     */
    public String getSyncMessage();

    /**
     * Set the sync message.
     * @param pMessage the sync message, must not be null
     */
    public void setSyncMessage(String pMessage);


    /**
     * Converts from the type that the subject value model provides
     * to the type this value model offers.  This method is used
     * internally during getValue().
     * @param pSubjectValue value in the subject's type
     * @return value in this value model's type
     * @throws ConversionException if we detected an error during the conversion
     */
    public OwnT convertSubjectToOwnValue(SubjectT pSubjectValue) throws ConversionException;

    /**
     * Converts from the type that this value model offers to the type
     * its subject value model. This method is used internally during
     * setValue().
     * @param pOwnValue value in this value model's type
     * @return value in the subject's type
     * @throws ConversionException if we detected an error during the conversion
     */
    public SubjectT convertOwnToSubjectValue(OwnT pOwnValue) throws ConversionException;

}
