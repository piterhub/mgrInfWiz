package com.sdm.util.model.converter;

import com.sdm.util.model.AbstractValueModel;
import com.sdm.util.model.ValueModel;
import com.sdm.util.model.ValueHolder;
import com.sdm.util.model.DelegateAccess;

import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;

/**
 * The AbstractTypeConverter class provides common code for classes providing
 * the TypeConverter inferface. All TypeConverters are ValueModels, and
 * provide their value by converting the original value called the subject.
 * <P>
 * To use as a super class, implement {@link TypeConverter#convertOwnToSubjectValue(Object)}
 * and {@link TypeConverter#convertSubjectToOwnValue(Object)}.
 * Return the correct value or throw a {@link ConversionException}
 * with an optional alternative value.
 * If you throw the exception, the sync state will be disabled, otherwise enabled.
 * If you provide an alternative value in the exception, that value is used as a result.
 * <P>
 * By default, the converter will throw an exception if the conversion fails
 * and no alternative value is provided by the converter. You can modify that behaviour
 * by setting propagateFailedConversions to false. In that case, a failed conversion
 * will not throw an exception and, in case of a set, the subject value will not be modified,
 * and in case of a get, the own value will be null.
 * @param <OwnT> the type of the own value
 * @param <SubjectT> the type of the subject value
 */
public abstract class AbstractTypeConverter<OwnT, SubjectT> extends AbstractValueModel<OwnT>
        implements TypeConverter<OwnT, SubjectT>, ChangeListener, DelegateAccess
{
    /** Our subject, never null. */
    private ValueModel<SubjectT> mSubject;
    /** Holds Boolean.TRUE if the last conversion was successfull. */
    private ValueHolder<Boolean> mInSync;
    /** our sync key, may be null */
    private Object               mSyncKey;
    /** our sync message, may be null */
    private String               mSyncMessage;
    /** true if we propagate a failed conversion as IllegalStateExceptions */
    private boolean              mPropagateFailedConversions;

    /**
     * Create a new converter with the handed subject.
     * @param pSubject the ValueModel holding the original value, must not be null
     * @throws IllegalArgumentException if pSubject is null
     */
    protected AbstractTypeConverter(final ValueModel<SubjectT> pSubject)
    {
        this(pSubject, true);
    }

    /**
     * Create a new converter with the handed subject and remember how conversion
     * failures are propagated.
     * @param pSubject the ValueModel holding the original value, must not be null
     * @param pPropagateFailedConversions if true, we propagate failed conversions as IllegalStateExceptions
     * @throws IllegalArgumentException if pSubject is null
     */
    protected AbstractTypeConverter(final ValueModel<SubjectT> pSubject, final boolean pPropagateFailedConversions)
    {
        super();
        if (pSubject==null)
        {
            throw new IllegalArgumentException("subject must not be null");
        }

        mSubject                   = pSubject;
        mPropagateFailedConversions= pPropagateFailedConversions;
        setInSetValue(false, false);
        mInSync                    = new ValueHolder<Boolean>(Boolean.TRUE);
        mSubject.addChangeListener(this);
    }
    
    /**
     * Sets the flag if we should propagate a failed conversion
     * @param pPropagateFailedConversions if true, we propagate failed conversions as IllegalStateExceptions
     */
    public void setPropagateFailedConversions(
            final boolean pPropagateFailedConversions)
    {
        mPropagateFailedConversions = pPropagateFailedConversions;
    }
    
    /**
     * @return true if we propagate failed conversions
     */
    public boolean getPropagateFailedConversions()
    {
        return mPropagateFailedConversions;
    }

    /**
     * Returns always true
     * @return true
     */
    public boolean isEditable()
    {
        return true;
    }

    /**
     * Return our subject ValueModel.
     * @return the subject, never null
     */
    public ValueModel<SubjectT> getSubject()
    {
        return mSubject;
    }

    /**
     * Cleanup all resources: disconnect from any input sources (like
     * other ValueModel's ...), and remove all listeners.
     */
    public void dispose()
    {
        super.dispose();
        if (!mSubject.isDisposed())
        {
            mSubject.removeChangeListener(this);
        }
        mInSync.dispose();
    }

    /**
     * Set a new value, this will convert the handed value to
     * the subject's value.
     * @param pValue the new value (null is o.k.)
     * @param pIsSetForced true if a forced setValue should be done
     * @throws UnsupportedOperationException if this ValueModel is not mutable
     * @throws IllegalStateException if we can't convert the value
     */
    public void setValue(final OwnT pValue, final boolean pIsSetForced)
    {
        checkDisposed();
        setInSetValue(true, pIsSetForced);
        try
        {
            SubjectT convertedValue;
            try
            {
                convertedValue= convertOwnToSubjectValue(pValue);
                mInSync.setValue(Boolean.TRUE);
            }
            catch (ConversionException ex)
            {
                // conversion failed, we are out-of-sync
                mInSync.setValue(Boolean.FALSE);
                if (ex.hasConversionValue())
                {
                    convertedValue= (SubjectT)ex.getConversionValue();
                }
                else
                {
                    if (mPropagateFailedConversions)
                    {
                        // we can't convert and have no alternative value
                        IllegalStateException ise= new IllegalStateException(ex.getMessage());
                        ise.initCause(ex.getCause());
                        throw ise;
                    }
                    else
                    {
                        // silently ignore the setValue
                        return;
                    }
                }
            }
            mSubject.setValue(convertedValue);
            fireStateChanged();
        }
        finally
        {
            setInSetValue(false, false);
        }
    }

    /**
     * Get the current value, during a callback this is the new value.
     * @return null or the value object
     * @throws IllegalStateException if we can't convert the value
     */
    public OwnT getValue()
    {
        // convert value
        SubjectT subjectValue  = mSubject.getValue();
        return getValue(subjectValue, mInSync);
    }

    /**
     * Transform the handed value to a new value.
     * This should not change the current value or trigger any updates.
     * @param pValue the value we should assume as our value
     * @return null or the transformed/mapped value object
     */
    public Object getValue(final Object pValue)
    {
        checkDisposed();
        SubjectT value= (SubjectT)pValue;
        if (mSubject instanceof DelegateAccess)
        {
            value= (SubjectT)((DelegateAccess)mSubject).getValue(pValue);
        }
        return getValue(value, null);
    }

    /**
     * Common code of the getValue() calls.
     * @param pSubjectValue our subjects value
     * @param pInSync null or the sync value model
     * @return the converted value
     */
    private OwnT getValue(final SubjectT pSubjectValue, final ValueModel<Boolean> pInSync)
    {
        OwnT convertedValue;
        try
        {
            convertedValue= convertSubjectToOwnValue(pSubjectValue);
            if (pInSync!=null)
                pInSync.setValue(Boolean.TRUE);
        }
        catch (ConversionException ex)
        {
            // conversion failed, we are out-of-sync
            if (pInSync!=null)
                pInSync.setValue(Boolean.FALSE);
            if (ex.hasConversionValue())
            {
                convertedValue= (OwnT)ex.getConversionValue();
            }
            else
            {
                if (mPropagateFailedConversions)
                {
                    // we can't convert and have no alternative value
                    IllegalStateException ise= new IllegalStateException(ex.getMessage());
                    ise.initCause(ex.getCause());
                    throw ise;
                }
                else
                {
                    // silently ignore the getValue and return null
                    return null;
                }
            }
        }
        return convertedValue;
    }

    /**
     * Return the value of the subject without any conversion.
     * @return the value of the subject
     */    
    protected Object getSubjectValue()
    {
        checkDisposed();
        return mSubject.getValue();
    }
    
    /**
     * Return a ValueModel containing a Boolean that shows if the last
     * conversion in setValue() or getValue() was sucessfull.
     * @return a ValueModel holding either Boolean.TRUE or Boolean.FALSE.
     */
    public ValueModel<Boolean> getSyncState()
    {
        checkDisposed();
        return mInSync;
    }

    /**
     * Get the sync key for the sync state.
     * @return an key, may be null
     */
    public Object getSyncKey()
    {
        return mSyncKey;
    }

    /**
     * Set the sync key for the sync state.
     * @param pKey a key, may be null
     */
    public void setSyncKey(final Object pKey)
    {
        mSyncKey= pKey;
    }

    /**
     * Return a sync message, usefull when the conversation fails.
     * If no one was set, a default message is returned.
     *
     * @return a sync message, never null
     */
    public String getSyncMessage()
    {
        if (mSyncMessage==null)
            return "Umwandlung fehlgeschlagen"; // TODO: I18N
        else
            return mSyncMessage;
    }

    /**
     * Set the sync message.
     *
     * @param pMessage the sync message, must not be null
     */
    public void setSyncMessage(final String pMessage)
    {
        if (pMessage==null) throw new IllegalArgumentException("Sync message must not be null");
        mSyncMessage= pMessage;
    }

    /**
     * Invoked when our subject changed. We try to convert the subject's value
     * and change ourself
     * @param pEvent  a ChangeEvent object
     */
    public void stateChanged(final ChangeEvent pEvent)
    {
        checkDisposed();
        if (isInSetValue())
        {
            return;
        }

        // get and convert value to check if we should propagate
        try
        {
            convertSubjectToOwnValue(mSubject.getValue());
        }
        catch (ConversionException ex)
        {
            // conversion failed, we are out-of-sync
            mInSync.setValue(Boolean.FALSE);

            if (!ex.hasConversionValue() && !mPropagateFailedConversions)
            {
                // ignore the change
                return;
            }
        }

        // propagate the change
        fireStateChanged();
    }
}
