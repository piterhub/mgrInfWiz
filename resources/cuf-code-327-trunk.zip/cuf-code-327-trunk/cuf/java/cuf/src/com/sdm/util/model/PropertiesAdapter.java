package com.sdm.util.model;

import java.util.Properties;

/**
 * PropertiesAdapter is a ValueModel that uses a Properties object
 * as its backing store.
 */
public class PropertiesAdapter extends AbstractValueModel<Object> implements ValueModel<Object>
{
    /** the properties object we take our value from, never null */
    private Properties mProperties;
    /** the key for the properties object, never null */
    private String     mKey;
    /** the default value, may be null */
    private String     mDefaultValue;


    /**
     * Create a new ValueModel with a properties object as its backing store.
     * @param pProperties   the properties object we read/write our object from/to,
     *                      must not be null
     * @param pKey          the key in pProperites, must not be null
     * @param pDefaultValue the default value, may be null
     * @throws IllegalArgumentException if pProperties or pKey is null
     */
    public PropertiesAdapter(final Properties pProperties,
                             final String     pKey,
                             final String     pDefaultValue)
    {
        super();
        if (pProperties==null)
            throw new IllegalArgumentException("properties must not be null");
        if (pKey==null)
            throw new IllegalArgumentException("properties key must not be null");

        mProperties  = pProperties;
        mKey         = pKey;
        mDefaultValue= pDefaultValue;
        setInSetValue(false, false);
    }

    /**
     * Returns always true
     * @return true
     */
    public boolean isEditable()
    {
        return true;
    }

    /**
     * Set a new value, this will fire a ChangeEvent if the new value
     * is different from the old value.
     * We store pValue.toString() in our properties object.
     * @param pValue the new value (null is o.k.)
     * @param pIsSetForced true if a forced setValue should be done
     */
    public void setValue(final Object pValue, final boolean pIsSetForced)
    {
        checkDisposed();

        // optimize only if there is no forced update
        if (!pIsSetForced)
        {
            String oldValue= mProperties.getProperty(mKey);
            if ((oldValue==null && pValue== null) ||
                (oldValue != null ? oldValue.equals(pValue) : pValue.equals(oldValue)))
            {
                // nothing changed
                return;
            }
        }

        setInSetValue(true, pIsSetForced);
        try
        {
            mProperties.setProperty(mKey, pValue==null?null:pValue.toString());
            fireStateChanged();
        }
        finally
        {
            setInSetValue(false, false);
        }

    }

    /**
     * Get the current value, during a callback this is the new value.
     * @return null or the value of the properties object as a String
     */
    public String getValue()
    {
        checkDisposed();
        return mProperties.getProperty(mKey, mDefaultValue);
    }
}
