package com.sdm.util.model;

/**
 * A simple default implementation for the index provider.
 */
public class FixedIndexProvider implements IndexProvider
{
    /** our index */
    private int mIndex;

    /**
     * Create a new FixedIndexProvider with the provided index.
     * @param pIndex the index we shall provide
     */
    public FixedIndexProvider(final int pIndex)
    {
        mIndex = pIndex;
    }

    /**
     * Return the desired index.
     * @return the index provided in the constructor
     */
    public int getIndex()
    {
        return mIndex;
    }
}
