package com.sdm.cufexamples.model.portal;

import com.sdm.util.ui.fw2.AbstractDialogDc;
import com.sdm.util.ui.fw2.DialogDc;
import com.sdm.util.ui.fw2.CloseDialogEvent;
import com.sdm.util.ui.builder.SwingXMLBuilder;
import com.sdm.util.ui.fw.Dc;

import java.util.Map;

/**
 * This dialog is an example of a simple modal about dialog.
 */
public class AboutDc extends AbstractDialogDc implements DialogDc, SwingXMLBuilder.Backlink
{
    /** the builder that created us, never null after init */
    private SwingXMLBuilder mBuilder;
    /** our presentation peer, never null after init */
    private AboutPc         mPc;

    public void setSwingXMLBuilder(final SwingXMLBuilder pBuilder)
    {
        mBuilder= pBuilder;
    }

    public void init(final Dc pParent, final Map<String, Object> pArgs)
    {
        super.init(pParent, pArgs);

        mPc= (AboutPc)mBuilder.getNonVisualObject("AboutPc");
        mPc.init(this, pArgs);
    }

    public void doActivate(final Map<String, Object> pArgs)
    {
        mPc.show();
    }

    public void doPassivate(final Map<String, Object> pArgs)
    {
        mPc.hide();
    }

    public void dispose(final Map<String, Object> pArgs)
    {
        mPc.dispose(pArgs);
    }

    public Object getVisualPresentation()
    {
        return mPc.getVisualPresentation();
    }

    /**
     * Close the dialog via a CloseDialogEvent(), this
     * will trigger a call to hide().
     */
    public void close()
    {
        CloseDialogEvent close= new CloseDialogEvent(this, this);
        postAppEvent(close);
    }
}
