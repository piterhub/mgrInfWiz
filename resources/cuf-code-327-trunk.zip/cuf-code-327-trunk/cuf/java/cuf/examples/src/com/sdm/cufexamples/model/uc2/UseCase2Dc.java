package com.sdm.cufexamples.model.uc2;

import com.sdm.util.ui.fw2.DialogDc;
import com.sdm.util.ui.fw2.AbstractDialogDc;
import com.sdm.util.ui.builder.SwingXMLBuilder;
import com.sdm.util.ui.fw.Dc;
import com.sdm.util.state.State;
import com.sdm.cufexamples.model.AppData;

import java.util.Map;
import java.util.HashMap;
import java.io.InputStream;

/**
 * UseCase2Dc is the dialog component of a very simple dialog.
 * It demonstrates the "can passivate" mechanism.
 */
public class UseCase2Dc extends AbstractDialogDc implements DialogDc
{
    // our presentation peer
    private UseCase2Pc mPc;

    // the builder that created our Pc and UI
    private SwingXMLBuilder mBuilder;

    /**
     * This method is called by the parent dialog controller during
     * the initialisation phase of an application.<br/>
     *
     * @param pParent our parent must implement AppEventSupport
     * @param pArgs variable argument list modeled as a key/value map, never null.
     */
    public void init(final Dc pParent, final Map<String, ? super Object> pArgs)
    {
        super.init(pParent, pArgs);

        // load our Pc and its UI
        InputStream in= Thread.currentThread().getContextClassLoader().getResourceAsStream(AppData.XML_APP_UC2_NAME);
        Map         nonVisual= new HashMap();
        nonVisual.put("UseCase2Dc", this);
        mBuilder= SwingXMLBuilder.create(in, nonVisual);
        mPc= (UseCase2Pc)mBuilder.getNonVisualObject("UseCase2Pc");
        mPc.init(this, pArgs);
    }

    /**
     * Called from the dialog coordinator to tell the dialog to switch
     * to the active state.
     * @param pArgs arguments, key is a String, value is any suitable objekt for the key
     */
    public void doActivate(final Map<String, ? super Object> pArgs)
    {
        System.out.println("UseCase2Dc.doActivate");
    }

    /**
     * Test to check if a dialog in the active state can be moved
     * to the passive state, we ask our presentation component if
     * it is o.k. to passivate.
     * @return true if the dialog can be passivated
     */
    public boolean canPassivate()
    {
        State passivateState= (State) mBuilder.getNonVisualObject("PassivateState");
        boolean canPassivate= passivateState.isEnabled();

        System.out.println("UseCase2Dc.canPassivate= "+canPassivate);

        return canPassivate;
    }

    /**
     * Called from the dialog coordinator to tell the dialog to switch
     * to the passive state.
     * @param pArgs arguments, key is a String, value is any suitable objekt for the key
     */
    public void doPassivate(final Map<String, ? super Object> pArgs)
    {
        System.out.println("UseCase2Dc.doPassivate");
    }

    /**
     * Called from the dialog coordinator to tell the dialog to cleanup all
     * resources. We only call dispose of our Pc.
     * @param pArgs arguments, key is a String, value is any suitable objekt for the key
     */
    public void dispose(final Map<String, ? super Object> pArgs)
    {
        mPc.dispose(pArgs);
    }

    /**
     * Called from the dialog coordinater in the initialized, active or passive
     * state to get the visual representation for this dialog.
     * @return an object that represents the visual representation of this dialog
     */
    public Object getVisualPresentation()
    {
        return mPc.getVisualPresentation();
    }
}
