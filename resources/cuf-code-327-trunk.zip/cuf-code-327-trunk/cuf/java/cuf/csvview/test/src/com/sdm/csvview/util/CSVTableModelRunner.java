package com.sdm.csvview.util;

import java.io.InputStream;

/**
 * A test driver for CSVTableModel.
 */
@SuppressWarnings({"UseOfSystemOutOrSystemErr", "CallToSystemExit", "StringContatenationInLoop"})
public class CSVTableModelRunner
{
    /**
     * We need just main.
     */
    private CSVTableModelRunner()
    {
    }

    /**
     * Small test driver.
     * @param pArgs not used
     * @throws Exception on problems
     */
    public static void main(final String[] pArgs) throws Exception
    {
        long          start, stop;
        String        fileName, separator;
        InputStream   input;

        start= System.currentTimeMillis();
        fileName = "Test.csv";
        input    = ClassLoader.getSystemResourceAsStream(fileName);
        separator= ";";
        FilteredTableModel tableModel= null;
        try
        {
            tableModel = new CSVTableModel(input, true, separator, "Cp1252");
        }
        catch (Exception e)
        {
            e.printStackTrace(System.out);
            System.exit(-1);
        }
        stop= System.currentTimeMillis();

        System.out.println("tablemodel: "+tableModel.getRowCount()+" rows");
        System.out.println("            "+tableModel.getColumnCount()+" columns");
        System.out.println("            reading took "+(stop-start)+" msecs");

        String  filter  = "a";
        start= System.currentTimeMillis();
        boolean filtered= tableModel.filter(filter);
        stop= System.currentTimeMillis();
        System.out.println("filtering with "+filter+" returned "+filtered+", took "+(stop-start)+" msecs");
        System.out.println("tablemodel: "+tableModel.getRowCount()+" rows");
        System.out.println("            "+tableModel.getColumnCount()+" columns");
        for (int i = 0; i < tableModel.getRowCount(); i++)
        {
            System.out.println("row= "+ i+", column[1]="+tableModel.getValueAt(i, 1));
        }
    }
}
