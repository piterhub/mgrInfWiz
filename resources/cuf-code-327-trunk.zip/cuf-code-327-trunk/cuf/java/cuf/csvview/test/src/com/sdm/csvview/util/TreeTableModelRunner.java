package com.sdm.csvview.util;

import javax.swing.table.TableModel;
import java.io.File;

/**
 * A test driver for TreeTableModel.
 */
@SuppressWarnings({"UseOfSystemOutOrSystemErr", "CallToSystemExit", "StringContatenationInLoop"})
public class TreeTableModelRunner
{
    /**
     * We need just main.
     */
    private TreeTableModelRunner()
    {
    }

    /**
     * Small test driver.
     * @param pArgs not used
     */
    public static void main(final String[] pArgs)
    {
        File file= new File("c:\\WINDOWS");

        TableModel model= new TreeTableModel(file);
        int        rows   = model.getRowCount();
        int        columns= model.getColumnCount();
        System.out.println("model data (" + rows+" rows, "+columns+" columns)");
        for (int column= 0; column < columns; column++)
        {
            System.out.print(model.getColumnName(column));
            if (column<columns-1)
                System.out.print(",");
        }
        System.out.println();
        for (int row= 0; row< rows; row++)
        {
            for (int column= 0; column < model.getColumnCount(); column++)
            {
                System.out.print(model.getValueAt(row, column));
                if (column<columns-1)
                    System.out.print(",");
            }
            System.out.println();
        }
    }
}
