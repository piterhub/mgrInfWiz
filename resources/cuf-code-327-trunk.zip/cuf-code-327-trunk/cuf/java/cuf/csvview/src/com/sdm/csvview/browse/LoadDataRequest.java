package com.sdm.csvview.browse;

import com.sdm.util.xfer.Request;

/**
 * Base interface for all our different load requests.
 */
public interface LoadDataRequest extends Request
{
}
