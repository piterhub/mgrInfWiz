package com.sdm.util.model;

import java.util.Map;
import java.util.Collection;
import java.util.HashMap;
import java.util.Set;
import java.util.HashSet;
import java.util.Arrays;
import java.util.ArrayList;

/**
 * Object containing data used for test purposes.
 * DataObjectA handles map-like access with a fixed number of attributes.
 */
public class DataObjectA implements Map
{
    private        Map mBackingMap;
    private static Set ATTRIBUTES= new HashSet(Arrays.asList("name", "born", "father", "mother", "children"));

    public DataObjectA()
    {
        mBackingMap= new HashMap(ATTRIBUTES.size());
        for (final Object ATTRIBUTE : ATTRIBUTES)
        {
            String attribute = (String) ATTRIBUTE;
            mBackingMap.put(attribute, null);
        }
        mBackingMap.put("children", new ArrayList());
    }

     public int size()
    {
        return mBackingMap.size();
    }

    public void clear()
    {
        mBackingMap.clear();
    }

    public boolean isEmpty()
    {
        return mBackingMap.isEmpty();
    }

    public boolean containsKey(final Object key)
    {
        return mBackingMap.containsKey(key);
    }

    public boolean containsValue(final Object value)
    {
        return mBackingMap.containsValue(value);
    }

    public Collection values()
    {
        return mBackingMap.values();
    }

    public void putAll(final Map t)
    {
        mBackingMap.putAll(t);
    }

    public Set entrySet()
    {
        return mBackingMap.entrySet();
    }

    public Set keySet()
    {
        return mBackingMap.keySet();
    }

    public Object get(final Object key)
    {
        if (!ATTRIBUTES.contains(key))
        {
            throw new IllegalArgumentException(key+" is not a valid key");
        }
        return mBackingMap.get(key);
    }

    public Object remove(final Object key)
    {
        throw new UnsupportedOperationException("can't remove key "+key);
    }

    public Object put(final Object key, final Object value)
    {
        if (!ATTRIBUTES.contains(key))
        {
            throw new IllegalArgumentException(key+" is not a valid key");
        }
        return mBackingMap.put(key, value);
    }
}
