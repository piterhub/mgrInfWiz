package com.sdm.util.model;

import java.util.Date;
import java.util.List;

import junit.framework.TestCase;

/**
 * Tests {@link AspectAdapter}.
 * TODO This test is not complete.
 */
public class AspectAdapterTest extends TestCase
{
    /**
     * Tests the creation using {@link AspectAdapter#AspectAdapter(ValueModel, String)}
     */
    public void testAspectAdapterCreationValueModelString()
    {
        AVMTestImpl avm = new AVMTestImpl();
        AspectAdapter aspectAdapter;
        avm.mValue = new TestDataObject();
        aspectAdapter = new AspectAdapter(avm, "string");
        avm.mValue = null;
        try
        {
            aspectAdapter = new AspectAdapter(null, "string");
            fail("AspectAdapter(null,s) must throw an IllegalArgumentException");
        }
        catch (IllegalArgumentException ex)
        {
            // correct
        }
        try
        {
            aspectAdapter = new AspectAdapter(avm, null);
            fail("AspectAdapter(vm,null) must throw an IllegalArgumentException");
        }
        catch (IllegalArgumentException ex)
        {
            // correct
        }
    }

    /**
     * Tests the creation using {@link AspectAdapter#AspectAdapter(ValueModel, Class, String)}
     */
    public void testAspectAdapterCreationValueModelClassString()
    {
        AVMTestImpl avm = new AVMTestImpl();
        AspectAdapter aspectAdapter;
        aspectAdapter = new AspectAdapter(avm, TestDataObject.class, "string");
        try
        {
            aspectAdapter = new AspectAdapter(null, TestDataObject.class, "string");
            fail("AspectAdapter(null,cl,s) must throw an IllegalArgumentException");
        }
        catch (IllegalArgumentException ex)
        {
            // correct
        }
        try
        {
            aspectAdapter = new AspectAdapter(avm, TestDataObject.class, null);
            fail("AspectAdapter(vm,cl,null) must throw an IllegalArgumentException");
        }
        catch (IllegalArgumentException ex)
        {
            // correct
        }
        try
        {
            aspectAdapter = new AspectAdapter(avm, TestDataObject.class, "no method");
            fail("AspectAdapter(vm,cl,illegal method) must throw an IllegalArgumentException");
        }
        catch (IllegalArgumentException ex)
        {
            // correct
        }
        aspectAdapter = new AspectAdapter(avm, null, "no method");
    }

    /**
     * Tests creation using {@link AspectAdapter#AspectAdapter(Object, String)}
     */
    public void testAspectAdapterCreationObjectString()
    {
        AspectAdapter aspectAdapter;
        try
        {
            aspectAdapter = new AspectAdapter(null, "string");
            fail("AspectAdapter(null,s) must throw an IllegalArgumentException");
        }
        catch (IllegalArgumentException ex)
        {
            // correct
        }
        TestDataObject testDataObject = new TestDataObject();
        aspectAdapter = new AspectAdapter(testDataObject, "string");
        try
        {
            aspectAdapter = new AspectAdapter(testDataObject, "no method");
            fail("AspectAdapter(obj,illegal method) must throw an IllegalArgumentException");
        }
        catch (IllegalArgumentException ex)
        {
            // correct
        }
    }

    /**
     * Tests various access strategies.
     */
    public void testAspectAccessAdapter()
    {
        // setup something complicated
        DataObjectA grandpa1= new DataObjectA();
        grandpa1.put("name", "grandpa1");
        grandpa1.put("born", new Date(1912, 1, 4));
        DataObjectA grandma1= new DataObjectA();
        grandma1.put("name", "grandma1");
        grandma1.put("born", new Date(1914, 4, 1));
        DataObjectB grandpa2= new DataObjectB();
        grandpa2.setName("grandpa2");
        grandpa2.setBorn(new Date(1924, 2, 2));
        DataObjectB grandma2= new DataObjectB();
        grandma2.setName("grandma2");
        grandma2.setBorn(new Date(1925, 1, 1));
        DataObjectA pa= new DataObjectA();
        pa.put("name", "pa");
        pa.put("born", new Date(1942, 3, 3 ));
        pa.put("father", grandpa1);
        pa.put("mother", grandma1);
        ((List)grandpa1.get("children")).add(pa);
        ((List)grandma1.get("children")).add(pa);
        DataObjectB ma= new DataObjectB();
        ma.setName("ma");
        ma.setBorn(new Date(1948, 2, 2));
        ma.setFather(grandpa2);
        ma.setMother(grandma2);
        grandpa2.getChildren().add(ma);
        grandma2.getChildren().add(ma);
        DataObjectA meA= new DataObjectA();
        meA.put("name", "meA");
        meA.put("born", new Date(1966, 3, 2 ));
        meA.put("father", pa);
        meA.put("mother", ma);
        ((List)pa.get("children")).add(meA);
        ma.getChildren().add(meA);
        DataObjectB meB= new DataObjectB();
        meB.setName("meB");
        meB.setBorn(new Date(1966, 3, 2 ));
        meB.setMother(ma);

        // tests MapAccessAdapter and MixedAccessAdapter
        ValueHolder myHolderA= new ValueHolder(meA);
        AspectAdapter aspect1= new AspectAdapter(myHolderA, "name");
        AspectAdapter aspect2= new AspectAdapter(myHolderA, "father.name");
        AspectAdapter aspect3= new AspectAdapter(myHolderA, "mother.name");
        AspectAdapter aspect4= new AspectAdapter(myHolderA, "father.father.name");
        AspectAdapter aspect5= new AspectAdapter(myHolderA, "father.mother.name");
        AspectAdapter aspect6= new AspectAdapter(myHolderA, "mother.father.name");
        AspectAdapter aspect7= new AspectAdapter(myHolderA, null, new MixedAccessAdapter("mother.father.name"), "mother.father.name");
        AspectAdapter aspect8= new AspectAdapter(myHolderA, "mother.mother.name");
        AspectAdapter aspect9= new AspectAdapter(myHolderA, null, new MixedAccessAdapter("mother.mother.name"), "mother.mother.name");
        assertTrue(aspect1.getValue().equals("meA"));
        assertTrue(aspect2.getValue().equals("pa"));
        System.out.println("aspect3 = " + aspect3.getValue());
        assertTrue(aspect4.getValue().equals("grandpa1"));
        assertTrue(aspect5.getValue().equals("grandma1"));
        System.out.println("aspect6 = " + aspect6.getValue());
        assertTrue(aspect7.getValue().equals("grandpa2"));
        System.out.println("aspect8 = " + aspect8.getValue());
        assertTrue(aspect9.getValue().equals("grandma2"));

        // tests MethodAccessAdapter
        ValueHolder myHolderB= new ValueHolder(meB);
        AspectAdapter aspect10= new AspectAdapter(myHolderB, "name");
        AspectAdapter aspect11= new AspectAdapter(myHolderB, "mother.name");
        AspectAdapter aspect12= new AspectAdapter(myHolderB, "mother.father.name");
        AspectAdapter aspect13= new AspectAdapter(myHolderB, "mother.mother.name");
        assertTrue(aspect10.getValue().equals("meB"));
        assertTrue(aspect11.getValue().equals("ma"));
        assertTrue(aspect12.getValue().equals("grandpa2"));
        assertTrue(aspect13.getValue().equals("grandma2"));
    }

    /**
     * Tests {@link AspectAdapter#setValue(Object, boolean)}.
     */
    public void testSetValue()
    {
        TestDataObject tdo = new TestDataObject();
        String testString = "test";
        assertNull("Initially, string must be null", tdo.getString());
        AspectAdapter aspectAdapter = new AspectAdapter(tdo, "string");
        aspectAdapter.setValue(testString, false);
        assertSame("Data object must have same reference to string", testString, tdo.getString());
        aspectAdapter.setValue(null, false);
        assertSame("Data object must have null reference in string", null, tdo.getString());
        AspectAdapter exceptionAspectAdapter = new AspectAdapter(tdo, "WithException");
        try
        {
            exceptionAspectAdapter.setValue("test", false);
            fail("InvocationTargetException must be mapped to an IllegalArgumentException");
        }
        catch (IllegalArgumentException ex)
        {
            assertSame("Cause for the IllegalArgumentException must be the exception thrown by the setter", TestDataObject.EXCEPTION, ex.getCause());
            // correct
        }
        AspectAdapter runtimeExceptionAspectAdapter = new AspectAdapter(tdo, "WithRuntimeException");
        try
        {
            runtimeExceptionAspectAdapter.setValue("test", false);
            fail("RuntimeException must be passed through.");
        }
        catch (RuntimeException ex)
        {
            assertSame("The exception must be the exception thrown by the setter", TestDataObject.RUNTIME_EXCEPTION, ex.getCause());
            // correct
        }
        try
        {
            aspectAdapter.setValue(0, false);
            fail("IllegalArgumentException must be mapped to an IllegalArgumentException");
        }
        catch (IllegalArgumentException ex)
        {
            // correct
        }
    }
    
    /**
     * tests the correct usage of the access adapter
     */
    public void testAccessAdapter()
    {
        TestDataObject testDataObject = new TestDataObject();
        ValueHolder vh = new ValueHolder( testDataObject);
        AspectAdapter stringAdapter = new AspectAdapter( vh, "string");
        TestAccessAdapter testAccessAdapter = new TestAccessAdapter();
        stringAdapter.setAccessAdapter( testAccessAdapter);
        
        String aspectValue = "StringValue";
        testAccessAdapter.setEditable( false);
        testAccessAdapter.setResultOnGetValue( aspectValue);
        testAccessAdapter.reset();
        
        assertFalse( "adapter must report to be not editable", stringAdapter.isEditable());
        assertTrue( "isEditable must have been called", testAccessAdapter.isEditableHasBeenCalled());
        assertFalse( "setValue must not have been called", testAccessAdapter.isSetValueHasBeenCalled());
        
        testAccessAdapter.setEditable( true);
        testAccessAdapter.reset();
        assertTrue( "adapter must report to be editable", stringAdapter.isEditable());
        assertTrue( "isEditable must have been called", testAccessAdapter.isEditableHasBeenCalled());
        assertFalse( "setValue must not have been called", testAccessAdapter.isSetValueHasBeenCalled());
        
        testAccessAdapter.reset();
        assertSame( "adapter must return the correct value", aspectValue, stringAdapter.getValue());
        assertTrue( "getValue must have been called", testAccessAdapter.isGetValueHasBeenCalled());
        assertSame( "getValue must have been called with correct parameter", testDataObject, testAccessAdapter.getLastGetValueSourceParameter());
        assertFalse( "setValue must not have been called", testAccessAdapter.isSetValueHasBeenCalled());
        
        testAccessAdapter.reset();
        String newValue = "new value";
        stringAdapter.setValue(newValue);
        assertTrue( "setValue must have been called", testAccessAdapter.isSetValueHasBeenCalled());
        assertSame( "setValue must have been called with correct source parameter", testDataObject, testAccessAdapter.getLastSetValueSourceParameter());
        assertSame( "setValue must have been called with correct value parameter", newValue, testAccessAdapter.getLastSetValueValueParameter());
        assertFalse( "getValue must not have been called", testAccessAdapter.isGetValueHasBeenCalled());
        assertSame( "adapter must return the correct value even after set", aspectValue, stringAdapter.getValue());
        assertTrue( "getValue must have been called", testAccessAdapter.isGetValueHasBeenCalled());
        
        vh.setValue( null);
        testAccessAdapter.reset();
        stringAdapter.setValue( newValue);
        assertFalse( "setValue must not be called when source is null", testAccessAdapter.isSetValueHasBeenCalled());
        assertSame( "adapter must return the correct value even for null source", aspectValue, stringAdapter.getValue());
        assertTrue( "getValue must have been called", testAccessAdapter.isGetValueHasBeenCalled());
        assertNull( "getValue must have been called with a source of null", testAccessAdapter.getLastGetValueSourceParameter());
    }

    /**
     * tests the notification when changing values with an aspect adapter
     * that is based on a value model. (i.e. its trigger is a {@link ExternalUpdate}.
     */
    public void testDefaultNotification()
    {
        ValueHolder baseValueHolder = new ValueHolder( new TestDataObject());
        AspectAdapter stringAdapter = new AspectAdapter( baseValueHolder, "string");
        AspectAdapter intAdapter = new AspectAdapter( baseValueHolder, "int");
        CallbackTarget baseCallbackTarget = new CallbackTarget();
        baseValueHolder.addChangeListener( baseCallbackTarget);
        CallbackTarget stringCallbackTarget = new CallbackTarget();
        stringAdapter.addChangeListener( stringCallbackTarget);
        CallbackTarget intCallbackTarget = new CallbackTarget();
        intAdapter.addChangeListener( intCallbackTarget);
        
        assertFalse( "initial value of change listener for base must be false", baseCallbackTarget.isStateChangedCalled());
        assertFalse( "initial value of change listener for string must be false", stringCallbackTarget.isStateChangedCalled());
        assertFalse( "initial value of change listener for int must be false", intCallbackTarget.isStateChangedCalled());

        // change the string
        stringAdapter.setValue( "New String");
        assertTrue( "base change must have been notified", baseCallbackTarget.isStateChangedCalled());
        assertTrue( "string change must have been notified", stringCallbackTarget.isStateChangedCalled());
        assertTrue( "int change must have been notified", intCallbackTarget.isStateChangedCalled());
        baseCallbackTarget.reset();
        stringCallbackTarget.reset();
        intCallbackTarget.reset();
        
        // change the base
        baseValueHolder.setValue( new TestDataObject());
        assertTrue( "base change must have been notified", baseCallbackTarget.isStateChangedCalled());
        assertTrue( "string change must have been notified", stringCallbackTarget.isStateChangedCalled());
        assertTrue( "int change must have been notified", intCallbackTarget.isStateChangedCalled());
        baseCallbackTarget.reset();
        stringCallbackTarget.reset();
        intCallbackTarget.reset();
        
        // signal external update on base
        baseValueHolder.signalExternalUpdate();
        assertTrue( "base change must have been notified", baseCallbackTarget.isStateChangedCalled());
        assertTrue( "string change must have been notified", stringCallbackTarget.isStateChangedCalled());
        assertTrue( "int change must have been notified", intCallbackTarget.isStateChangedCalled());
        baseCallbackTarget.reset();
        stringCallbackTarget.reset();
        intCallbackTarget.reset();
        
        // signal external update on string
        stringAdapter.signalExternalUpdate();
        assertTrue( "base change must have been notified", baseCallbackTarget.isStateChangedCalled());
        assertTrue( "string change must have been notified", stringCallbackTarget.isStateChangedCalled());
        assertTrue( "int change must have been notified", intCallbackTarget.isStateChangedCalled());
        baseCallbackTarget.reset();
        stringCallbackTarget.reset();
        intCallbackTarget.reset();
        
        // setValue forced on base
        baseValueHolder.setValueForced( baseValueHolder.getValue());
        assertTrue( "base change must have been notified", baseCallbackTarget.isStateChangedCalled());
        assertTrue( "string change must have been notified", stringCallbackTarget.isStateChangedCalled());
        assertTrue( "int change must have been notified", intCallbackTarget.isStateChangedCalled());
        baseCallbackTarget.reset();
        stringCallbackTarget.reset();
        intCallbackTarget.reset();
        
        // setValue forced on string
        stringAdapter.setValueForced( stringAdapter.getValue());
        assertTrue( "base change must have been notified", baseCallbackTarget.isStateChangedCalled());
        assertTrue( "string change must have been notified", stringCallbackTarget.isStateChangedCalled());
        assertTrue( "int change must have been notified", intCallbackTarget.isStateChangedCalled());
        baseCallbackTarget.reset();
        stringCallbackTarget.reset();
        intCallbackTarget.reset();
    }
    
//    Note: the logic for the following test is not yet implemented
//    /**
//     * tests the single attribute notification when changing values with an aspect adapter
//     * that is based on a value model. (i.e. its trigger is a {@link ExternalUpdate}.
//     */
//    public void testLocalNotification()
//    {
//        ValueHolder baseValueHolder = new ValueHolder( new TestDataObject());
//        AspectAdapter stringAdapter = new AspectAdapter( baseValueHolder, "string");
//        stringAdapter.setNotificationStrategy( new LocalNotificationStrategy());
//        AspectAdapter intAdapter = new AspectAdapter( baseValueHolder, "int");
//        CallbackTarget baseCallbackTarget = new CallbackTarget();
//        baseValueHolder.addChangeListener( baseCallbackTarget);
//        CallbackTarget stringCallbackTarget = new CallbackTarget();
//        stringAdapter.addChangeListener( stringCallbackTarget);
//        CallbackTarget intCallbackTarget = new CallbackTarget();
//        intAdapter.addChangeListener( intCallbackTarget);
//        
//        assertFalse( "initial value of change listener for base must be false", baseCallbackTarget.isStateChangedCalled());
//        assertFalse( "initial value of change listener for string must be false", stringCallbackTarget.isStateChangedCalled());
//        assertFalse( "initial value of change listener for int must be false", intCallbackTarget.isStateChangedCalled());
//
//        // change the string
//        stringAdapter.setValue( "New String");
//        assertFalse( "base change must not have been notified", baseCallbackTarget.isStateChangedCalled());
//        assertTrue( "string change must have been notified", stringCallbackTarget.isStateChangedCalled());
//        assertFalse( "int change must not have been notified", intCallbackTarget.isStateChangedCalled());
//        baseCallbackTarget.reset();
//        stringCallbackTarget.reset();
//        intCallbackTarget.reset();
//        
//        // change the base
//        baseValueHolder.setValue( new TestDataObject());
//        assertTrue( "base change must have been notified", baseCallbackTarget.isStateChangedCalled());
//        assertTrue( "string change must have been notified", stringCallbackTarget.isStateChangedCalled());
//        assertTrue( "int change must have been notified", intCallbackTarget.isStateChangedCalled());
//        baseCallbackTarget.reset();
//        stringCallbackTarget.reset();
//        intCallbackTarget.reset();
//        
//        // signal external update on base 
//        baseValueHolder.signalExternalUpdate();
//        assertTrue( "base change must have been notified", baseCallbackTarget.isStateChangedCalled());
//        assertTrue( "string change must have been notified", stringCallbackTarget.isStateChangedCalled());
//        assertTrue( "int change must have been notified", intCallbackTarget.isStateChangedCalled());
//        baseCallbackTarget.reset();
//        stringCallbackTarget.reset();
//        intCallbackTarget.reset();
//        
//        // signal external update on string
//        stringAdapter.signalExternalUpdate();
//        assertFalse( "base change must not have been notified", baseCallbackTarget.isStateChangedCalled());
//        assertTrue( "string change must have been notified", stringCallbackTarget.isStateChangedCalled());
//        assertFalse( "int change must not have been notified", intCallbackTarget.isStateChangedCalled());
//        baseCallbackTarget.reset();
//        stringCallbackTarget.reset();
//        intCallbackTarget.reset();
//        
//        // set value forced on base 
//        baseValueHolder.setValueForced( baseValueHolder.getValue());
//        assertTrue( "base change must have been notified", baseCallbackTarget.isStateChangedCalled());
//        assertTrue( "string change must have been notified", stringCallbackTarget.isStateChangedCalled());
//        assertTrue( "int change must have been notified", intCallbackTarget.isStateChangedCalled());
//        baseCallbackTarget.reset();
//        stringCallbackTarget.reset();
//        intCallbackTarget.reset();
//        
//        // set value forced on string
//        stringAdapter.setValueForced( stringAdapter.getValue());
//        assertFalse( "base change must not have been notified", baseCallbackTarget.isStateChangedCalled());
//        assertTrue( "string change must have been notified", stringCallbackTarget.isStateChangedCalled());
//        assertFalse( "int change must not have been notified", intCallbackTarget.isStateChangedCalled());
//        baseCallbackTarget.reset();
//        stringCallbackTarget.reset();
//        intCallbackTarget.reset();
//        
//    }
    
    // TODO getValue()
    // TODO: Test multiple getter
    // TODO: test notification with Object as source instead of an value model
    
    /**
     * helper class to check the calls for an {@link AspectAccessAdapter}.
     */
    static class TestAccessAdapter implements AspectAccessAdapter
    {

        /**
         * the object to return when {@link #getValue(Object)} is called
         */
        private Object mResultOnGetValue;
        
        /**
         * the parameter value that has been used in the last
         * call to {@link #getValue(Object)}.
         */
        private Object mLastGetValueSourceParameter;
        
        /**
         * the value to return when {@link #isEditable()}
         * is called.
         */
        private boolean mEditable;
        
        /**
         * the value of the source parameter that has been used in the last
         * call to {@link #setValue(Object, Object)}.
         */
        private Object mLastSetValueSourceParameter;
        
        /**
         * the value of the value parameter that has been used in the last
         * call to {@link #setValue(Object, Object)}.
         */
        private Object mLastSetValueValueParameter;
        
        /**
         * true if {@link #getValue(Object)} has been called,
         * set to false in {@link #reset()}.
         */
        private boolean mGetValueHasBeenCalled;
        
        /**
         * true if {@link #setValue(Object, Object)} has been called,
         * set to false in {@link #reset()}
         */
        private boolean mSetValueHasBeenCalled;
        
        /**
         * true if {@link #isEditable()} has been called,
         * set to false in {@link #reset()}
         */
        private boolean mIsEditableHasBeenCalled;

        /**
         * registers the call and returns {@link #mResultOnGetValue}
         * {@inheritDoc}
         */
        public Object getValue(final Object pSource)
        {
            mLastGetValueSourceParameter = pSource;
            mGetValueHasBeenCalled = true;
            return mResultOnGetValue;
        }
    
        /**
         * registers the call and returns {@link #mEditable}
         * {@inheritDoc}
         */
        public boolean isEditable()
        {
            mIsEditableHasBeenCalled = true;
            return mEditable;
        }

        /**
         * registers the call
         * {@inheritDoc}
         */
        public void setValue(final Object pSource, final Object pValue)
        {
            mLastSetValueSourceParameter = pSource;
            mLastSetValueValueParameter = pValue;
            mSetValueHasBeenCalled = true;
        }
        
        /**
         * resets the has been called flags to false.
         */
        public void reset()
        {
            mGetValueHasBeenCalled = false;
            mSetValueHasBeenCalled = false;
            mIsEditableHasBeenCalled = false;
        }

        public boolean isGetValueHasBeenCalled()
        {
            return mGetValueHasBeenCalled;
        }
        
        public void setEditable(final boolean pEditable)
        {
            mEditable = pEditable;
        }

        public boolean isEditableHasBeenCalled()
        {
            return mIsEditableHasBeenCalled;
        }

        public Object getLastGetValueSourceParameter()
        {
            return mLastGetValueSourceParameter;
        }

        public Object getLastSetValueSourceParameter()
        {
            return mLastSetValueSourceParameter;
        }

        public Object getLastSetValueValueParameter()
        {
            return mLastSetValueValueParameter;
        }

        public void setResultOnGetValue(final Object pResultOnGetValue)
        {
            mResultOnGetValue = pResultOnGetValue;
        }
        
        public boolean isSetValueHasBeenCalled()
        {
            return mSetValueHasBeenCalled;
        }
        
        
    }
    
}
