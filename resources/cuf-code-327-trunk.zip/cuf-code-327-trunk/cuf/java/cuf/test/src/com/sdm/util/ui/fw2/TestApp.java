package com.sdm.util.ui.fw2;

import java.util.Map;
import java.util.Properties;

import com.sdm.util.ui.fw.Application;

/**
 * a test application that does nothing and provides nothing
 */
public class TestApp implements Application
{

    public Map<String, Object> getAppModel()
    {
        return null;
    }

    public Properties getProperties()
    {
        return null;
    }

    public String getProperty(final String pKey, final String pDefault)
    {
        return null;
    }

    public void setProperty(final String pKey, final String pValue)
    {
    }

    public void start(final String[] pArgs)
    {
    }

    public void stop()
    {
    }

}
