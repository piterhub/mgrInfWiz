package com.sdm.util.model.ui;

import javax.swing.JLabel;

import com.sdm.util.model.ValueHolder;

import junit.framework.TestCase;

/**
 * Tests the {@link ToolTipAdapter}.
 */
public class ToolTipAdapterTest extends TestCase
{

    public void testCreation()
    {
        ValueHolder vh = new ValueHolder("test");
        JLabel component = new JLabel();
        new ToolTipAdapter( vh, component);
        assertEquals( "initial tooltip must be correct", "test", component.getToolTipText());
    }
    
    /**
     * tests various values
     */
    public void testValues()
    {
        ValueHolder vh = new ValueHolder();
        JLabel component = new JLabel();
        new ToolTipAdapter( vh, component);
        assertNull( "null value must result in null tooltip", component.getToolTipText());
        vh.setValue( "Tooltip");
        assertEquals( "text value must be correct", "Tooltip", component.getToolTipText());
        vh.setValue( "");
        assertNull( "empty string must result in null tooltip", component.getToolTipText());
    }
    
}
