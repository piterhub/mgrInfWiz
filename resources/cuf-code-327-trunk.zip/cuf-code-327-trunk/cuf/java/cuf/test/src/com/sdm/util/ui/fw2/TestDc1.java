/**
 * 
 */
package com.sdm.util.ui.fw2;

import java.util.Map;

import com.sdm.util.ui.fw.Dc;

/**
 * a test {@link Dc} that stores its init parameters
 * locally.
 */
public class TestDc1 implements Dc
{
    /**
     * the parent we were initialized with
     */
    private Dc mParent;

    /**
     * the arguments we were initialized with
     */
    private Map<String, ? super Object> mArgs;

    public void init(final Dc pParent, final Map<String, ? super Object> pArgs)
    {
        mParent = pParent;
        mArgs = pArgs;
    }

    /**
     * Return the parent
     * @return the parent Dc
     */
    public Dc getParent()
    {
        return mParent;
    }

    /**
     * Return our arguments.
     * @return the arguments
     */
    public Map<String, ? super Object> getArgs()
    {
        return mArgs;
    }
}