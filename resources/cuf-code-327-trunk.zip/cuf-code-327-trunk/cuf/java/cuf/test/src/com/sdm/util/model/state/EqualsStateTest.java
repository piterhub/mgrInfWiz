package com.sdm.util.model.state;

import junit.framework.TestCase;

import com.sdm.util.model.ValueHolder;

/**
 * tests {@link EqualsState}
 */
public class EqualsStateTest extends TestCase
{
    
    public void testCreation()
    {
        ValueHolder vm1 = new ValueHolder();
        ValueHolder vm2 = new ValueHolder();
        EqualsState equalsState = new EqualsState( vm1, vm2);
        assertTrue( "state must be initialized", equalsState.isInitialized());
        assertTrue( "null values must be equal", equalsState.isEnabled());
    }
    
    public void testEqual()
    {
        ValueHolder vm1 = new ValueHolder();
        ValueHolder vm2 = new ValueHolder();
        EqualsState equalsState = new EqualsState( vm1, vm2);
        vm1.setValue( "Test");
        vm2.setValue( "Test");
        assertTrue( "state must be initialized", equalsState.isInitialized());
        assertTrue( "equals values must result in state enabled", equalsState.isEnabled());
    }
    
    public void testNotEqual()
    {
        ValueHolder vm1 = new ValueHolder();
        ValueHolder vm2 = new ValueHolder();
        EqualsState equalsState = new EqualsState( vm1, vm2);
        vm1.setValue( "Not");
        vm2.setValue( "Equal");
        assertTrue( "state must be initialized", equalsState.isInitialized());
        assertFalse( "not equals values must result in state disabled", equalsState.isEnabled());
    }
    
    public void testExplicitValue()
    {
        ValueHolder vm = new ValueHolder();
        EqualsState equalsState = new EqualsState( vm, "Test");
        assertTrue( "state must be initialized", equalsState.isInitialized());
        assertFalse( "not equals values must result in state disabled", equalsState.isEnabled());
        vm.setValue( "Test");
        assertTrue( "state must be initialized", equalsState.isInitialized());
        assertTrue( "equals values must result in state enabled", equalsState.isEnabled());
        vm.setValue( "NotEqual");
        assertTrue( "state must be initialized", equalsState.isInitialized());
        assertFalse( "not equals values must result in state disabled", equalsState.isEnabled());
    }
}
