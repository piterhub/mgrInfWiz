package com.sdm.util.model.state;

import com.sdm.util.model.ValueHolder;
import com.sdm.util.model.ValueModel;
import com.sdm.util.state.State;

import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

/**
 * Simple test runner.
 */
@SuppressWarnings({"UseOfSystemOutOrSystemErr"})
public class ValueStateRunner
{
    /**
     * We only need main.
     */
    private ValueStateRunner()
    {
    }

    /**
     * Small test driver.
     * @param pArgs not used
     */
    public static void main(final String[] pArgs)
    {
        ValueModel<Boolean> model= new ValueHolder<Boolean>();
        model.addChangeListener(new ChangeListener()
        {
            public void stateChanged(final ChangeEvent pEvent)
            {
                System.out.println("in model stateChanged");
                System.out.println("    value    ="+((ValueModel<?>)pEvent.getSource()).getValue());
            }
        });

        ValueState state= new ValueState(model);
        state.addChangeListener(new ChangeListener()
        {
            public void stateChanged(final ChangeEvent pEvent)
            {
                System.out.println("in state stateChanged");
                System.out.println("    isEnabled="+((State)pEvent.getSource()).isEnabled());
            }
        });

        model.setValue(Boolean.TRUE);
        state.setEnabled(false);
    }
}
