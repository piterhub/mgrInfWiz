package com.sdm.util.model.ui;

import java.util.ArrayList;
import java.util.List;

import javax.swing.JComboBox;

import junit.framework.TestCase;

import com.sdm.util.model.CallbackTarget;
import com.sdm.util.model.ValueHolder;
import com.sdm.util.model.ValueModel;

/**
 * a few tests for the {@link LOVAdapter}
 */
public class LOVAdapterTest extends TestCase
{

    /**
     * tests the simple creation of a {@link LOVAdapter}
     */
    public void testComboCreationWithoutSelection()
    {
        List keys = createTestKeys( new int[]{ 1,2,3});
        List displays = createTestDisplays( keys);
        ValueHolder keysVM = new ValueHolder(keys);
        ValueHolder displaysVM = new ValueHolder(displays);
        ValueHolder selectedVM = new ValueHolder();
        JComboBox combo = new JComboBox();
        LOVAdapter lovAdapter = new LOVAdapter( combo, displaysVM, keysVM, selectedVM);
        checkLovState(lovAdapter, combo, selectedVM, keys, displays, -1);
    }
    
    /**
     * tests the change of the keys and the display list
     * to a list of the same length but different values
     */
    public void testListChangeSameLength()
    {
        List keys = createTestKeys( new int[]{ 1,2,3});
        List displays = createTestDisplays( keys);
        ValueHolder keysVM = new ValueHolder(keys);
        ValueHolder displaysVM = new ValueHolder(displays);
        ValueHolder selectedVM = new ValueHolder();
        CallbackTarget selectedCallback = new CallbackTarget();
        selectedVM.addChangeListener( selectedCallback);
        JComboBox combo = new JComboBox();
        LOVAdapter lovAdapter = new LOVAdapter( combo, displaysVM, keysVM, selectedVM);
        selectedVM.setValue( keys.get(1));
        assertTrue( "selection must have been fired", selectedCallback.isStateChangedCalled());
        checkLovState(lovAdapter, combo, selectedVM, keys, displays, 1);
        selectedCallback.reset();
        
        // replace the list with a different list (first keys)
        keys = createTestKeys( new int[]{ 17,18,19});
        displays = createTestDisplays( keys);
        keysVM.setValue( keys);
        displaysVM.setValue( displays);
        assertTrue( "selection must have been fired", selectedCallback.isStateChangedCalled());
        checkLovState( lovAdapter, combo, selectedVM, keys, displays, -1);
        selectedCallback.reset();
        selectedVM.setValue( keys.get(1));
        assertTrue( "selection must have been fired", selectedCallback.isStateChangedCalled());
        checkLovState( lovAdapter, combo, selectedVM, keys, displays, 1);
        selectedCallback.reset();
        
        // replace the list with a different list (first displays)
        keys = createTestKeys( new int[]{ 31,32,33});
        displays = createTestDisplays( keys);
        displaysVM.setValue( displays); 
        keysVM.setValue( keys);
        assertTrue( "selection must have been fired", selectedCallback.isStateChangedCalled());
        checkLovState( lovAdapter, combo, selectedVM, keys, displays, -1);
        selectedCallback.reset();
        selectedVM.setValue( keys.get(1));
        assertTrue( "selection must have been fired", selectedCallback.isStateChangedCalled());
        checkLovState( lovAdapter, combo, selectedVM, keys, displays, 1);
        selectedCallback.reset();
        
    }

    /**
     * tests the change of the keys and the display list
     * to a shorter list with different values
     */
    public void testListChangeShorter()
    {
        List keys = createTestKeys( new int[]{ 1,2,3});
        List displays = createTestDisplays( keys);
        ValueHolder keysVM = new ValueHolder(keys);
        ValueHolder displaysVM = new ValueHolder(displays);
        ValueHolder selectedVM = new ValueHolder();
        CallbackTarget selectedCallback = new CallbackTarget();
        selectedVM.addChangeListener( selectedCallback);
        JComboBox combo = new JComboBox();
        LOVAdapter lovAdapter = new LOVAdapter( combo, displaysVM, keysVM, selectedVM);
        selectedVM.setValue( keys.get(1));
        assertTrue( "selection must have been fired", selectedCallback.isStateChangedCalled());
        checkLovState(lovAdapter, combo, selectedVM, keys, displays, 1);
        selectedCallback.reset();
        
        // replace the list with a different list (first keys)
        keys = createTestKeys( new int[]{ 17});
        displays = createTestDisplays( keys);
        keysVM.setValue( keys);
        displaysVM.setValue( displays);
        assertTrue( "selection must have been fired", selectedCallback.isStateChangedCalled());
        checkLovState( lovAdapter, combo, selectedVM, keys, displays, -1);
        selectedCallback.reset();
    }

    /**
     * Creates a list of Integer objects corresponding to the given ints
     * @param pKeys the values
     * @return the list of Integer values
     */
    private List createTestKeys(final int[] pKeys)
    {
        List result = new ArrayList();
        for (final int pKey : pKeys)
        {
            result.add(pKey);
        }
        return result;
    }

    /**
     * Based on the list of keys we form the values as
     * the {@link Object#toString()} with surrounding &lt; and &gt;
     * @param pKeys a list of keys
     * @return a matching list of display values
     */
    private List createTestDisplays( final List pKeys)
    {
        List result = new ArrayList();
        for (final Object pKey : pKeys)
        {
            result.add("<" + pKey + '>');
        }
        return result;
    }
    
    /**
     * tests if the given LOVAdapter and the combo are set up consistently
     * with the data.
     * 
     * @param pLovAdapter the LOVAdapter
     * @param pCombo the Combo to which the LOVAdapter is connected
     * @param pSelectedVM the value model holding the selected key
     * @param pKeys the correct list of keys
     * @param pDisplays the correct list of display values
     * @param pSelectedIndex the index in the lists that should be selected
     */
    private void checkLovState(final LOVAdapter pLovAdapter, final JComboBox pCombo, final ValueModel pSelectedVM, final List pKeys, final List pDisplays, final int pSelectedIndex)
    {
        if (pSelectedIndex<0)
        {
            // checks concerning the display
            assertNull( "selected item must be null", pLovAdapter.getSelectedItem());
            assertEquals( "selection index must be correct", -1, pLovAdapter.getSelectedIndex());
            assertEquals( "combo must have correct selection index", -1, pCombo.getSelectedIndex());
            assertNull( "combo must have correct selection value", pCombo.getSelectedItem());
            // checks concerning the key
            assertNull( "selected key must be null", pSelectedVM.getValue());
        }
        else
        {
            Object correctSelectedKey = pKeys.get( pSelectedIndex);
            Object correctSelectedDisplay = pDisplays.get( pSelectedIndex);
            // checks concerning the display
            assertSame( "selected item must be correct", correctSelectedDisplay, pLovAdapter.getSelectedItem());
            assertEquals( "selection index must be correct", pSelectedIndex, pLovAdapter.getSelectedIndex());
            assertEquals( "combo must have correct selection index", pSelectedIndex, pCombo.getSelectedIndex());
            assertSame( "combo must have correct selection value", correctSelectedDisplay, pCombo.getSelectedItem());
            // checks concerning the key
            assertSame( "selected key must be correct", correctSelectedKey, pSelectedVM.getValue());
        }
        assertEquals( "combo must have the correct number of entries", pDisplays.size(), pCombo.getItemCount());
        for (int i = 0; i < pDisplays.size(); i++)
        {
            assertSame( "combo must have correct entry at index "+i, pDisplays.get(i), pCombo.getItemAt(i));
        }
    }
    
    // TODO: lots of other tests, 
    // e.g. list changes in various contents with different call orders,
    // handling of inconsistent lists (duplicate values, different length, ...),
    // ...
    
}
