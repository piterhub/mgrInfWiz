package com.sdm.util.model.converter;

import junit.framework.TestCase;

import com.sdm.util.model.ValueHolder;
import com.sdm.util.model.ValueModel;

/**
 * Tests the {@link AbstractTypeConverter},
 * is NOT a base class for tests of derived type converters.
 */
public class AbstractTypeConverterTest extends TestCase
{

    /**
     * tests, if our appending test converter works correctly
     */
    public void testAppendingTypeConverter()
    {
        AbstractTypeConverter tc = createAppendingTypeConverter( new ValueHolder(), "X");
        try
        {
            assertEquals( "X must be appended", "TestX", tc.convertSubjectToOwnValue( "Test"));
        } catch (ConversionException e)
        {
            fail( "Unexpected exception: "+e);
        }
        try
        {
            assertEquals( "X must be removed", "Test", tc.convertOwnToSubjectValue( "TestX"));
        } catch (ConversionException e)
        {
            fail( "Unexpected exception: "+e);
        }
    }

    public void testAlternativeTypeConverter()
    {
        AbstractTypeConverter tc = createAlternativeTypeConverter( new ValueHolder(), "subAlt", "ownAlt");
        try
        {
            tc.convertSubjectToOwnValue( "Test");
            fail( "Exception expected");
        } catch (ConversionException e)
        {
            assertEquals( "alternative value", "ownAlt", e.getConversionValue());
        }
        try
        {
            tc.convertOwnToSubjectValue( "Test");
            fail( "Exception expected");
        } catch (ConversionException e)
        {
            assertEquals( "alternative value", "subAlt", e.getConversionValue());
        }
    }

    public void testFailingTypeConverter()
    {
        AbstractTypeConverter tc = createFailingTypeConverter( new ValueHolder(), false);
        try
        {
            tc.convertSubjectToOwnValue( "Test");
            fail( "Exception expected");
        } catch (ConversionException e)
        {
            assertNull( "alternative value must be null", e.getConversionValue());
        }
        try
        {
            tc.convertOwnToSubjectValue( "Test");
            fail( "Exception expected");
        } catch (ConversionException e)
        {
            assertNull( "alternative value must be null", e.getConversionValue());
        }
    }

    /**
     * tests if the conversion from subject to own value is called correctly
     */
    public void testSubjectToOwnOk()
    {
        ValueHolder valueHolder = new ValueHolder();
        valueHolder.setValue( "Test");
        AbstractTypeConverter tc = createAppendingTypeConverter( valueHolder, "C");
        assertEquals( "own value must be correct", "TestC", tc.getValue());
        assertTrue( "must be in sync", tc.getSyncState().booleanValue());
    }
    
    /**
     * tests if the conversion from own to subject value is called correctly
     */
    public void testOwnToSubjectOk()
    {
        ValueHolder valueHolder = new ValueHolder();
        AbstractTypeConverter tc = createAppendingTypeConverter( valueHolder, "C");
        tc.setValue( "TestC");
        assertEquals( "subject value must be correct", "Test", valueHolder.getValue());
        assertTrue( "must be in sync", tc.getSyncState().booleanValue());
    }
    
    /**
     * tests if the conversion from subject to own value provides the correct alternative value
     */
    public void testSubjectToOwnAlternative()
    {
        ValueHolder valueHolder = new ValueHolder();
        valueHolder.setValue( "Test");
        AbstractTypeConverter tc = createAlternativeTypeConverter( valueHolder, "subjectAlternative", "ownAlternative");
        assertEquals( "own value must be correct", "ownAlternative", tc.getValue());
        assertFalse( "must be out of sync", tc.getSyncState().booleanValue());
    }
    
    /**
     * tests if the conversion from own to subject value provides the correct alternative value
     */
    public void testOwnToSubjectAlternative()
    {
        ValueHolder valueHolder = new ValueHolder();
        AbstractTypeConverter tc = createAlternativeTypeConverter( valueHolder, "subjectAlternative", "ownAlternative");
        tc.setValue( "Test");
        assertEquals( "subject value must be correct", "subjectAlternative", valueHolder.getValue());
        assertFalse( "must be out of sync", tc.getSyncState().booleanValue());
    }
    
    /**
     * tests if the conversion from subject to own value forwards failed exceptions
     */
    public void testSubjectToOwnFailedWithPropagation()
    {
        ValueHolder valueHolder = new ValueHolder();
        valueHolder.setValue( "Test");
        AbstractTypeConverter tc = createFailingTypeConverter( valueHolder, true);
        try 
        {
            tc.getValue();
            fail( "Exception expected");
        }
        catch (IllegalStateException e)
        {
            // correct
        }
    }
    
    /**
     * tests if the conversion from own to subject value forwards failed exceptions
     */
    public void testOwnToSubjectFailedWithPropagation()
    {
        ValueHolder valueHolder = new ValueHolder();
        AbstractTypeConverter tc = createFailingTypeConverter( valueHolder, true);
        try 
        {
            tc.setValue( "Test");
            fail( "Exception expected");
        }
        catch (IllegalStateException e)
        {
            // correct
        }
    }
    
    /**
     * tests if the conversion from subject to own value forwards failed exceptions
     */
    public void testSubjectToOwnFailedWithoutPropagation()
    {
        ValueHolder valueHolder = new ValueHolder();
        valueHolder.setValue( "Test");
        AbstractTypeConverter tc = createFailingTypeConverter( valueHolder, false);
        try 
        {
            assertNull( "result must be null because of failed conversion", tc.getValue());
        }
        catch (IllegalStateException e)
        {
            fail( "Did not expect exception but silent ignore");
        }
        assertFalse( "must be out of sync", tc.getSyncState().booleanValue());
    }
    
    /**
     * tests if the conversion from own to subject value forwards failed exceptions
     */
    public void testOwnToSubjectFailedWithoutPropagation()
    {
        ValueHolder valueHolder = new ValueHolder();
        AbstractTypeConverter tc = createFailingTypeConverter( valueHolder, false);
        try 
        {
            tc.setValue( "Test");
        }
        catch (IllegalStateException e)
        {
            fail( "Did not expect exception but silent ignore");
        }
        assertFalse( "must be out of sync", tc.getSyncState().booleanValue());
        assertEquals( "subject must be unchanged", null, valueHolder.getValue());
    }
    
    /**
     * creates a type converter which concatenates a string to the subject value
     * and removes the given number of characters from the own value
     * as conversion.
     * 
     * @param pSubject the source
     * @param pAppendValue the string to append
     * @return the type converter
     */
    private AbstractTypeConverter createAppendingTypeConverter( final ValueModel pSubject, final String pAppendValue)
    {
        return new AbstractTypeConverter( pSubject) {
            public Object convertOwnToSubjectValue(final Object pOwnValue) throws ConversionException
            {
                String value = (String) pOwnValue;
                return value.substring( 0, value.length()-pAppendValue.length());
            }
            public Object convertSubjectToOwnValue(final Object pSubjectValue) throws ConversionException
            {
                String value = (String) pSubjectValue;
                return value+pAppendValue;
            }
        };
    }
    
    /**
     * creates a type converter which fails the conversion but 
     * provides an alternative value.
     * 
     * @param pSubject the source
     * @param pSubjectAltValue the alternative value for the subject
     * @param pOwnAltValue the alternative value for our own value
     * @return the type converter
     */
    private AbstractTypeConverter createAlternativeTypeConverter( final ValueModel pSubject, final String pSubjectAltValue, final String pOwnAltValue)
    {
        return new AbstractTypeConverter( pSubject) {
            public Object convertOwnToSubjectValue(final Object pOwnValue) throws ConversionException
            {
                throw new ConversionException( "Conversion failed", null, pSubjectAltValue);
            }
            public Object convertSubjectToOwnValue(final Object pSubjectValue) throws ConversionException
            {
                throw new ConversionException( "Conversion failed", null, pOwnAltValue);
            }
        };
    }
    
    /**
     * creates a type converter which fails the conversion and does not 
     * provide an alternative value.
     * 
     * @param pSubject the source
     * @param pPropagate true if conversion exceptions should be propagated
     * @return the type converter
     */
    private AbstractTypeConverter createFailingTypeConverter( final ValueModel pSubject, final boolean pPropagate)
    {
        return new AbstractTypeConverter( pSubject, pPropagate) {
            public Object convertOwnToSubjectValue(final Object pOwnValue) throws ConversionException
            {
                throw new ConversionException( "Conversion failed", null);
            }
            public Object convertSubjectToOwnValue(final Object pSubjectValue) throws ConversionException
            {
                throw new ConversionException( "Conversion failed", null);
            }
        };
    }
    
}
