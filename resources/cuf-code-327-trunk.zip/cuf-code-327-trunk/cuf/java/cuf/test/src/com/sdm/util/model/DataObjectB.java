package com.sdm.util.model;

import java.util.Date;
import java.util.List;
import java.util.ArrayList;

/**
 * Object containing data used for test purposes.
 * DataObjectA handles method-based access.
 */
public class DataObjectB
{
    private String mName;
    private Date   mBorn;
    private DataObjectB mFather;
    private DataObjectB mMother;
    private List   mChildren= new ArrayList();

    public String getName()
    {
        return mName;
    }

    public void setName(final String pName)
    {
        mName = pName;
    }

    public Date getBorn()
    {
        return mBorn;
    }

    public void setBorn(final Date pBorn)
    {
        mBorn = pBorn;
    }

    public DataObjectB getFather()
    {
        return mFather;
    }

    public void setFather(final DataObjectB pFather)
    {
        mFather = pFather;
    }

    public DataObjectB getMother()
    {
        return mMother;
    }

    public void setMother(final DataObjectB pMother)
    {
        mMother = pMother;
    }

    public List getChildren()
    {
        return mChildren;
    }

    public void setChildren(final List pChildren)
    {
        mChildren = pChildren;
    }
}
