package com.sdm.util.model.state.ui;

import javax.swing.JTextField;

import junit.framework.TestCase;

import com.sdm.util.state.AbstractStateAdapter;
import com.sdm.util.state.SimpleState;
import com.sdm.util.state.State;
import com.sdm.util.state.ui.SwingEnabledAdapter;
import com.sdm.util.state.ui.SwingVisibleAdapter;

/**
 * tests {@link AbstractStateAdapter}
 */
public class AbstractStateAdapterTest extends TestCase
{

    /**
     * tests the multiple use of a target 
     * for the same adapter category.
     */
    public void testDuplicateTargets()
    {
        JTextField textField = new JTextField();
        State state = new SimpleState();
        SwingEnabledAdapter enabledAdapter1 = new SwingEnabledAdapter( state);
        SwingEnabledAdapter enabledAdapter2 = new SwingEnabledAdapter( state);
        enabledAdapter1.add( textField);
        try 
        {
            enabledAdapter1.add( textField);
            fail( "Expected exception for duplicate target");
        }
        catch (IllegalArgumentException ex)
        {
            // correct
        }
        try 
        {
            enabledAdapter2.add( textField);
            fail( "Expected exception for duplicate target");
        }
        catch (IllegalArgumentException ex)
        {
            // correct
        }
        // but after a remove, it should be possible
        enabledAdapter1.remove( textField);
        enabledAdapter2.add( textField);
        // it must be ok to add a different target
        enabledAdapter1.add( new JTextField());
        enabledAdapter2.add( new JTextField());
        // and it must be ok to add to an adapter of different category
        SwingVisibleAdapter visibleAdapter = new SwingVisibleAdapter( state);
        visibleAdapter.add( textField);
    }
    
}
