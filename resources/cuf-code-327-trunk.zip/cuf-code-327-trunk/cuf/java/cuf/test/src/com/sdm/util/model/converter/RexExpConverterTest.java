package com.sdm.util.model.converter;

import junit.framework.TestCase;

import com.sdm.util.model.CallbackTarget;
import com.sdm.util.model.ValueHolder;

/**
 * Tests {@link RegExpConverter}
 */
public class RexExpConverterTest extends TestCase
{

    /**
     * Tests the creation of a RegExpConverter.
     */
    public void testCreate()
    {
        ValueHolder valueHolder = new ValueHolder();
        RegExpConverter regExpConverter = new RegExpConverter( valueHolder, "");
        assertTrue( "must be in sync for null", regExpConverter.getSyncState().booleanValue());
        assertEquals( "null must be passed through", null, regExpConverter.getValue());
    }

    /**
     * tests the correct 'conversion'
     */
    public void testCorrectConversion()
    {
        ValueHolder valueHolder = new ValueHolder();
        RegExpConverter regExpConverter = new RegExpConverter( valueHolder, "[ABC]*");
        assertTrue( "must be in sync for null", regExpConverter.getSyncState().booleanValue());
        assertEquals( "null must be passed through", null, regExpConverter.getValue());
        valueHolder.setValue( "AA");
        assertTrue( "must be in sync for correct value", regExpConverter.getSyncState().booleanValue());
        assertEquals( "value must be passed through", "AA", regExpConverter.getValue());
        regExpConverter.setValue( "BB");
        assertTrue( "must be in sync for correct value", regExpConverter.getSyncState().booleanValue());
        assertEquals( "value must be passed through", "BB", valueHolder.getValue());
    }
    
    /**
     * tests the incorrect 'conversion' with a default setting
     */
    public void testIncorrectConversionDefault()
    {
        ValueHolder valueHolder = new ValueHolder();
        RegExpConverter regExpConverter = new RegExpConverter( valueHolder, "[ABC]*");
        checkIncorrectConversionBlocked(valueHolder, regExpConverter);
    }
    
    /**
     * tests the incorrect 'conversion' with block setting
     */
    public void testIncorrectConversionBlock()
    {
        ValueHolder valueHolder = new ValueHolder();
        RegExpConverter regExpConverter = new RegExpConverter( valueHolder, "[ABC]*", true);
        checkIncorrectConversionBlocked(valueHolder, regExpConverter);
    }
    
    /**
     * tests the incorrect 'conversion' with unblocked setting
     */
    public void testIncorrectConversionUnblocked()
    {
        ValueHolder valueHolder = new ValueHolder();
        RegExpConverter regExpConverter = new RegExpConverter( valueHolder, "[ABC]*", false);
        CallbackTarget regExpConverterCallbackTarget = new CallbackTarget();
        regExpConverter.addChangeListener( regExpConverterCallbackTarget);
        assertTrue( "must be in sync for null", regExpConverter.getSyncState().booleanValue());
        regExpConverterCallbackTarget.reset();
        valueHolder.setValue( "wrong");
        assertFalse( "must be out of sync for wrong value", regExpConverter.getSyncState().booleanValue());
        assertEquals( "wrong value must be passed through", "wrong", regExpConverter.getValue());
        assertTrue("callbackTarget must have been notified for value change", regExpConverterCallbackTarget.isStateChangedCalled());
        regExpConverterCallbackTarget.reset();
        regExpConverter.setValue( "wrong, too");
        assertFalse( "must be out of sync for wrong value", regExpConverter.getSyncState().booleanValue());
        assertEquals( "value must be passed through", "wrong, too", valueHolder.getValue());
    }
    
    /**
     * check if the given converter and value model perform correctly
     * for blocked conversions.
     */
    public void checkIncorrectConversionBlocked( final ValueHolder valueHolder, final RegExpConverter regExpConverter)
    {
        CallbackTarget regExpConverterCallbackTarget = new CallbackTarget();
        regExpConverter.addChangeListener( regExpConverterCallbackTarget);
        assertTrue( "must be in sync for null", regExpConverter.getSyncState().booleanValue());
        regExpConverterCallbackTarget.reset();
        valueHolder.setValue( "wrong");
        assertFalse( "must be out of sync for wrong value", regExpConverter.getSyncState().booleanValue());
        try 
        {
            assertNull( "failed conversion should result in null since RegExpConverter ignores failiures by default", regExpConverter.getValue());
        } 
        catch (IllegalStateException ex)
        {
            fail( "getValue should not fail on get value");
        }
        assertFalse("callbackTarget must not have been notified for value change", regExpConverterCallbackTarget.isStateChangedCalled());
        regExpConverterCallbackTarget.reset();
        regExpConverter.setValue( "wrong, too");
        assertFalse( "must be out of sync for wrong value", regExpConverter.getSyncState().booleanValue());
        assertEquals( "value must not be passed through", "wrong", valueHolder.getValue());
    }
    
}
