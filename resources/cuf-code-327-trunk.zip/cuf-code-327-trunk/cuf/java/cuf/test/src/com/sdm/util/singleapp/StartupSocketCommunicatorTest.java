package com.sdm.util.singleapp;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.io.StreamCorruptedException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;

import junit.framework.TestCase;
import junit.textui.TestRunner;

/**
 * a few tests for the {@link StartupSocketCommunicator}
 */
public class StartupSocketCommunicatorTest extends TestCase
{
    
    /**
     * a port that should be available
     */
    private static final int PORT_TO_USE = 12345;

    /**
     * runs these tests with a text ui
     * @param args ignored
     */
    public static void main(final String[] args)
    {
        TestRunner.run(StartupSocketCommunicatorTest.class);
    }
    
    /**
     * checks if the port for is available, fails otherwise
     * @param pPort the port to check
     */
    private void checkPortAvailable(final int pPort)
    {
        ServerSocket serverSocket = null;
        try
        {
            serverSocket = new ServerSocket(pPort);
        } 
        catch (IOException e)
        {
            fail("Port "+pPort+" is not available: "+e);
        }
        try
        {
            serverSocket.close();
        } 
        catch (IOException e)
        {
            fail("Could not close the socket on port "+pPort+" we just opened: "+e);
        }
    }

    /**
     * tests if the simple server creation works
     */
    public void testServerCreation() throws InterruptedException
    {
        checkPortAvailable(PORT_TO_USE);
        StartupSocketCommunicator sscServer = new StartupSocketCommunicator( "TestApp", PORT_TO_USE, new ContactHandler() {
            public Serializable handleContactFromOtherInstance(final Serializable pData)
            {
                return pData+"-Pong";
            }
        }, "Ping");
        assertTrue(sscServer.isServerMode());
        Thread.sleep(1000); // wait a bit so the server thread can finish running
        assertFalse(sscServer.isServerStopped());
        sscServer.waitServerStopped();
        assertTrue(sscServer.isServerStopped());
        assertNull(sscServer.getException());
    }
    
    /**
     * tests a simple client server interaction with a null parameter
     */
    public void testSimpleServerInteraction() throws InterruptedException
    {
        checkPortAvailable(PORT_TO_USE);
        StartupSocketCommunicator sscServer = new StartupSocketCommunicator( "TestApp", PORT_TO_USE, new ContactHandler() {
            public Serializable handleContactFromOtherInstance(final Serializable pData)
            {
                assertNull(pData);
                return null;
            }
        }, "NotNull");
        assertTrue(sscServer.isServerMode());
        assertFalse(sscServer.isServerStopped());
        StartupSocketCommunicator sscClient = new StartupSocketCommunicator( "TestApp", PORT_TO_USE, new ContactHandler() {
            public Serializable handleContactFromOtherInstance(final Serializable pData)
            {
                fail("Should not be called");
                return null; // to please the compiler
            }
        }, null);
        assertFalse(sscClient.isServerMode());
        assertNull(sscClient.getException());
        assertNull(sscClient.getClientResult());
        Thread.sleep(1000); // wait a bit so the server thread can finish running
        assertFalse(sscServer.isServerStopped());
        sscServer.waitServerStopped();
        assertTrue(sscServer.isServerStopped());
        assertNull(sscServer.getException());
    }
    
    /**
     * tests a simple client server interaction with String parameter
     */
    public void testStringServerInteraction() throws InterruptedException
    {
        checkPortAvailable(PORT_TO_USE);
        StartupSocketCommunicator sscServer = new StartupSocketCommunicator( "TestApp", PORT_TO_USE, new ContactHandler() {
            public Serializable handleContactFromOtherInstance(final Serializable pData)
            {
                assertEquals("ParamFromClient",pData);
                return "ValueFromServer";
            }
        }, null);
        assertTrue(sscServer.isServerMode());
        assertFalse(sscServer.isServerStopped());
        StartupSocketCommunicator sscClient = new StartupSocketCommunicator( "TestApp", PORT_TO_USE, new ContactHandler() {
            public Serializable handleContactFromOtherInstance(final Serializable pData)
            {
                fail("Should not be called");
                return null; // to please the compiler
            }
        }, "ParamFromClient");
        assertFalse(sscClient.isServerMode());
        assertNull(sscClient.getException());
        assertEquals("ValueFromServer",sscClient.getClientResult());
        Thread.sleep(1000); // wait a bit so the server thread can finish running
        assertFalse(sscServer.isServerStopped());
        sscServer.waitServerStopped();
        assertTrue(sscServer.isServerStopped());
        assertNull(sscServer.getException());
    }
    
    /**
     * tests server throwing an exception
     */
    public void testServerException() throws InterruptedException
    {
        checkPortAvailable(PORT_TO_USE);
        StartupSocketCommunicator sscServer = new StartupSocketCommunicator("TestApp", PORT_TO_USE, new ContactHandler()
        {
            public Serializable handleContactFromOtherInstance(final Serializable pData)
            {
                throw new RuntimeException("TestException");
            }
        }, null);
        assertTrue(sscServer.isServerMode());
        assertFalse(sscServer.isServerStopped());
        StartupSocketCommunicator sscClient = new StartupSocketCommunicator("TestApp", PORT_TO_USE, new ContactHandler()
        {
            public Serializable handleContactFromOtherInstance(final Serializable pData)
            {
                fail("Should not be called");
                return null; // to please the compiler
            }
        }, "ParamFromClient");
        assertFalse(sscClient.isServerMode());
        Throwable clientEx = sscClient.getException();
        assertNotNull(clientEx);
        assertTrue(clientEx instanceof RuntimeException);
        assertEquals("Error in communication to server: NOK:Handler returned error: java.lang.RuntimeException: TestException", clientEx.getMessage());
        assertNull(sscClient.getClientResult());
        Thread.sleep(1000); // wait a bit so the server thread can finish running
        assertFalse(sscServer.isServerStopped());
        sscServer.waitServerStopped();
        assertTrue(sscServer.isServerStopped());
        Throwable serverEx = sscServer.getException();
        assertNotNull(serverEx);
        assertTrue(serverEx instanceof RuntimeException);
        assertEquals("TestException", serverEx.getMessage());
    }
    
    /**
     * tests an application id mismatch
     */
    public void testWrongAppId() throws InterruptedException
    {
        checkPortAvailable(PORT_TO_USE);
        StartupSocketCommunicator sscServer = new StartupSocketCommunicator("TestApp1", PORT_TO_USE, new ContactHandler()
        {
            public Serializable handleContactFromOtherInstance(final Serializable pData)
            {
                fail("Should not be called");
                return null; // to please the compiler
            }
        }, null);
        assertTrue(sscServer.isServerMode());
        assertFalse(sscServer.isServerStopped());
        StartupSocketCommunicator sscClient = new StartupSocketCommunicator("TestApp2", PORT_TO_USE, new ContactHandler()
        {
            public Serializable handleContactFromOtherInstance(final Serializable pData)
            {
                fail("Should not be called");
                return null; // to please the compiler
            }
        }, "ParamFromClient");
        assertFalse(sscClient.isServerMode());
        Throwable clientEx = sscClient.getException();
        assertNotNull(clientEx);
        assertTrue(clientEx instanceof RuntimeException);
        assertEquals("Error in communication to server: NOK:Application id does not match", clientEx.getMessage());
        assertNull(sscClient.getClientResult());
        Thread.sleep(1000); // wait a bit so the server thread can finish running
        assertFalse(sscServer.isServerStopped());
        sscServer.waitServerStopped();
        assertTrue(sscServer.isServerStopped());
        Throwable serverEx = sscServer.getException();
        assertNotNull(serverEx);
        assertTrue(serverEx instanceof RuntimeException);
        assertEquals("Client sent different application id: got TestApp2 expected TestApp1", serverEx.getMessage());
    }
    
    /**
     * tests a mismatch of the magic number
     */
    public void testWrongMagicNumber() throws Exception
    {
        checkPortAvailable(PORT_TO_USE);
        StartupSocketCommunicator sscServer = new StartupSocketCommunicator("TestApp1", PORT_TO_USE, new ContactHandler()
        {
            public Serializable handleContactFromOtherInstance(final Serializable pData)
            {
                fail("Should not be called");
                return null; // to please the compiler
            }
        }, null);
        assertTrue(sscServer.isServerMode());
        assertFalse(sscServer.isServerStopped());
        // simulate a different client
        Socket clientSocket = new Socket(InetAddress.getLocalHost(), PORT_TO_USE);
        ObjectOutputStream clientOut = new ObjectOutputStream(clientSocket.getOutputStream());
        clientOut.writeLong(17);
        clientOut.flush();
        ObjectInputStream clientIn = new ObjectInputStream(clientSocket.getInputStream());
        String resultMessage = (String) clientIn.readObject();
        assertEquals("NOK:Magic Number does not match", resultMessage);
        Thread.sleep(1000); // wait a bit so the server thread can finish running
        assertFalse(sscServer.isServerStopped());
        sscServer.waitServerStopped();
        assertTrue(sscServer.isServerStopped());
        Throwable serverEx = sscServer.getException();
        assertNotNull(serverEx);
        assertTrue(serverEx instanceof RuntimeException);
        assertEquals("Client sent different magic number: got 17 expected 8920712192410910312", serverEx.getMessage());
    }
    
    /**
     * tests a different protocol (no {@link ObjectInputStream} and no magic number)
     */
    public void testNoMagicNumber() throws Exception
    {
        checkPortAvailable(PORT_TO_USE);
        StartupSocketCommunicator sscServer = new StartupSocketCommunicator("TestApp1", PORT_TO_USE, new ContactHandler()
        {
            public Serializable handleContactFromOtherInstance(final Serializable pData)
            {
                fail("Should not be called");
                return null; // to please the compiler
            }
        }, null);
        assertTrue(sscServer.isServerMode());
        assertFalse(sscServer.isServerStopped());
        // simulate a different client
        Socket clientSocket = new Socket(InetAddress.getLocalHost(), PORT_TO_USE);
        OutputStream clientOut = clientSocket.getOutputStream();
        try
        {
            for (int i = 0; i < 10240; i++)
            {
                clientOut.write(i);
            }
            clientOut.flush();
        } catch (Exception ex)
        {
            // this may happen, depending on the default socket buffer and other stuff
        }
        Thread.sleep(1000); // wait a bit so the server thread can finish running
        assertFalse(sscServer.isServerStopped());
        sscServer.waitServerStopped();
        assertTrue(sscServer.isServerStopped());
        Throwable serverEx = sscServer.getException();
        assertNotNull(serverEx);
        assertTrue(serverEx instanceof StreamCorruptedException);
    }
    
}
