package com.sdm.util.model;

import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

/**
 * Implements a call target for notification tests.
 */
public class CallbackTarget implements ChangeListener
{
    /**
     * Flag, set to true when method {@link #stateChanged(javax.swing.event.ChangeEvent)} is called.
     */
    private boolean mStateChangedCalled = false;

    /**
     * The value of the parameter of {@link #stateChanged(javax.swing.event.ChangeEvent)} from the last call.
     */
    private ChangeEvent mStateChangedParameter = null;

    /**
     * @return true, iff the method {@link #stateChanged(javax.swing.event.ChangeEvent)} has been called since the
     * last call to {@link #reset()}.
     */
    public boolean isStateChangedCalled()
    {
        return mStateChangedCalled;
    }

    /**
     * @return the parameter of the last call to the method {@link #stateChanged(javax.swing.event.ChangeEvent)}
     * or null if the method has not been called since the last call to {@link #reset()}.
     */
    public ChangeEvent getStateChangedEvent()
    {
        return mStateChangedParameter;
    }

    /**
     * Resets the registered data.
     */
    public void reset()
    {
        mStateChangedCalled = false;
        mStateChangedParameter = null;
    }

    /**
     * @see javax.swing.event.ChangeListener#stateChanged(javax.swing.event.ChangeEvent)
     */
    public void stateChanged(final ChangeEvent e)
    {
        mStateChangedCalled = true;
        mStateChangedParameter = e;
    }

}

